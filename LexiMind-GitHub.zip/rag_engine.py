"""
LexiMind RAG Engine
Document-grounded question answering using clause-aware chunking, hybrid TF-IDF retrieval
(word n-grams + character n-grams, which handle Telugu word endings), bilingual query expansion,
and generative (AI) or extractive (offline) answers with source citations.
Never fabricates facts; explicitly reports 'Information not found' when answers are absent.
"""

import re
from typing import Dict, Any, List, Optional

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from config import GEMINI_API_KEY, OPENAI_API_KEY
from clause_analyzer import segment_into_clauses, extract_parties, extract_labeled_amounts, extract_time_periods
from text_simplifier import split_sentences, is_noise_sentence, is_heading_line, simplify_sentence


# Bilingual query expansion: an English question can find Telugu text and vice versa
QUERY_EXPANSION = {
    "rent": ["rent", "rental", "అద్దె", "monthly", "నెలవారీ"],
    "అద్దె": ["rent", "అద్దె", "నెలవారీ"],
    "deposit": ["deposit", "advance", "security", "డిపాజిట్", "ధరావతు", "అడ్వాన్స్"],
    "డిపాజిట్": ["deposit", "advance", "ధరావతు", "అడ్వాన్స్"],
    "ధరావతు": ["deposit", "డిపాజిట్", "అడ్వాన్స్"],
    "price": ["price", "consideration", "sale", "amount", "క్రయధనం", "ధర", "రూ"],
    "cost": ["price", "amount", "payment", "fee", "rs", "రూ"],
    "pay": ["pay", "payment", "payable", "paid", "చెల్లించ", "చెల్లింపు"],
    "payment": ["pay", "payable", "paid", "rs", "చెల్లింపు", "చెల్లించ"],
    "ఎంత": ["rs", "రూ", "amount", "మొత్తం", "రూపాయలు"],
    "fee": ["fee", "fees", "charges", "royalty", "ఫీజు"],
    "terminate": ["terminate", "termination", "end", "cancel", "notice", "రద్దు", "నోటీసు"],
    "cancel": ["terminate", "termination", "cancel", "notice", "రద్దు", "నోటీసు"],
    "cancelled": ["terminate", "termination", "notice", "రద్దు"],
    "రద్దు": ["terminate", "termination", "notice", "రద్దు", "నోటీసు"],
    "notice": ["notice", "నోటీసు", "prior", "written"],
    "duration": ["term", "duration", "period", "months", "years", "కాలపరిమితి", "నెలలు", "సంవత్సరాలు"],
    "term": ["term", "duration", "period", "months", "years", "కాలపరిమితి"],
    "long": ["term", "duration", "period", "months", "years", "కాలపరిమితి"],
    "end": ["end", "terminate", "termination", "expire", "expiry", "till", "until", "వరకు", "కాలపరిమితి", "రద్దు"],
    "కాలపరిమితి": ["term", "duration", "months", "నెలలు"],
    "who": ["between", "party", "parties", "lessor", "lessee", "vendor", "purchaser", "పక్షం", "యజమాని", "అద్దెదారు"],
    "parties": ["between", "party", "lessor", "lessee", "vendor", "purchaser", "disclosing", "receiving", "పక్షం"],
    "ఎవరు": ["పక్షం", "యజమాని", "అద్దెదారు", "విక్రయదారు", "కొనుగోలుదారు", "party"],
    "property": ["property", "premises", "situated", "survey", "plot", "door", "ఆస్తి", "సర్వే", "డోర్", "స్థలం"],
    "address": ["situated", "residing", "located", "door", "నివాసం", "డోర్"],
    "where": ["situated", "located", "at", "jurisdiction", "court", "నగరంలో"],
    "boundaries": ["east", "west", "north", "south", "bounded", "తూర్పు", "పడమర", "ఉత్తర", "దక్షిణ", "చతుస్సీమలు"],
    "penalty": ["penalty", "forfeit", "damages", "interest", "late", "జరిమానా", "జప్తు"],
    "late": ["late", "delay", "default", "interest", "ఆలస్యం"],
    "repair": ["repair", "repairs", "maintenance", "మరమ్మతు"],
    "dispute": ["dispute", "arbitration", "court", "jurisdiction", "వివాద", "కోర్టు"],
    "confidential": ["confidential", "confidentiality", "disclose", "secret", "గోప్యత", "రహస్య"],
    "lock": ["lock-in", "lock", "లాక్-ఇన్"],
    "possession": ["possession", "handover", "keys", "స్వాధీనం", "అప్పగించ"],
}

STOPWORDS = {
    "what", "is", "the", "for", "in", "a", "an", "of", "to", "at", "by", "from", "and", "or", "on", "it",
    "this", "that", "how", "when", "where", "which", "does", "do", "are", "be", "can", "will", "there",
    "any", "my", "me", "i", "we", "you", "your", "agreement", "document", "contract", "deed", "about",
    "ఈ", "ఏమిటి", "ఏమి", "లో", "కి", "ఉంది", "ఉన్నాయి", "ఒప్పందం", "ఒప్పందంలో", "పత్రంలో", "మరియు",
}

INTENTS = {
    "money": r"\b(?:how much|amount|rent|price|deposit|fee|cost|pay|payment|consideration|money|salary)\b|ఎంత|అద్దె|ధర|డబ్బు|డిపాజిట్|చెల్లింపు",
    "time": r"\b(?:when|how long|duration|term|period|date|expire|end|until|valid)\b|ఎప్పుడు|ఎన్ని నెలలు|గడువు|కాలపరిమితి|తేదీ",
    "who": r"\b(?:who|parties|party|names?|landlord|tenant|buyer|seller)\b|ఎవరు|పక్షాలు|పేర్లు",
    "cancel": r"\b(?:terminat\w*|cancel\w*|notice|exit|leave|vacate)\b|రద్దు|నోటీసు|ఖాళీ",
}

MONEY_RE = r"(?:Rs\.?|INR|రూ|\$)\s*\d"
TIME_RE = r"\d+\s*(?:days?|months?|years?|నెల|రోజు|సంవత్సర)|\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4}|(?:January|February|March|April|May|June|July|August|September|October|November|December)"
WHO_RE = r"\b(?:between|lessor|lessee|landlord|tenant|vendor|seller|purchaser|buyer|party)\b|పక్షం|యజమాని|అద్దెదారు|విక్రయదారు|కొనుగోలుదారు"
CANCEL_RE = r"\b(?:terminat\w*|cancel\w*|notice|end this agreement)\b|రద్దు|నోటీసు"

# Question patterns used to pick which structured facts to show above the answer
PARTY_QUESTION = r"\b(?:who are|parties|party|names?)\b|ఎవరెవరు|పక్షాలు|పేర్లు|ఎవరు"
MONEY_QUESTION = r"\b(?:how much|amount|rent|price|deposit|fee|cost|payment|consideration|money|salary|advance)\b|అద్దె|ధర|డబ్బు|డిపాజిట్|ధరావతు|చెల్లింపు|అడ్వాన్స్"
AMOUNT_QUESTION_LABELS = [
    (r"\brent\b|అద్దె", "Monthly rent"),
    (r"deposit|డిపాజిట్|ధరావతు", "Security deposit"),
    (r"advance|అడ్వాన్స్", "Advance / earnest money"),
    (r"price|consideration|sale|క్రయధనం|ధర", "Sale price / consideration"),
    (r"balance|మిగిలిన", "Balance amount"),
    (r"\bfees?\b|charges|ఫీజు", "Fee / charges"),
    (r"penalt|fine|జరిమానా", "Penalty / damages"),
]
PERIOD_QUESTION_LABELS = [
    (r"notice|cancel|terminat|నోటీసు|రద్దు", "Notice period"),
    (r"lock", "Lock-in period"),
    (r"\bterm\b|duration|how long|period of|valid|కాలపరిమితి|ఎన్ని నెలలు", "Agreement term"),
    (r"confidential|గోప్య", "Confidentiality period"),
]

NOT_FOUND_TE = "ఈ ప్రశ్నకు సంబంధించిన సమాచారం సమర్పించిన దస్తావేజులో కనుగొనబడలేదు. (Information not found in the uploaded document)."
NOT_FOUND_EN = "The requested information could not be found in the uploaded legal document."


def _tokens(text: str) -> List[str]:
    return [t for t in re.findall(r"[A-Za-z]+(?:-[A-Za-z]+)?|[ఀ-౿]+|\d[\d,]*", text.lower()) if t not in STOPWORDS]


def _short_reference(title: str, fallback: str) -> str:
    title = re.sub(r"[:\s]+$", "", title.strip())
    if not title or title.startswith("Preamble"):
        return fallback if not title else "Preamble / Parties"
    if len(title) > 60:
        title = title[:60].rsplit(" ", 1)[0] + "…"
    return title


class DocumentRAGEngine:
    """Retrieval-Augmented Generation (RAG) engine for legal documents."""

    def __init__(self, text: str, pages_data: Optional[List[Dict[str, Any]]] = None):
        self.raw_text = text or ""
        self.pages_data = pages_data or []
        self.chunks: List[Dict[str, Any]] = []
        self.word_vec: Optional[TfidfVectorizer] = None
        self.char_vec: Optional[TfidfVectorizer] = None
        self.word_matrix = None
        self.char_matrix = None
        # Kept for backward compatibility with older code that inspected these attributes
        self.vectorizer: Optional[TfidfVectorizer] = None
        self.tfidf_matrix = None

        if self.raw_text.strip():
            self._build_index()

    # ------------------------------------------------------------------ indexing
    def _chunks_from_text(self, text: str, page_number: int, multi_page: bool) -> List[Dict[str, Any]]:
        chunks = []
        for cl in segment_into_clauses(text):
            if cl["clause_id"].startswith("Signatures"):
                continue
            ref = _short_reference(cl["title"], cl["clause_id"])
            if multi_page:
                ref = f"Page {page_number} · {ref}"
            sentences = [s for s in split_sentences(cl["text"]) if not is_noise_sentence(s) or is_heading_line(s)]
            if len(" ".join(sentences).split()) <= 90:
                windows = ["\n".join(sentences)] if sentences else [cl["text"]]
            else:
                windows = ["\n".join(sentences[i:i + 3]) for i in range(0, len(sentences), 2)]
            for w_idx, window in enumerate(windows, start=1):
                if len(window.strip()) < 15:
                    continue
                simplified = " ".join(" ".join(simplify_sentence(s, set())[0]) for s in window.split("\n"))
                chunks.append({
                    "chunk_id": f"P{page_number}-{cl['clause_id']}-{w_idx}",
                    "text": window.strip(),
                    # Index the original AND the plain-language wording so everyday questions match legalese
                    "search_text": window.strip() + "\n" + simplified,
                    "page_number": page_number,
                    "reference": ref,
                })
        return chunks

    def _build_index(self):
        """Chunk the document by clause and build word- and character-level TF-IDF indexes."""
        pages = [p for p in self.pages_data if p.get("text", "").strip()]
        if len(pages) > 1:
            for page_info in pages:
                self.chunks.extend(self._chunks_from_text(page_info["text"], page_info.get("page_number", 1), True))
        else:
            self.chunks = self._chunks_from_text(self.raw_text, 1, False)

        if not self.chunks:
            self.chunks = [{"chunk_id": "full", "text": self.raw_text.strip(), "page_number": 1, "reference": "Full document"}]

        corpus = [c.get("search_text", c["text"]) for c in self.chunks]
        self.word_vec = TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True, token_pattern=r"(?u)[\wఀ-౿]+")
        self.char_vec = TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 4), sublinear_tf=True)
        self.word_matrix = self.word_vec.fit_transform(corpus)
        self.char_matrix = self.char_vec.fit_transform(corpus)
        self.vectorizer, self.tfidf_matrix = self.word_vec, self.word_matrix

    # ------------------------------------------------------------------ retrieval
    def expand_query(self, query: str) -> str:
        terms = _tokens(query)
        expanded = list(terms)
        for t in terms:
            for key, extra in QUERY_EXPANSION.items():
                if t == key or (len(key) > 3 and t.startswith(key)):
                    expanded.extend(extra)
        return " ".join(expanded) if expanded else query

    def _similarities(self, query: str, word_matrix, char_matrix) -> np.ndarray:
        q = self.expand_query(query)
        word_sim = cosine_similarity(self.word_vec.transform([q]), word_matrix).flatten()
        char_sim = cosine_similarity(self.char_vec.transform([q]), char_matrix).flatten()
        return 0.55 * word_sim + 0.45 * char_sim

    def retrieve_relevant_chunks(self, query: str, top_k: int = 3, threshold: float = 0.05) -> List[Dict[str, Any]]:
        """Retrieve top-k relevant chunks using the hybrid similarity score."""
        if not self.chunks or self.word_vec is None:
            return []
        scores = self._similarities(query, self.word_matrix, self.char_matrix)
        scores = scores + 0.08 * np.array([self._intent_boost(query, c["text"]) for c in self.chunks])
        results = []
        for idx in np.argsort(scores)[::-1][:top_k]:
            if scores[idx] >= threshold:
                chunk_copy = dict(self.chunks[idx])
                chunk_copy["similarity_score"] = round(float(scores[idx]), 4)
                results.append(chunk_copy)
        return results

    @staticmethod
    def _intent_boost(query: str, text: str) -> float:
        boost = 0.0
        for intent, q_pat in INTENTS.items():
            if re.search(q_pat, query, re.IGNORECASE):
                t_pat = {"money": MONEY_RE, "time": TIME_RE, "who": WHO_RE, "cancel": CANCEL_RE}[intent]
                if re.search(t_pat, text, re.IGNORECASE):
                    boost += 1.0
        return boost

    @staticmethod
    def _term_in(term: str, haystack: str) -> bool:
        stem = term[:4] if re.match(r"[ఀ-౿]", term) and len(term) > 4 else term
        if re.match(r"[a-z]", stem):
            stem = re.sub(r"(?:led|ed|es|s|ing)$", "", stem) if len(stem) > 5 else stem
            return bool(re.search(r"(?<![a-z])" + re.escape(stem), haystack))
        return stem in haystack

    def _has_content_overlap(self, query: str, passages: List[str]) -> bool:
        """At least half of the meaningful query terms (directly, by Telugu stem, or via a translation) must occur."""
        q_terms = [t for t in _tokens(query) if len(t) > 2 and not t.isdigit()]
        if not q_terms:
            return True
        haystack = " ".join(passages).lower()
        matched = 0
        for t in q_terms:
            options = [t]
            for key, extra in QUERY_EXPANSION.items():
                if t == key or (len(key) > 3 and t.startswith(key)):
                    options.extend(extra)
            if any(self._term_in(o.lower(), haystack) for o in options):
                matched += 1
        return matched / len(q_terms) >= 0.5

    # ------------------------------------------------------------------ answering
    def _best_sentences(self, query: str, retrieved: List[Dict[str, Any]], k: int = 2) -> List[Dict[str, Any]]:
        candidates = []
        for rank, chunk in enumerate(retrieved):
            for s in split_sentences(chunk["text"]):
                if is_heading_line(s) or is_noise_sentence(s):
                    continue
                candidates.append({"text": s, "reference": chunk["reference"], "rank": rank})
        if not candidates:
            return []
        texts = [c["text"] + " " + " ".join(simplify_sentence(c["text"], set())[0]) for c in candidates]
        word_m = self.word_vec.transform(texts)
        char_m = self.char_vec.transform(texts)
        sims = self._similarities(query, word_m, char_m)
        for c, sim in zip(candidates, sims):
            c["score"] = float(sim) + 0.15 * self._intent_boost(query, c["text"]) - 0.03 * c["rank"]
        candidates.sort(key=lambda c: c["score"], reverse=True)
        chosen = []
        top_score = candidates[0]["score"]
        for c in candidates:
            if len(chosen) >= k:
                break
            if chosen and (c["score"] < 0.04 or c["score"] < 0.6 * top_score):
                break
            if all(c["text"] != x["text"] for x in chosen):
                chosen.append(c)
        return chosen

    def _direct_facts(self, query: str, retrieved: List[Dict[str, Any]], source_lang: str) -> List[str]:
        """Short structured answer for common question types (parties, money, time periods)."""
        facts = []
        context = "\n".join(c["text"] for c in retrieved)
        key = "label_te" if source_lang == "te" else "label_en"
        asks_time = bool(re.search(INTENTS["time"], query, re.IGNORECASE) or re.search(INTENTS["cancel"], query, re.IGNORECASE))
        asks_money = bool(re.search(MONEY_QUESTION, query, re.IGNORECASE)) or ("ఎంత" in query and not asks_time)

        if re.search(PARTY_QUESTION, query, re.IGNORECASE):
            for p in extract_parties(self.raw_text)[:4]:
                facts.append(f"{p['role']}: **{p['name']}**")
        if asks_money:
            amounts = extract_labeled_amounts(context)
            wanted = {label for pat, label in AMOUNT_QUESTION_LABELS if re.search(pat, query, re.IGNORECASE)}
            if wanted:
                amounts = [a for a in amounts if a["label_en"] in wanted] or amounts
            for a in amounts[:4]:
                facts.append(f"{a[key]}: **{a['value']}**")
        if asks_time:
            periods = extract_time_periods(context)
            wanted = {label for pat, label in PERIOD_QUESTION_LABELS if re.search(pat, query, re.IGNORECASE)}
            if wanted:
                periods = [p for p in periods if p["label_en"] in wanted] or periods
            for p in periods[:4]:
                facts.append(f"{p[key]}: **{p['value']}**")
        return list(dict.fromkeys(facts))

    def answer_question(self, query: str, source_lang: str = "en", use_ai: bool = True) -> Dict[str, Any]:
        """
        Answer user questions grounded exclusively in the document context.
        Supports both AI API generation and extractive offline fallback.
        """
        not_found_msg = NOT_FOUND_TE if source_lang == "te" else NOT_FOUND_EN
        if not self.raw_text.strip():
            return {"answer": "No document content is loaded.", "supporting_passages": [], "engine": "none", "grounded": False}

        retrieved = self.retrieve_relevant_chunks(query, top_k=3)
        if not retrieved:
            return {"answer": not_found_msg, "supporting_passages": [], "engine": "Verification Check (Threshold Not Met)", "grounded": False}

        if not self._has_content_overlap(query, [c["text"] for c in retrieved]):
            return {"answer": not_found_msg, "supporting_passages": [], "engine": "Verification Check (No Content Overlap)", "grounded": False}

        # Step 1: AI answer generation grounded in the retrieved excerpts
        ai_error = None
        if use_ai and (GEMINI_API_KEY or OPENAI_API_KEY):
            from language_processor import call_ai_model
            context_str = "\n\n".join(f"[{c['reference']}]: {c['text']}" for c in retrieved)
            target_lang = "Telugu" if source_lang == "te" else "English"
            prompt = f"""Answer the user's question STRICTLY from the document excerpts below.
Do NOT invent facts, obligations, or contract terms.
If the excerpts do not contain the answer, reply exactly: "This information is not specified in the document."
Answer in simple {target_lang}, in 1-4 sentences, and cite the reference in square brackets.

DOCUMENT EXCERPTS:
\"\"\"
{context_str}
\"\"\"

QUESTION: {query}
ANSWER:"""
            ai = call_ai_model(prompt, system="You are a legal document Q&A assistant. Answer only from the provided excerpts.")
            if ai["text"]:
                return {"answer": ai["text"], "supporting_passages": retrieved, "engine": f"{ai['engine']} RAG", "grounded": True}
            ai_error = "; ".join(ai["errors"])

        # Step 2: Offline extractive answer
        best = self._best_sentences(query, retrieved, k=2)
        if not best:
            return {"answer": not_found_msg, "supporting_passages": [], "engine": "Verification Check (No Answer Sentence)", "grounded": False}

        lines = ["📄 **ఆధార సహిత సమాధానం:**" if source_lang == "te" else "📄 **Answer from the document:**"]
        facts = self._direct_facts(query, retrieved, source_lang)
        if facts:
            lines.extend(f"* {f}" for f in facts)
            lines.append("")
        for b in best:
            simple = " ".join(simplify_sentence(b["text"], set())[0])
            lines.append(f"* {simple}")
        lines.append("")
        refs = list(dict.fromkeys(b["reference"] for b in best))
        lines.append(("*ఆధారం: " if source_lang == "te" else "*Reference: ") + "; ".join(refs) + "*")
        lines.append("")
        lines.append(("**అసలు వాక్యం:** " if source_lang == "te" else "**Original wording:** ") + f"\"{best[0]['text']}\"")

        result = {
            "answer": "\n".join(lines),
            "supporting_passages": retrieved,
            "engine": "LexiMind Hybrid Extractive RAG (Offline TF-IDF word + char n-grams)",
            "grounded": True,
        }
        if ai_error:
            result["ai_error"] = ai_error
        return result

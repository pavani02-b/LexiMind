"""
LexiMind Text Simplifier (Offline NLP Core)
Document-specific, rule-based legal simplification used when no AI API key is configured.

Pipeline:
  1. Text normalization & sentence segmentation (English + Telugu, abbreviation-aware,
     repairs PDF/OCR line wrapping, drops OCR noise).
  2. Lexical & syntactic simplification of every sentence:
     - English: legalese phrase rewriting (hereinafter, shall, notwithstanding, S/o ...),
       removal of amount-in-words duplicates, long-sentence splitting.
     - Telugu: archaic/grantha written forms -> modern spoken Telugu
       (చెల్లించవలెను -> చెల్లించాలి, పత్రము -> పత్రం, కలదు -> ఉంది ...).
  3. Extractive summarization with TextRank over TF-IDF sentence vectors.
  4. Obligation / right / prohibition extraction per party.
  5. Readability statistics (before vs. after).

Every output sentence is derived from the uploaded document itself, so two different
documents always produce two different simplifications.
"""

import re
from typing import Dict, List, Tuple

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


TE_BLOCK = r"ఀ-౿"
TE_CONSONANT = r"క-హ"
TE_CHAR_RE = re.compile(f"[{TE_BLOCK}]")

# Abbreviations that end with a period but do not end a sentence
ABBREVIATIONS = {
    "rs", "mr", "mrs", "ms", "dr", "smt", "sri", "shri", "no", "nos", "sy", "s/o", "d/o", "w/o",
    "c/o", "vs", "viz", "etc", "e.g", "i.e", "ltd", "pvt", "inc", "co", "st", "d.no", "h.no",
    "plot", "sq", "ft", "regd", "approx", "dt", "dist", "vol", "pg", "art", "sec", "cl", "jr", "sr",
    "రూ", "నెం", "శ్రీ", "శ్రీమతి", "సం", "డా",
}


# ----------------------------------------------------------------------------------------
# 1. Normalization & sentence segmentation
# ----------------------------------------------------------------------------------------

def normalize_text(text: str) -> str:
    """Clean extraction artifacts while keeping all legal content."""
    if not text:
        return ""
    text = text.replace("\r\n", "\n").replace("\r", "\n").replace("‌", "").replace("﻿", "")
    text = re.sub(r"^\s*-{2,}\s*Page\s*\d+.*?-{2,}\s*$", "", text, flags=re.MULTILINE | re.IGNORECASE)
    text = re.sub(r"^\s*\[(?:FICTIONAL|సాఫ్ట్‌వేర్|సాఫ్ట్వేర్)[^\]]*\]\s*$", "", text, flags=re.MULTILINE)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def is_heading_line(line: str) -> bool:
    """Detect clause headings such as '1. PREMISES:' or 'నిబంధన 2 (అద్దె వివరాలు):'."""
    s = line.strip()
    if not s or len(s.split()) > 12:
        return False
    if s.endswith(":"):
        return True
    letters = re.findall(r"[A-Za-z]", s)
    if letters and len(letters) >= 4 and sum(1 for c in letters if c.isupper()) / len(letters) > 0.85:
        return True
    return False


def is_noise_sentence(sentence: str) -> bool:
    """Filter OCR garbage, stamp-paper headers, separators and signature fragments."""
    s = sentence.strip()
    if len(s) < 12:
        return True
    letters = len(re.findall(rf"[A-Za-z{TE_BLOCK}]", s))
    if letters / max(len(s), 1) < 0.55:
        return True
    words = s.split()
    if len(words) < 3:
        return True
    # OCR table borders / stamp-paper headers
    if s.count("|") >= 2:
        return True
    # Share of tokens that look like real words (Telugu word of 2+ letters, or a Latin word with a vowel)
    real = sum(
        1 for w in words
        if re.fullmatch(rf"[{TE_BLOCK}]{{2,}}[\.,:;!\)]*", w) or re.fullmatch(r"\(?[A-Za-z]*[aeiouAEIOU][A-Za-z]{2,}[\.,:;\)]*", w)
        or re.fullmatch(r"(?:Rs\.?|రూ[\.!]?)?\d[\d,\./\-]*[/\-]*[\.,]?", w)
    )
    if len(words) >= 4 and real / len(words) < 0.5:
        return True
    # OCR fragments: many 1-2 character tokens
    short_tokens = sum(1 for w in words if len(re.sub(r"[^\w]", "", w)) <= 2)
    if len(words) >= 5 and short_tokens / len(words) > 0.6:
        return True
    return False


def _ends_with_abbreviation(chunk: str) -> bool:
    if re.fullmatch(r"\(?\d{1,3}[\.\)]", chunk.strip()):  # list numbers such as "1." stay with their heading
        return True
    m = re.search(rf"([A-Za-z{TE_BLOCK}\./]+)\.$", chunk.strip())
    if not m:
        return False
    token = m.group(1).lower().strip(".")
    if token in ABBREVIATIONS:
        return True
    # Single initials such as "P." or "B.S."
    if re.fullmatch(rf"(?:[A-Za-z{TE_BLOCK}]{{1,2}}\.)*[A-Za-z{TE_BLOCK}]{{1,2}}", token):
        return True
    return False


def _join_wrapped_lines(block: str) -> List[str]:
    """Join lines broken by PDF/OCR wrapping; keep headings and list items on their own line."""
    lines = [l.strip() for l in block.split("\n") if l.strip()]
    units: List[str] = []
    for line in lines:
        if not units:
            units.append(line)
            continue
        prev = units[-1]
        starts_new = (
            is_heading_line(prev)
            or is_heading_line(line)
            or re.match(r"^(?:\d+[\.\)]|\([a-z0-9]+\)|[-•*]|Clause|Section|Article|నిబంధన|షరతు)\s*", line, re.IGNORECASE)
            or re.search(r"[\.\!\?।:;]$", prev)
        )
        if starts_new:
            units.append(line)
        else:
            units[-1] = prev + " " + line
    return units


def split_sentences(text: str) -> List[str]:
    """Abbreviation-aware sentence splitter for English, Telugu and mixed text."""
    text = normalize_text(text)
    sentences: List[str] = []
    for block in re.split(r"\n\s*\n", text):
        for unit in _join_wrapped_lines(block):
            parts = re.split(rf"(?<=[\.\!\?।])\s+(?=[\"'(\[]?[A-Z0-9{TE_BLOCK}])", unit)
            buf = ""
            for part in parts:
                buf = f"{buf} {part}".strip() if buf else part
                if _ends_with_abbreviation(buf):
                    continue
                sentences.append(buf)
                buf = ""
            if buf:
                sentences.append(buf)
    return [s.strip() for s in sentences if s.strip()]


def sentence_language(sentence: str) -> str:
    te = len(TE_CHAR_RE.findall(sentence))
    en = len(re.findall(r"[A-Za-z]", sentence))
    return "te" if te >= en else "en"


# ----------------------------------------------------------------------------------------
# 2a. English lexical / syntactic simplification
# ----------------------------------------------------------------------------------------

_MONTHS = r"January|February|March|April|May|June|July|August|September|October|November|December"

EN_REWRITE_RULES: List[Tuple[str, str]] = [
    # Boilerplate that adds nothing for a layperson
    (r",?\s*\(?which expression shall,?\s*unless (?:it is )?repugnant to the context[^)]*\)?", ""),
    (r"\bof the (?:ONE|FIRST|OTHER|SECOND) PART\b", ""),
    (r"\((?:Rupees|Rs\.?|INR)[^)]*?only\)", ""),
    (r"\bnow,? this (?:agreement|deed|indenture) witnesseth(?: as follows)?\b", "The parties agree as follows"),
    (r"\bnow,? therefore,?", "So,"),
    (r"\bin witness whereof\b,?", "To confirm this,"),
    (r"\bwitnesseth\b", "records"),
    (r"\bnotwithstanding anything(?: to the contrary)?(?: contained)?(?: herein| in this agreement)?", "despite anything else in this agreement"),
    (r"\bcovenants? and agrees? to\b|\bcovenants? to\b|\bundertakes? to\b", "promises to"),
    (r"\breserves the (?:sole and absolute|sole|absolute) (?:discretion|right) to\b", "can, entirely on its own decision,"),
    (r"\bin strict confidence\b", "completely secret"),
    (r"\bprior written consent\b", "written permission first"),
    (r"\bany and all\b", "all"),
    (r"\s*\bwhatsoever\b", ""),
    (r"\bkeep indemnified\b", "keep protected"),
    (r"\bthe receipt whereof\b", "receipt of which"),
    (r"\bnotwithstanding\b", "despite"),
    (r"\bhereinafter (?:collectively |jointly |individually )?(?:called|referred to as|termed)\b", "called"),
    (r"\bhereinafter\b", "from now on"),
    (r"\b(?:made and entered into|entered into and executed|made and executed)\b", "made"),
    (r"\bby and between\b", "between"),
    (rf"\bon this (\d{{1,2}}(?:st|nd|rd|th)?) day of ({_MONTHS}),?", r"on \1 \2,"),
    (rf"\b(\d{{1,2}}(?:st|nd|rd|th)?) day of ({_MONTHS}),?", r"\1 \2,"),
    (r"\b(\d{1,2}(?:st|nd|rd|th)) day of (?:every|each)\b", r"\1 of every"),
    (r"\bthe parties hereto\b", "both parties"),
    (r"\bparties hereto\b", "parties"),
    # Indian legal abbreviations
    (r"\bS/o\.?", "son of"),
    (r"\bD/o\.?", "daughter of"),
    (r"\bW/o\.?", "wife of"),
    (r"\bC/o\.?", "care of"),
    (r"\bresiding at\b", "living at"),
    (r"\baged about\b", "aged around"),
    # Affidavits
    (r"\bdo hereby solemnly (?:affirm|declare)(?: and (?:declare|state|affirm))?(?: on oath)?\b", "state under oath"),
    (r"\bsolemnly (?:affirm|declare)(?: and (?:declare|state|affirm))?\b", "state under oath"),
    (r"\btrue and correct to the best of (?:my|our) knowledge(?:,? information)? and belief\b", "true as far as I know"),
    (r"\bthe deponent\b", "the person making this statement"),
    (r"\bdeponent\b", "person making this statement"),
    # Conditions & connectors
    (r"\bin the event (?:that|of)\b", "if"),
    (r"\bprovided (?:always |further |however )?that\b", "as long as"),
    (r"\bsave and except\b", "except"),
    (r"\bprior to\b", "before"),
    (r"\bsubsequent to\b", "after"),
    (r"\bpursuant to\b", "under"),
    (r"\bin accordance with\b", "following"),
    (r"\bin (?:respect|relation) (?:of|to)\b|\bwith respect to\b|\bwith regard to\b", "about"),
    (r"\bfor the purpose of\b", "for"),
    (r"\bby virtue of\b", "because of"),
    (r"\bin lieu of\b", "instead of"),
    (r"\binasmuch as\b", "because"),
    (r"\bon or before\b", "by"),
    (r"\bat (?:its|his|her|their) (?:sole|absolute|sole and absolute) discretion\b", "entirely as they choose"),
    (r"\bfrom time to time\b", "when needed"),
    (r"\bforthwith\b", "immediately"),
    (r"\bper annum\b", "per year"),
    (r"\bper mensem\b", "per month"),
    (r"\binter alia\b", "among other things"),
    (r"\bmutatis mutandis\b", "with the necessary changes"),
    (r"\bbona fide\b", "genuine"),
    (r"\bnull and void\b", "cancelled and of no effect"),
    (r"\bin perpetuity\b", "forever"),
    (r"\bforce majeure\b", "events beyond anyone's control (force majeure)"),
    (r"\bindemnify,? defend and hold harmless\b|\bindemnify and hold harmless\b", "protect and compensate"),
    (r"\bindemnify\b", "compensate"),
    (r"\bfree from all encumbrances\b", "free from any loans, mortgages or legal claims"),
    (r"\bencumbrances?\b", "loans, mortgages or legal claims"),
    (r"\bvacant and peaceful possession\b", "empty, undisputed possession"),
    (r"\b(?:aforesaid|aforementioned|above[- ]mentioned)\b", "mentioned above"),
    (r"\bthe said\b", "the"),
    (r"\bthe undersigned\b", "the person signing below"),
    # Archaic "here-/there-" words
    (r"\bhereby\s+", ""),
    (r"\bherein\b", "in this agreement"),
    (r"\bhereto\b", "to this agreement"),
    (r"\bhereunder\b", "under this agreement"),
    (r"\bhereof\b", "of this agreement"),
    (r"\bthereof\b", "of it"),
    (r"\btherein\b", "in it"),
    (r"\bthereto\b", "to it"),
    (r"\bthereunder\b", "under it"),
    (r"\bwhereby\b", "by which"),
    (r"\bwherein\b", "in which"),
    (r"\bwhereas\b,?\s*", ""),
    # Modal verbs
    (r"\bshall not\b", "must not"),
    (r"\bshall be entitled to\b", "has the right to"),
    (r"\bis entitled to\b", "has the right to"),
    (r"\bshall be deemed (?:to be )?\b", "will be treated as "),
    (r"\bshall be borne by\b", "must be paid by"),
    (r"\bshall be liable to\b", "must"),
    (r"\bshall be liable for\b", "is responsible for"),
    (r"\bshall be responsible for\b", "is responsible for"),
    (r"\bshall (be|have|apply|remain|continue|survive|commence|expire|prevail|mean|include|stand|become|come)\b", r"will \1"),
    (r"\bshall\b", "must"),
    # Plain words
    (r"\blet out\b", "rent out"),
    (r"\btake on lease\b", "rent"),
    (r"\bcommencing\b", "starting"),
    (r"\bcommence\b", "start"),
    (r"\bcommencement\b", "start"),
    (r"\bexpiry\b|\bexpiration\b", "end"),
    (r"\bterminate\b", "end"),
    (r"\bremuneration\b", "payment"),
    (r"\bremit\b", "pay"),
    (r"\bfurnish\b", "give"),
    (r"\bendeavou?r\b", "try"),
    (r"\butili[sz]e\b", "use"),
    (r"\bexecuted\b", "signed"),
    (r"\bexecute\b", "sign"),
    (r"\bLessor\b", "Landlord"),
    (r"\bLESSOR\b", "LANDLORD"),
    (r"\bLessee\b", "Tenant"),
    (r"\bLESSEE\b", "TENANT"),
    (r"\bVendee\b", "Buyer"),
    (r"\bVendor\b", "Seller"),
    (r"\bVENDOR\b", "SELLER"),
    (r"\bPurchaser\b", "Buyer"),
    (r"\bPURCHASER\b", "BUYER"),
]
# Rules that start with a capitalised word (Lessor, LESSEE, S/o ...) are case-sensitive so that
# "Lessor" -> "Landlord" and "LESSOR" -> "LANDLORD" keep the document's own casing.
_EN_COMPILED = [
    (re.compile(p) if re.match(r"\\b[A-Z]", p) else re.compile(p, re.IGNORECASE), r)
    for p, r in EN_REWRITE_RULES
]


def _tidy_english(s: str) -> str:
    s = re.sub(r"\b(\w+)\s*/\s*\1\b", r"\1", s, flags=re.IGNORECASE)  # "LANDLORD / LANDLORD"
    s = re.sub(r"\b(the|a|an)\s+\1\b", r"\1", s, flags=re.IGNORECASE)
    s = re.sub(r"\(\s*\)", "", s)
    s = re.sub(r"\s+([,;:\.\)])", r"\1", s)
    s = re.sub(r"\(\s+", "(", s)
    s = re.sub(r",\s*,", ",", s)
    s = re.sub(r"^[,;:\s]+", "", s)
    s = re.sub(r"\s{2,}", " ", s).strip()
    if s and s[0].islower():
        s = s[0].upper() + s[1:]
    return s


def simplify_english_sentence(sentence: str) -> Tuple[List[str], int]:
    """Rewrite one English legal sentence. Returns (output sentences, number of rewrites)."""
    s = sentence
    changes = 0
    for pattern, repl in _EN_COMPILED:
        s, n = pattern.subn(repl, s)
        changes += n
    s = _tidy_english(s)

    # Split very long sentences at semicolons / ", and" boundaries
    out: List[str] = []
    pieces = [p.strip() for p in re.split(r";\s+|:\s+(?=[A-Z])", s) if p.strip()] if len(s.split()) > 28 else [s]
    for p in pieces:
        p = re.sub(r"[;,\s]+$", "", _tidy_english(p))
        if p and not re.search(r"[\.\!\?:]$", p):
            p += "."
        if p:
            out.append(p)
    if len(pieces) > 1:
        changes += len(pieces) - 1
    return out, changes


# ----------------------------------------------------------------------------------------
# 2b. Telugu lexical simplification (archaic written Telugu -> modern spoken Telugu)
# ----------------------------------------------------------------------------------------

TE_PHRASE_RULES: List[Tuple[str, str]] = [
    ("ఉభయ పక్షములవారు", "ఇరు పక్షాల వారు"),
    ("ఉభయ పక్షముల", "ఇరు పక్షాల"),
    ("ఉభయ పక్షాలు", "ఇరు పక్షాలు"),
    ("ఉభయుల", "ఇద్దరి"),
    ("ఉభయులు", "ఇద్దరూ"),
    ("స్వతంత్ర సర్వ హక్కులతో", "పూర్తి హక్కులతో"),
    ("వ్రాయించి ఇవ్వడమైనది", "రాసి ఇచ్చారు"),
    ("వ్రాయించియిచ్చిన", "రాసి ఇచ్చిన"),
    ("ఇవ్వడమైనది", "ఇచ్చారు"),
    ("చేయడమైనది", "చేశారు"),
    ("స్వాధీనపరచడమైనది", "అప్పగించారు"),
    ("రద్దుపరచబడును", "రద్దవుతుంది"),
    ("అని పిలువబడును", "అని పిలుస్తారు"),
    ("చేసినచో", "చేస్తే"),
    ("చేయనిచో", "చేయకపోతే"),
    ("ఇవ్వనిచో", "ఇవ్వకపోతే"),
    ("చెల్లించనిచో", "చెల్లించకపోతే"),
    ("కానిచో", "కాకపోతే"),
    ("అయినచో", "అయితే"),
    ("కాని యెడల", "కాకపోతే"),
    ("యెడల", "అయితే"),
    ("తక్షణమే", "వెంటనే"),
    ("పిమ్మట", "తర్వాత"),
    ("తదుపరి", "తర్వాత"),
    ("నిమిత్తం", "కోసం"),
    ("కొరకు", "కోసం"),
    ("అట్టి", "అలాంటి"),
    ("ఇట్టి", "ఇలాంటి"),
    ("ఏదేని", "ఏదైనా"),
    ("ఎవరేని", "ఎవరైనా"),
    ("సమయమున", "సమయంలో"),
    ("సదరు", "ఈ"),
    ("క్రింది", "కింది"),
    ("క్రింద", "కింద"),
    ("వ్రా", "రా"),
    (" యొక్క", ""),
    (" గాను", ""),
    (" నందు", "లో"),
    (" యందు", "లో"),
]

# Suffix rules: (regex, replacement). Lookbehinds keep them inside Telugu words only.
TE_SUFFIX_RULES: List[Tuple[str, str]] = [
    (rf"(?<=[{TE_CONSONANT}])వలెను(?![{TE_BLOCK}])", "ాలి"),          # చెల్లించవలెను -> చెల్లించాలి
    (rf"(?<=[{TE_CONSONANT}])వలయును(?![{TE_BLOCK}])", "ాలి"),
    (rf"(?<=[{TE_CONSONANT}])వలసిన(?![{TE_BLOCK}])", "ాల్సిన"),       # చెల్లించవలసిన -> చెల్లించాల్సిన
    (rf"(?<=[{TE_CONSONANT}])వలసి(?![{TE_BLOCK}])", "ాల్సి"),
    (rf"(?<=[{TE_CONSONANT}])డమైనది(?![{TE_BLOCK}])", "ారు"),          # నిర్ణయించడమైనది -> నిర్ణయించారు
    (rf"ినారు(?![{TE_BLOCK}])", "ారు"),                               # చెల్లించినారు -> చెల్లించారు
    (rf"ినాడు(?![{TE_BLOCK}])", "ాడు"),
    (rf"ినది(?![{TE_BLOCK}])", "ింది"),                               # చెందినది -> చెందింది
    (rf"బడును(?![{TE_BLOCK}])", "బడుతుంది"),                          # ఇవ్వబడును -> ఇవ్వబడుతుంది
    (rf"వచ్చును(?![{TE_BLOCK}])", "వచ్చు"),                           # చేయవచ్చును -> చేయవచ్చు
    (rf"(?<=[{TE_CONSONANT}])రాదు(?![{TE_BLOCK}])", "కూడదు"),          # చేయరాదు -> చేయకూడదు
    (rf"(?<![{TE_BLOCK}])కలదు(?![{TE_BLOCK}])", "ఉంది"),
    (rf"(?<![{TE_BLOCK}])గలదు(?![{TE_BLOCK}])", "ఉంది"),
    (rf"(?<![{TE_BLOCK}])కలవు(?![{TE_BLOCK}])", "ఉన్నాయి"),
    (rf"(?<![{TE_BLOCK}])గల(?![{TE_BLOCK}])", "ఉన్న"),
    (rf"(?<=[{TE_CONSONANT}])మునకు(?![{TE_BLOCK}])", "ానికి"),         # కార్యాలయమునకు -> కార్యాలయానికి
    (rf"(?<=[{TE_CONSONANT}])మును(?![{TE_BLOCK}])", "ాన్ని"),           # గృహమును -> గృహాన్ని
    (rf"(?<=[{TE_CONSONANT}])ములు(?![{TE_BLOCK}])", "ాలు"),            # గజములు -> గజాలు
    (rf"(?<=[{TE_CONSONANT}])ముల(?![{TE_BLOCK}])", "ాల"),
    (rf"(?<=[{TE_CONSONANT}])మున(?![{TE_BLOCK}])", "ంలో"),             # కాలమున -> కాలంలో
    (rf"(?<=[{TE_CONSONANT}])ము(?![{TE_BLOCK}])", "ం"),                # పత్రము -> పత్రం
]
_TE_SUFFIX_COMPILED = [(re.compile(p), r) for p, r in TE_SUFFIX_RULES]

# Short inline meanings added after the first occurrence of difficult Telugu legal terms
TE_INLINE_GLOSS = {
    "క్రయధనం": "అమ్మకపు ధర",
    "ధరావతు": "సెక్యూరిటీ డిపాజిట్",
    "చతుస్సీమలు": "నాలుగు వైపుల హద్దులు",
    "తనఖా": "అప్పుకు హామీగా ఆస్తి పెట్టడం",
    "దస్తావేజు": "అధికారిక పత్రం",
    "విక్రయదారుడు": "అమ్మేవారు",
    "ఖరీదుదారుడు": "కొనేవారు",
    "కౌలుదారు": "అద్దెకు తీసుకునేవారు",
    "స్థిరాస్తి": "ఇల్లు / భూమి",
    "జప్తు": "స్వాధీనం చేసుకోవడం",
}


def simplify_telugu_sentence(sentence: str, glossed: set) -> Tuple[List[str], int]:
    """Rewrite one Telugu legal sentence into modern spoken Telugu."""
    s = sentence
    changes = 0
    for old, new in TE_PHRASE_RULES:
        if old in s:
            changes += s.count(old)
            s = s.replace(old, new)
    for pattern, repl in _TE_SUFFIX_COMPILED:
        s, n = pattern.subn(repl, s)
        changes += n
    for term, meaning in TE_INLINE_GLOSS.items():
        if term in s and term not in glossed and meaning not in s:
            s = s.replace(term, f"{term} ({meaning})", 1)
            glossed.add(term)
            changes += 1
    s = re.sub(r"\s{2,}", " ", s)
    s = re.sub(r"\s+([,\.\)])", r"\1", s).strip()
    s = re.sub(r"[;,\s]+$", "", s)
    if s and not re.search(r"[\.\!\?।:]$", s):
        s += "."
    return [s], changes


def simplify_sentence(sentence: str, glossed: set) -> Tuple[List[str], int]:
    """Apply Telugu rules to Telugu script and English rules to Latin script (mixed lines get both)."""
    has_te = bool(TE_CHAR_RE.search(sentence))
    has_en = len(re.findall(r"[A-Za-z]{2,}", sentence)) >= 3
    if has_te and not has_en:
        return simplify_telugu_sentence(sentence, glossed)
    if has_en and not has_te:
        return simplify_english_sentence(sentence)
    if has_te and has_en:
        en_out, n1 = simplify_english_sentence(sentence)
        out, total = [], n1
        for part in en_out:
            te_out, n2 = simplify_telugu_sentence(part, glossed)
            out.extend(te_out)
            total += n2
        return out, total
    return [sentence.strip()], 0


def simplify_passage(text: str, glossed: set = None) -> Tuple[List[str], int]:
    """Simplify every sentence of a passage; returns (sentences, total rewrites)."""
    glossed = glossed if glossed is not None else set()
    out: List[str] = []
    total = 0
    for sent in split_sentences(text):
        if is_noise_sentence(sent):
            continue
        simp, n = simplify_sentence(sent, glossed)
        out.extend(simp)
        total += n
    return out, total


# ----------------------------------------------------------------------------------------
# 3. Extractive summarization (TextRank over TF-IDF vectors)
# ----------------------------------------------------------------------------------------

_INFO_PATTERNS = [
    r"\d",
    r"\b(?:shall|must|agree|agrees|pay|payable|rent|deposit|terminate|notice|liable|confidential|price|consideration|sell|transfer|declare)\b",
    r"(?:అద్దె|చెల్లించ|డిపాజిట్|ధరావతు|రద్దు|నోటీసు|విక్రయ|క్రయధనం|హక్కు|వలెను|ాలి)",
]
_LOW_VALUE_PATTERNS = [
    r"^\s*(?:witness|witnesses|సాక్షులు)",
    r"in witness whereof|to confirm this,|signed this agreement|సంతకాలు చేసి",
    r"^\s*\d+\.\s*[A-Z]\.\s*[A-Za-z]+,\s*[A-Za-z]+",   # "1. P. Ramesh, Whitefield"
    r"అని పిలుస్తారు|అని పిలువబడును|^\(?\s*called the\b",  # definition-only sentences
]
# Everything after the signature / witness marker is attestation, not content
_SIGNATURE_MARKERS = r"in witness whereof|to confirm this,|^witnesses|సాక్షుల సమక్షంలో|సంతకాలు చేస|^సాక్షులు"


def textrank_scores(sentences: List[str]) -> np.ndarray:
    """PageRank over a cosine-similarity graph of character n-gram TF-IDF vectors."""
    n = len(sentences)
    if n == 0:
        return np.array([])
    if n == 1:
        return np.array([1.0])
    vec = TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 4), sublinear_tf=True)
    try:
        matrix = vec.fit_transform(sentences)
    except ValueError:
        return np.ones(n) / n
    sim = cosine_similarity(matrix)
    np.fill_diagonal(sim, 0.0)
    row_sums = sim.sum(axis=1, keepdims=True)
    row_sums[row_sums == 0] = 1.0
    transition = sim / row_sums
    scores = np.ones(n) / n
    damping = 0.85
    for _ in range(60):
        new_scores = (1 - damping) / n + damping * transition.T.dot(scores)
        if np.abs(new_scores - scores).sum() < 1e-6:
            scores = new_scores
            break
        scores = new_scores
    return scores


def summarize(sentences: List[str], max_sentences: int = 5) -> List[int]:
    """Return indices (in document order) of the most informative sentences."""
    if not sentences:
        return []
    base = textrank_scores(sentences)
    signature_start = next(
        (i for i, s in enumerate(sentences) if i > len(sentences) // 2 and re.search(_SIGNATURE_MARKERS, s, re.IGNORECASE)),
        len(sentences),
    )
    scores = []
    for i, s in enumerate(sentences):
        score = float(base[i])
        if i >= signature_start:
            score *= 0.05
        if any(re.search(p, s, re.IGNORECASE) for p in _INFO_PATTERNS):
            score *= 1.6
        if re.search(r"(?:Rs\.?|INR|రూ|\$)\s*\d", s):
            score *= 1.4
        if any(re.search(p, s, re.IGNORECASE) for p in _LOW_VALUE_PATTERNS):
            score *= 0.2
        # Party introductions (father's name, age, address) are already shown under Key Facts
        if re.search(r"తండ్రి\s*:|వయస్సు\s*:|నివాసం\s*:|\bson of\b|\bdaughter of\b|\bwife of\b|\baged\b|\bliving at\b|\bregistered office\b", s, re.IGNORECASE):
            score *= 0.35
        if is_heading_line(s):
            score *= 0.1
        words = len(s.split())
        if words < 6:
            score *= 0.4
        scores.append(score)
    order = np.argsort(scores)[::-1]
    chosen: List[int] = []
    for idx in order:
        if len(chosen) >= max_sentences:
            break
        # Avoid near-duplicate sentences in the summary
        if any(_overlap(sentences[idx], sentences[c]) > 0.7 for c in chosen):
            continue
        chosen.append(int(idx))
    return sorted(chosen)


def _overlap(a: str, b: str) -> float:
    wa, wb = set(re.findall(r"\w+", a.lower())), set(re.findall(r"\w+", b.lower()))
    if not wa or not wb:
        return 0.0
    return len(wa & wb) / min(len(wa), len(wb))


# ----------------------------------------------------------------------------------------
# 4. Obligations / rights / prohibitions per party
# ----------------------------------------------------------------------------------------

PARTY_TERMS_EN = [
    ("Tenant", r"\b(?:lessee|tenant|licensee)\b"),
    ("Landlord", r"\b(?:lessor|landlord|licensor|owner)\b"),
    ("Buyer", r"\b(?:purchaser|buyer|vendee)\b"),
    ("Seller", r"\b(?:vendor|seller)\b"),
    ("Receiving Party", r"\breceiving party\b|\brecipient\b"),
    ("Disclosing Party", r"\bdisclosing party\b"),
    ("Employee", r"\b(?:employee|consultant|contractor)\b"),
    ("Employer", r"\b(?:employer|company)\b"),
    ("Deponent", r"\b(?:deponent|declarant|i|person making this statement)\b"),
    ("Both parties", r"\b(?:either party|both parties|each party|the parties|parties)\b"),
]
PARTY_TERMS_TE = [
    ("అద్దెదారు", r"(?:అద్దెదారు|కౌలుదారు|రెండవ పక్షం)"),
    ("యజమాని", r"(?:యజమాని|మొదటి పక్షం)"),
    ("కొనుగోలుదారు", r"(?:కొనుగోలుదారు|ఖరీదుదారు|వ్రాయించుకున్న|రాయించుకున్న)"),
    ("విక్రయదారు", r"(?:విక్రయదారు|అమ్మకందారు|అమ్మేవారు)"),
    ("ఇరు పక్షాలు", r"(?:ఇరు పక్షా|ఉభయ|ఎవరైనా|ఇద్దరి)"),
]

EN_PROHIBITION = r"\b(?:must not|shall not|may not|cannot|is not allowed to|prohibited)\b"
EN_RIGHT = r"\b(?:may|has the right to|have the right to|is entitled to|reserves the right|will be entitled)\b"
EN_OBLIGATION = r"\b(?:must|shall|agrees? to|undertakes? to|is required to|is responsible for|will pay|has to|are to)\b"
TE_PROHIBITION = r"(?:కూడదు|రాదు|నిషేధ|వీలులేదు|వీల్లేదు)"
TE_RIGHT = r"(?:హక్కు|వచ్చు|అధికారం)"
TE_OBLIGATION = r"(?:ాలి(?![ఀ-౿])|వలెను|ాల్సి|బాధ్యత)"


def _find_party(sentence: str, lang: str) -> str:
    terms = PARTY_TERMS_TE if lang == "te" else PARTY_TERMS_EN
    if lang == "en":
        # English (SVO): the subject is the party mentioned closest before the modal verb
        modal = re.search(EN_OBLIGATION + "|" + EN_RIGHT + "|" + EN_PROHIBITION, sentence, re.IGNORECASE)
        zone = sentence[: modal.start()] if modal else sentence
        best = None
        for label, pat in terms:
            for m in re.finditer(pat, zone, re.IGNORECASE):
                if best is None or m.start() > best[1]:
                    best = (label, m.start())
    else:
        # Telugu (SOV): the subject comes first, after any leading conditional clause ("...చేస్తే,")
        zone = re.split(r"(?:తే|చో|అయితే|కపోతే),\s*", sentence)[-1]
        best = None
        for label, pat in terms:
            m = re.search(pat, zone)
            if m and (best is None or m.start() < best[1]):
                best = (label, m.start())
    if best:
        return best[0]
    for label, pat in terms:
        if re.search(pat, sentence, re.IGNORECASE):
            return label
    return "ఇతర నిబంధనలు" if lang == "te" else "General"


def extract_duties(simplified_sentences: List[str]) -> Dict[str, Dict[str, List[str]]]:
    """Group sentences into obligations, rights and prohibitions per party."""
    result: Dict[str, Dict[str, List[str]]] = {}
    for s in simplified_sentences:
        if is_heading_line(s) or len(s.split()) < 5:
            continue
        lang = sentence_language(s)
        if lang == "te":
            kind = "prohibition" if re.search(TE_PROHIBITION, s) else "right" if re.search(TE_RIGHT, s) else "obligation" if re.search(TE_OBLIGATION, s) else None
        else:
            kind = (
                "prohibition" if re.search(EN_PROHIBITION, s, re.IGNORECASE)
                else "obligation" if re.search(EN_OBLIGATION, s, re.IGNORECASE)
                else "right" if re.search(EN_RIGHT, s, re.IGNORECASE)
                else None
            )
        if not kind:
            continue
        party = _find_party(s, lang)
        bucket = result.setdefault(party, {"obligation": [], "right": [], "prohibition": []})
        if s not in bucket[kind]:
            bucket[kind].append(s)
    return result


# ----------------------------------------------------------------------------------------
# 5. Readability statistics
# ----------------------------------------------------------------------------------------

def _syllables(word: str) -> int:
    word = word.lower()
    groups = re.findall(r"[aeiouy]+", word)
    count = len(groups)
    if word.endswith("e") and count > 1:
        count -= 1
    return max(count, 1)


def readability_stats(sentences: List[str]) -> Dict[str, float]:
    """Average sentence length and (for English) Flesch Reading Ease."""
    sentences = [s for s in sentences if s.strip()]
    if not sentences:
        return {"sentences": 0, "avg_words_per_sentence": 0.0, "flesch_reading_ease": None}
    words = [w for s in sentences for w in re.findall(rf"[A-Za-z{TE_BLOCK}]+", s)]
    avg_len = len(words) / len(sentences)
    en_words = [w for w in words if re.match(r"[A-Za-z]", w)]
    flesch = None
    if en_words and len(en_words) >= 0.6 * len(words):
        syll = sum(_syllables(w) for w in en_words) / len(en_words)
        flesch = round(206.835 - 1.015 * avg_len - 84.6 * syll, 1)
    return {
        "sentences": len(sentences),
        "avg_words_per_sentence": round(avg_len, 1),
        "flesch_reading_ease": flesch,
    }

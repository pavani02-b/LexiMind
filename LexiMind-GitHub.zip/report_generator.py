"""
LexiMind Report Generator
Generates downloadable plain text (.txt), Markdown (.md), DOCX (.docx), and PDF (.pdf) documents.
Supports primary same-language simplified document, side-by-side comparison, and optional bilingual reports.
Telugu PDF text is shaped with HarfBuzz (uharfbuzz) so vowel signs and conjuncts render correctly.
"""

import io
import os
import re
from typing import Dict, Any, Optional, List
import docx
from docx.shared import Pt, RGBColor
from docx.oxml import parse_xml
from docx.oxml.ns import nsdecls

from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

from config import LEGAL_SAFETY_DISCLAIMER, TELUGU_FONT_PATH


# Register Telugu Font for ReportLab if available
TELUGU_FONT_REGISTERED = False
PDF_FONT_NAME = "Helvetica"

if TELUGU_FONT_PATH and os.path.isfile(TELUGU_FONT_PATH):
    try:
        if TELUGU_FONT_PATH.lower().endswith(".ttc"):
            pdfmetrics.registerFont(TTFont("TeluguFont", TELUGU_FONT_PATH, subfontIndex=0))
        else:
            pdfmetrics.registerFont(TTFont("TeluguFont", TELUGU_FONT_PATH))
        TELUGU_FONT_REGISTERED = True
        PDF_FONT_NAME = "TeluguFont"
    except Exception:
        TELUGU_FONT_REGISTERED = False

try:
    import uharfbuzz  # noqa: F401
    TELUGU_SHAPING_AVAILABLE = True
except ImportError:
    TELUGU_SHAPING_AVAILABLE = False

# Emoji and pictographs have no glyphs in Nirmala/Helvetica; they would print as black boxes
_EMOJI_RE = re.compile("[\U0001F000-\U0001FAFF☀-➿⬀-⯿️‍←-⇿⌀-⏿]")


def _strip_emoji(text: str) -> str:
    text = text.replace("→", "->").replace("↔", "<->")
    return re.sub(r"\s{2,}", " ", _EMOJI_RE.sub("", text)).strip()


def _strip_inline_md(text: str) -> str:
    """Remove markdown emphasis markers while keeping the words."""
    text = re.sub(r"\*\*(.+?)\*\*", r"\1", text)
    text = re.sub(r"(?<!\w)\*(.+?)\*(?!\w)", r"\1", text)
    text = re.sub(r"(?<!\w)_(.+?)_(?!\w)", r"\1", text)
    return text.replace("`", "")


def _parse_markdown_lines(md: str) -> List[Dict[str, str]]:
    """Turn the simplified markdown into typed blocks: heading / bullet / quote / text."""
    blocks = []
    for raw in md.split("\n"):
        line = raw.rstrip()
        if not line.strip():
            continue
        stripped = line.strip()
        m = re.match(r"^(#{1,6})\s+(.*)", stripped)
        if m:
            blocks.append({"type": "heading", "level": str(len(m.group(1))), "text": _strip_inline_md(m.group(2))})
        elif re.match(r"^[\*\-•]\s+", stripped):
            indent = "2" if line.startswith(("  ", "\t")) else "1"
            blocks.append({"type": "bullet", "level": indent, "text": _strip_inline_md(re.sub(r"^[\*\-•]\s+", "", stripped))})
        elif stripped.startswith(">"):
            blocks.append({"type": "quote", "level": "1", "text": _strip_inline_md(stripped.lstrip("> ").strip())})
        elif re.fullmatch(r"-{3,}", stripped):
            continue
        else:
            blocks.append({"type": "text", "level": "1", "text": _strip_inline_md(stripped)})
    return blocks


def _format_value(v: Any) -> str:
    """Readable text for extracted values (lists of party dicts, nested dicts, strings)."""
    if isinstance(v, list):
        parts = []
        for item in v:
            if isinstance(item, dict) and "name" in item:
                parts.append(f"{item['name']} ({item.get('role', '')})".replace(" ()", ""))
            else:
                parts.append(str(item))
        return "; ".join(parts)
    if isinstance(v, dict):
        return "; ".join(f"{k}: {val}" for k, val in v.items() if str(val) != "Not found") or "Not found"
    return str(v)


def _risk_lines(risk_data: Optional[Dict[str, Any]]) -> List[Dict[str, str]]:
    if not risk_data or not risk_data.get("flagged_risks"):
        return []
    return [
        {
            "title": f"{r['category']} ({r.get('severity_label', r['severity'])})",
            "passage": r["source_passage"],
            "explanation": r["plain_explanation"],
            "suggestion": r["suggestion"],
        }
        for r in risk_data["flagged_risks"]
    ]


def generate_txt_report(
    filename: str,
    original_text: str,
    simplified_text: str,
    source_lang_name: str,
    key_details: Optional[Dict[str, Any]] = None,
    risk_data: Optional[Dict[str, Any]] = None,
    translated_text: Optional[str] = None
) -> bytes:
    """Generate a clean plain text report (.txt)."""
    lines = []
    lines.append("=" * 80)
    lines.append("LEXIMIND: AI LEGAL DOCUMENT SIMPLIFICATION SYSTEM")
    lines.append("=" * 80)
    lines.append(f"Document Filename: {filename}")
    lines.append(f"Source Language  : {source_lang_name}")
    lines.append("Generated Mode   : Primary Same-Language Simplification")
    lines.append("=" * 80)
    lines.append("")
    lines.append(LEGAL_SAFETY_DISCLAIMER)
    lines.append("")
    lines.append("-" * 80)
    lines.append("1. SIMPLIFIED LEGAL EXPLANATION (SAME LANGUAGE)")
    lines.append("-" * 80)
    for b in _parse_markdown_lines(simplified_text):
        if b["type"] == "heading":
            lines.append("")
            lines.append(b["text"].upper() if b["text"].isascii() else b["text"])
        elif b["type"] == "bullet":
            lines.append(("    - " if b["level"] == "2" else "  • ") + b["text"])
        elif b["type"] == "quote":
            lines.append(f"      \"{b['text']}\"")
        else:
            lines.append(b["text"])
    lines.append("")

    if translated_text:
        lines.append("-" * 80)
        lines.append("2. OPTIONAL TRANSLATION & EXPLANATION")
        lines.append("-" * 80)
        lines.extend(b["text"] for b in _parse_markdown_lines(translated_text))
        lines.append("")

    if key_details:
        lines.append("-" * 80)
        lines.append("3. EXTRACTED CONTRACTUAL DETAILS")
        lines.append("-" * 80)
        for k, v in key_details.items():
            if isinstance(v, dict):
                lines.append(f"• {k}:")
                for sub_k, sub_v in v.items():
                    lines.append(f"    - {sub_k}: {sub_v}")
            else:
                lines.append(f"• {k}: {_format_value(v)}")
        lines.append("")

    risks = _risk_lines(risk_data)
    if risks:
        lines.append("-" * 80)
        lines.append("4. POTENTIAL RISK & REVIEW HIGHLIGHTS")
        lines.append("-" * 80)
        for idx, risk in enumerate(risks, start=1):
            lines.append(f"[{idx}] {risk['title']}")
            lines.append(f"     Source Passage : {risk['passage']}")
            lines.append(f"     Explanation    : {risk['explanation']}")
            lines.append(f"     Suggestion     : {risk['suggestion']}")
            lines.append("")

    lines.append("-" * 80)
    lines.append("5. ORIGINAL EXTRACTED DOCUMENT TEXT (PRESERVED FOR COMPARISON)")
    lines.append("-" * 80)
    lines.append(original_text)
    lines.append("")
    lines.append("=" * 80)
    lines.append("END OF REPORT")
    lines.append("=" * 80)

    return "\n".join(lines).encode("utf-8")


def generate_markdown_report(
    filename: str,
    original_text: str,
    simplified_text: str,
    source_lang_name: str,
    key_details: Optional[Dict[str, Any]] = None,
    risk_data: Optional[Dict[str, Any]] = None,
    translated_text: Optional[str] = None
) -> bytes:
    """Generate a GitHub-flavored Markdown report (.md)."""
    md = []
    md.append("# ⚖️ LexiMind: Legal Document Simplification Report\n")
    md.append(f"**Document:** `{filename}` | **Source Language:** {source_lang_name}\n")
    md.append(f"> ⚠️ **Legal Disclaimer:** {LEGAL_SAFETY_DISCLAIMER}\n")
    md.append("\n---\n")

    md.append("## 📄 1. Simplified Document (Same Language)\n")
    md.append(simplified_text)
    md.append("\n\n---\n")

    if translated_text:
        md.append("## 🌐 2. Optional Translation / Explanation\n")
        md.append(translated_text)
        md.append("\n\n---\n")

    if key_details:
        md.append("## 📌 3. Key Extracted Contract Details\n")
        for k, v in key_details.items():
            if isinstance(v, dict):
                md.append(f"- **{k}:**")
                for sub_k, sub_v in v.items():
                    md.append(f"  - *{sub_k}:* {sub_v}")
            else:
                md.append(f"- **{k}:** {_format_value(v)}")
        md.append("\n---\n")

    risks = _risk_lines(risk_data)
    if risks:
        md.append("## ⚠️ 4. Potential Risk Flags & Recommendations\n")
        for idx, risk in enumerate(risks, start=1):
            md.append(f"### {idx}. {risk['title']}")
            md.append(f"> **Source Passage:** *\"{risk['passage']}\"*\n")
            md.append(f"- **Plain Meaning:** {risk['explanation']}")
            md.append(f"- **Actionable Review Advice:** {risk['suggestion']}\n")
        md.append("\n---\n")

    md.append("## 🔍 5. Original Extracted Document (Preserved for Verification)\n")
    md.append("```text\n" + original_text + "\n```\n")

    return "\n".join(md).encode("utf-8")


def _docx_add_markdown(doc, md_text: str):
    for b in _parse_markdown_lines(md_text):
        if b["type"] == "heading":
            level = 2 if b["level"] in ("1", "2", "3") else 3
            h = doc.add_heading(level=level)
            run = h.add_run(b["text"])
            run.font.color.rgb = RGBColor(30, 58, 138)
        elif b["type"] == "bullet":
            p = doc.add_paragraph(b["text"], style="List Bullet 2" if b["level"] == "2" else "List Bullet")
            p.paragraph_format.space_after = Pt(2)
        elif b["type"] == "quote":
            p = doc.add_paragraph()
            r = p.add_run(f"“{b['text']}”")
            r.italic = True
            r.font.color.rgb = RGBColor(71, 85, 105)
            p.paragraph_format.left_indent = Pt(24)
        else:
            p = doc.add_paragraph(b["text"])
            p.paragraph_format.space_after = Pt(4)


def generate_docx_report(
    filename: str,
    original_text: str,
    simplified_text: str,
    source_lang_name: str,
    key_details: Optional[Dict[str, Any]] = None,
    risk_data: Optional[Dict[str, Any]] = None,
    translated_text: Optional[str] = None
) -> bytes:
    """Generate a professionally styled Microsoft Word document (.docx)."""
    doc = docx.Document()

    title = doc.add_paragraph()
    run_title = title.add_run("LexiMind: Legal Document Simplification")
    run_title.font.name = "Calibri"
    run_title.font.size = Pt(22)
    run_title.font.bold = True
    run_title.font.color.rgb = RGBColor(30, 58, 138)

    sub = doc.add_paragraph()
    sub_run = sub.add_run(f"Document: {filename}  |  Language: {source_lang_name}")
    sub_run.font.italic = True
    sub_run.font.size = Pt(11)
    sub_run.font.color.rgb = RGBColor(100, 116, 139)

    table_disc = doc.add_table(rows=1, cols=1)
    table_disc.autofit = True
    cell = table_disc.cell(0, 0)
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="FEF3C7"/>')
    cell._tc.get_or_add_tcPr().append(shd)
    disc_run = cell.paragraphs[0].add_run(f"DISCLAIMER: {LEGAL_SAFETY_DISCLAIMER}")
    disc_run.font.size = Pt(9.5)
    disc_run.font.color.rgb = RGBColor(146, 64, 14)

    doc.add_paragraph()

    h1 = doc.add_heading(level=1)
    h1.add_run("1. Simplified Document (Same-Language Explanation)").font.color.rgb = RGBColor(30, 58, 138)
    _docx_add_markdown(doc, simplified_text)

    if translated_text:
        h_trans = doc.add_heading(level=1)
        h_trans.add_run("2. Translated Explanation").font.color.rgb = RGBColor(30, 58, 138)
        _docx_add_markdown(doc, translated_text)

    if key_details:
        h2 = doc.add_heading(level=1)
        h2.add_run("3. Extracted Key Information").font.color.rgb = RGBColor(30, 58, 138)
        for k, v in key_details.items():
            p = doc.add_paragraph(style="List Bullet")
            p.add_run(f"{k}: ").bold = True
            if isinstance(v, dict):
                for sub_k, sub_v in v.items():
                    if str(sub_v) == "Not found":
                        continue
                    sub_p = doc.add_paragraph(style="List Bullet 2")
                    sub_p.add_run(f"{sub_k}: ").bold = True
                    sub_p.add_run(str(sub_v))
            else:
                p.add_run(_format_value(v))

    risks = _risk_lines(risk_data)
    if risks:
        h3 = doc.add_heading(level=1)
        h3.add_run("4. Potential Risk Flags").font.color.rgb = RGBColor(185, 28, 28)
        for risk in risks:
            p = doc.add_paragraph()
            p.add_run(f"• {risk['title']}\n").bold = True
            p.add_run(f"  Source Passage: \"{risk['passage']}\"\n")
            p.add_run(f"  Explanation: {risk['explanation']}\n")
            p.add_run(f"  Recommendation: {risk['suggestion']}")

    h4 = doc.add_heading(level=1)
    h4.add_run("5. Original Preserved Document Text").font.color.rgb = RGBColor(100, 116, 139)
    for p in original_text.split("\n"):
        if p.strip():
            p_elem = doc.add_paragraph(p.strip())
            p_elem.paragraph_format.line_spacing = 1.0
            p_elem.paragraph_format.space_after = Pt(2)

    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


def _pdf_escape(text: str) -> str:
    # '&' must be escaped first, otherwise '&lt;' becomes '&amp;lt;'
    return _strip_emoji(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def generate_pdf_report(
    filename: str,
    original_text: str,
    simplified_text: str,
    source_lang_name: str,
    key_details: Optional[Dict[str, Any]] = None,
    risk_data: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Generate a PDF report using ReportLab with Telugu Unicode support.
    If Telugu font is unavailable, returns a structured error instructing DOCX download.
    """
    has_telugu = any(0x0C00 <= ord(c) <= 0x0C7F for c in simplified_text + original_text)
    is_telugu = "telugu" in source_lang_name.lower() or has_telugu

    if is_telugu and not TELUGU_FONT_REGISTERED:
        return {
            "success": False,
            "pdf_bytes": b"",
            "error": (
                "A Telugu Unicode font (such as Nirmala.ttc or Gautami) could not be loaded into the PDF renderer. "
                "To guarantee faithful Telugu script rendering, please download the DOCX or TXT version."
            )
        }

    try:
        buf = io.BytesIO()
        doc = SimpleDocTemplate(buf, pagesize=A4, rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40,
                                title=f"LexiMind - {filename}")
        font_name = PDF_FONT_NAME if (is_telugu or TELUGU_FONT_REGISTERED) else "Helvetica"
        shaping = 1 if (font_name == "TeluguFont" and TELUGU_SHAPING_AVAILABLE) else 0

        def style(name, size, leading, color="#1E293B", **kw):
            return ParagraphStyle(name, fontName=font_name, fontSize=size, leading=leading,
                                  textColor=colors.HexColor(color), shaping=shaping, **kw)

        title_style = style("TitleStyle", 18, 24, "#1E3A8A", spaceAfter=8)
        sub_style = style("SubStyle", 10, 14, "#64748B", spaceAfter=12)
        body_style = style("BodyStyle", 10, 16, spaceAfter=4)
        bullet_style = style("BulletStyle", 10, 16, leftIndent=14, bulletIndent=4, spaceAfter=3)
        bullet2_style = style("Bullet2Style", 9.5, 15, leftIndent=28, bulletIndent=18, spaceAfter=2)
        quote_style = style("QuoteStyle", 9.5, 15, "#475569", leftIndent=24, spaceAfter=4)
        h1_style = style("H1Style", 13, 18, "#1E3A8A", spaceBefore=12, spaceAfter=6)
        h2_style = style("H2Style", 11.5, 16, "#1E3A8A", spaceBefore=8, spaceAfter=4)
        disclaimer_style = style("DisclaimerStyle", 8.5, 12, "#92400E", backColor=colors.HexColor("#FEF3C7"),
                                 borderPadding=6, spaceAfter=10)

        story = [
            Paragraph("LexiMind: Legal Document Simplification", title_style),
            Paragraph(_pdf_escape(f"Document: {filename} | Language: {source_lang_name}"), sub_style),
            Paragraph(_pdf_escape(LEGAL_SAFETY_DISCLAIMER), disclaimer_style),
            Spacer(1, 10),
            Paragraph("1. Simplified Document (Same Language)", h1_style),
        ]

        for b in _parse_markdown_lines(simplified_text):
            text = _pdf_escape(b["text"])
            if not text:
                continue
            if b["type"] == "heading":
                story.append(Paragraph(text, h2_style))
            elif b["type"] == "bullet":
                story.append(Paragraph(text, bullet2_style if b["level"] == "2" else bullet_style, bulletText="•"))
            elif b["type"] == "quote":
                story.append(Paragraph(f"“{text}”", quote_style))
            else:
                story.append(Paragraph(text, body_style))

        if key_details:
            story.append(Paragraph("2. Key Extracted Information", h1_style))
            for k, v in key_details.items():
                story.append(Paragraph(f"<b>{_pdf_escape(k)}:</b> {_pdf_escape(_format_value(v))}", body_style))

        risks = _risk_lines(risk_data)
        if risks:
            story.append(Paragraph("3. Potential Risk Flags", h1_style))
            for r in risks:
                story.append(Paragraph(f"<b>{_pdf_escape(r['title'])}</b>", body_style))
                story.append(Paragraph(f"“{_pdf_escape(r['passage'])}”", quote_style))
                story.append(Paragraph(_pdf_escape(r["explanation"]), bullet_style, bulletText="•"))
                story.append(Paragraph(_pdf_escape(r["suggestion"]), bullet_style, bulletText="•"))

        doc.build(story)
        return {"success": True, "pdf_bytes": buf.getvalue(), "error": None}
    except Exception as e:
        return {
            "success": False,
            "pdf_bytes": b"",
            "error": f"PDF generation error: {str(e)}. Please download the DOCX or TXT version."
        }

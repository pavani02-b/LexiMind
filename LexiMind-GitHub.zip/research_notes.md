# 📚 LexiMind: Research Notes & Academic Literature References

This document outlines genuine academic research, peer-reviewed publications, open-access datasets, and benchmark corpora relevant to legal NLP, contract intelligence, Indic language processing, and document simplification.

---

## 1. Relevant Benchmark Corpora & Datasets

### 1.1 CUAD (Contract Understanding Atticus Dataset)
- **Authors**: Dan Hendrycks, Collin Burns, Anya Chen, Spencer Ball, et al.
- **Publication**: *Thirty-fifth Conference on Neural Information Processing Systems (NeurIPS) Datasets and Benchmarks Track*, 2021.
- **Overview**: CUAD is a corpus of 510 commercial legal contracts with over 13,000 expert annotations across 41 contract categories (including Unilateral Termination, Non-Compete, Governing Law, Indemnification, and Uncapped Liability).
- **Relevance to LexiMind**: Provided the taxonomy for clause categorization and informed the risk heuristics implemented in `risk_analyzer.py` (specifically identifying one-sided termination and uncapped indemnity patterns).

### 1.2 ContractNLI: A Dataset for Document-level Natural Language Inference for Contracts
- **Authors**: Yuta Koreeda, Christopher D. Manning.
- **Publication**: *Findings of the Association for Computational Linguistics (EMNLP)*, 2021.
- **Overview**: A dataset designed for document-level natural language inference in non-disclosure agreements (NDAs). Explores whether specific obligations or rights are entailed, contradicted, or not mentioned.
- **Relevance to LexiMind**: Guided the design of LexiMind's grounded RAG QA engine (`rag_engine.py`), reinforcing the principle that unmentioned facts must be explicitly reported as *"not found"* rather than inferred.

### 1.3 LegalBench: A Collaboratively Built Benchmark for Measuring Legal Reasoning in Large Language Models
- **Authors**: Neel Guha, Julian Nyarko, Daniel E. Ho, Christopher Ré, et al.
- **Publication**: *NeurIPS Datasets and Benchmarks Track*, 2023.
- **Overview**: An interdisciplinary benchmark comprising 162 tasks covering issue-spotting, rule application, contract interpretation, and clause classification across multiple jurisdictions.
- **Relevance to LexiMind**: Provided evaluation methodologies for zero-shot and few-shot legal simplification and extraction tasks.

### 1.4 ILDC (Indian Legal Documents Corpus)
- **Authors**: Vijit Malik, Rishabh Sanjay, Shubham Kumar Nigam, Kripabandhu Ghosh, et al.
- **Publication**: *Proceedings of the 59th Annual Meeting of the Association for Computational Linguistics (ACL)*, 2021.
- **Overview**: A corpus of Indian legal cases annotated with judicial outcomes and court proceedings, addressing the linguistic characteristics of Indian legal writing.
- **Relevance to LexiMind**: Informed the entity extraction logic in `clause_analyzer.py` regarding Indian registration numbers, sub-registrar citations, and stamp duty conventions.

---

## 2. Indic NLP & Telugu Language Resources

### 2.1 AI4Bharat & IndicBERT / IndicTrans
- **Authors**: Anoop Kunchukuttan, Divyanshu Kakwani, Satish Golla, et al.
- **Organizations**: AI4Bharat, IIT Madras, Centre for Development of Advanced Computing (C-DAC).
- **Publication**: *Findings of EMNLP*, 2020 / *Transactions of the Association for Computational Linguistics (TACL)*, 2022.
- **Overview**: Open-source models and resources for 22 scheduled Indian languages, establishing tokenization, morphological analysis, and multilingual embeddings for Telugu and neighboring Dravidian languages.
- **Relevance to LexiMind**: Highlighted the importance of preserving Unicode script ranges (`\u0C00-\u0C7F`) and avoiding lossy transliteration in document processing workflows.

### 2.2 Tesseract Telugu OCR Data (`tel.traineddata`)
- **Maintainers**: Ray Smith, Google Open Source, and the Tesseract Community.
- **Repository**: `github.com/tesseract-ocr/tessdata`
- **Relevance to LexiMind**: Provides the LSTM neural network weights used by Tesseract for optical character recognition of Telugu glyphs and conjunct consonants (*vottulu* and *guninthalu*).

---

## 3. Plain Language & Legal Simplification Literature

### 3.1 The Plain Language Movement in Law
- **Authors**: Joseph Kimble.
- **Publication**: *Lifting the Fog of Legalese: Essays on Plain Language*, Carolina Academic Press, 2006.
- **Key Finding**: Demonstrates empirically that drafting legal documents in clear, modern prose reduces reader processing time by over 30%, decreases drafting errors, and eliminates ambiguities that lead to civil litigation.
- **Relevance to LexiMind**: Forms the primary pedagogical justification for LexiMind's core feature: converting complex legalese into plain language while strictly maintaining legal meaning, obligations, and party identities.

### 3.2 Evaluation Metrics for Legal Text Simplification
- **Key Metrics in Literature**: SARI (System output Against References and against the Input sentence), FKGL (Flesch-Kincaid Grade Level), and factual entailment accuracy.
- **Academic Context**: In academic evaluations, automated simplification systems are evaluated on two axes: (1) *Readability improvement* (reduction in sentence length and syntactic complexity) and (2) *Factual fidelity* (zero omission of material rights or introduction of hallucinations).

---

*Note: LexiMind references these genuine datasets and research papers to ground its design. No benchmark scores or claims of training are fabricated.*

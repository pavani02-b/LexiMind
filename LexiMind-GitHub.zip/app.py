"""
LexiMind: AI-Powered Legal Document Simplification and Intelligent Contract Analysis System
Streamlit Main Application
"""

import html
import os
import re
from pathlib import Path

import streamlit as st

# Configure Streamlit page settings
st.set_page_config(
    page_title="LexiMind — Legal Document Simplifier",
    page_icon="⚖️",
    layout="wide",
    initial_sidebar_state="expanded"
)

from config import (
    GEMINI_API_KEY,
    OPENAI_API_KEY,
    GEMINI_MODEL,
    OPENAI_MODEL,
    AI_TIMEOUT_SECONDS,
    LEGAL_SAFETY_DISCLAIMER,
)
from document_processor import (
    process_uploaded_document,
    get_ocr_diagnostics,
    DocumentProcessingError
)
from language_processor import (
    detect_document_language,
    simplify_legal_document
)
from clause_analyzer import analyze_document_clauses
from risk_analyzer import highlight_potential_risks
from rag_engine import DocumentRAGEngine
from report_generator import (
    generate_txt_report,
    generate_markdown_report,
    generate_docx_report,
    generate_pdf_report,
    TELUGU_FONT_REGISTERED,
    TELUGU_SHAPING_AVAILABLE
)
from text_simplifier import simplify_passage

BASE_DIR = Path(__file__).resolve().parent

# Custom Styling (cards set their own text colour so they stay readable in Streamlit's dark theme)
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(135deg, #0F172A 0%, #1E3A8A 50%, #2563EB 100%);
        padding: 24px 30px;
        border-radius: 12px;
        color: white;
        margin-bottom: 25px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    .main-header h1 { color: #F8FAFC; font-size: 2.2rem; font-weight: 700; margin-bottom: 6px; }
    .main-header p { color: #CBD5E1; font-size: 1.05rem; margin-bottom: 0px; }
    .badge-primary, .badge-success, .badge-warning {
        display: inline-block; color: white; padding: 4px 10px; border-radius: 6px;
        font-size: 0.82rem; font-weight: 600; margin-right: 6px;
    }
    .badge-primary { background-color: #3B82F6; }
    .badge-success { background-color: #10B981; }
    .badge-warning { background-color: #F59E0B; }
    .legal-card {
        background-color: #F8FAFC; color: #1E293B; border-left: 4px solid #2563EB;
        padding: 16px 20px; border-radius: 0 8px 8px 0; margin-bottom: 16px;
        border-top: 1px solid #E2E8F0; border-right: 1px solid #E2E8F0; border-bottom: 1px solid #E2E8F0;
    }
    .risk-high, .risk-medium, .risk-advisory {
        color: #1E293B; padding: 14px 18px; border-radius: 0 8px 8px 0; margin-bottom: 12px;
    }
    .risk-high { background-color: #FEF2F2; border-left: 4px solid #EF4444; }
    .risk-medium { background-color: #FFFBEB; border-left: 4px solid #F59E0B; }
    .risk-advisory { background-color: #F0FDF4; border-left: 4px solid #10B981; }
    .risk-high h4, .risk-medium h4, .risk-advisory h4 { color: #0F172A; }
    .original-box {
        background-color: #F1F5F9; color: #0F172A; padding: 16px; border-radius: 8px;
        max-height: 520px; overflow-y: auto; font-family: monospace; font-size: 0.88rem; white-space: pre-wrap;
    }
    /* Compact headings inside the simplified-output boxes */
    .st-key-simplified_box h4, .st-key-translated_box h4, .st-key-translated_box h3 { font-size: 1.2rem !important; padding-top: 0.2rem; }
    .st-key-simplified_box h5, .st-key-translated_box h5 { font-size: 1.02rem !important; padding-top: 0.6rem; }
    .disclaimer-box {
        background-color: #FFFBEB; border: 1px solid #FCD34D; border-radius: 8px;
        padding: 14px 18px; font-size: 0.85rem; color: #92400E; margin-top: 25px;
    }
</style>
""", unsafe_allow_html=True)


# Initialize Session State
DEFAULT_STATE = {
    "raw_text": "",
    "filename": "",
    "extraction_metadata": {},
    "simplification_results": None,
    "clause_results": None,
    "risk_results": None,
    "rag_engine": None,
    "processed_text": None,
    "last_uploaded_signature": None,
    "qa_history": [],
    "editor_version": 0,
}
for key, value in DEFAULT_STATE.items():
    if key not in st.session_state:
        st.session_state[key] = value


def reset_results():
    st.session_state.simplification_results = None
    st.session_state.clause_results = None
    st.session_state.risk_results = None
    st.session_state.rag_engine = None
    st.session_state.processed_text = None
    st.session_state.qa_history = []
    # New text => new editor widget, so the text area shows the new document
    st.session_state.editor_version += 1


# ==============================================================================
# SIDEBAR: System Diagnostics & Settings
# ==============================================================================
with st.sidebar:
    st.markdown("## ⚖️ LexiMind System")
    st.markdown("**Academic Capstone Project**")
    st.markdown("---")

    st.markdown("#### 🔌 Engine Status")
    ai_available = bool(GEMINI_API_KEY or OPENAI_API_KEY)
    use_ai = False
    if ai_available:
        engine_label = f"Gemini ({GEMINI_MODEL})" if GEMINI_API_KEY else f"OpenAI ({OPENAI_MODEL})"
        use_ai = st.toggle(
            f"Use {engine_label}",
            value=True,
            help=f"On: better wording, needs internet, can take up to {AI_TIMEOUT_SECONDS} s when the AI service is busy. "
                 "Off: instant offline NLP engine."
        )
        if use_ai:
            st.success(f"AI API: Active — {engine_label}")
            st.caption(f"If the AI does not answer within {AI_TIMEOUT_SECONDS} seconds, LexiMind uses the offline engine.")
        else:
            st.info("AI turned off — using the instant offline NLP engine.")
    else:
        st.info("AI API: Offline NLP Mode")
        st.caption(
            "No API key in `.env`. The offline engine rewrites the document's own sentences "
            "(legalese → plain words, archaic Telugu → spoken Telugu), summarizes with TextRank, "
            "and extracts obligations, amounts and dates."
        )

    ocr_diag = get_ocr_diagnostics()
    if ocr_diag["is_available"]:
        st.success(f"Tesseract OCR: v{ocr_diag['version']}")
        st.caption(f"Path: `{ocr_diag['executable_path']}`")
        if ocr_diag["has_telugu"]:
            st.markdown("<span class='badge-success'>Telugu OCR (tel): Ready</span>", unsafe_allow_html=True)
        else:
            st.markdown("<span class='badge-warning'>Telugu OCR: tel.traineddata missing</span>", unsafe_allow_html=True)
        if ocr_diag["has_english"]:
            st.markdown("<span class='badge-success'>English OCR (eng): Ready</span>", unsafe_allow_html=True)
        st.caption(f"Installed: {', '.join(ocr_diag['languages']) if ocr_diag['languages'] else 'none'}")
    else:
        st.warning("Tesseract OCR: Not Configured")
        st.caption("Scanned PDFs & images require Tesseract.")
        if ocr_diag.get("error_note"):
            st.caption(f"Note: {ocr_diag['error_note']}")

    if TELUGU_FONT_REGISTERED and TELUGU_SHAPING_AVAILABLE:
        st.markdown("<span class='badge-success'>Telugu PDF: Nirmala + HarfBuzz shaping</span>", unsafe_allow_html=True)
    elif TELUGU_FONT_REGISTERED:
        st.markdown("<span class='badge-warning'>Telugu PDF: install uharfbuzz for correct glyphs</span>", unsafe_allow_html=True)
    else:
        st.markdown("<span class='badge-warning'>Telugu PDF Font: Use DOCX</span>", unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("#### ⚙️ Simplification Settings")
    simplification_depth = st.radio(
        "Explanation Depth",
        ["Simple", "Detailed"],
        index=0,
        help="Simple: summary, key facts, duties and 1–2 lines per section. Detailed: every sentence of every section rewritten."
    )

    st.markdown("---")
    st.markdown("#### 🌐 Optional Translation")
    enable_translation = st.checkbox(
        "Enable Secondary Translation",
        value=False,
        help="By default LexiMind simplifies in the document's own language. Full translation needs an AI API key; offline mode translates the key-fact labels only."
    )
    translation_target = "en"
    if enable_translation:
        target_choice = st.selectbox("Translate Secondary Output To", ["English (en)", "Telugu (te)"], index=0)
        translation_target = "en" if "English" in target_choice else "te"


# Hero Banner
st.markdown("""
<div class="main-header">
    <h1>⚖️ LexiMind</h1>
    <p>AI-Powered Legal Document Simplification & Intelligent Contract Analysis System</p>
    <div style="margin-top: 10px;">
        <span class="badge-primary">Same-Language Simplification</span>
        <span class="badge-primary">Telugu & English Support</span>
        <span class="badge-primary">Verifiable Contract Extraction</span>
        <span class="badge-primary">Grounded RAG Q&A</span>
    </div>
</div>
""", unsafe_allow_html=True)


tab_main, tab_clauses, tab_risks, tab_qa, tab_glossary = st.tabs([
    "🚀 1. Upload & Simplify",
    "📑 2. Clause & Details Analysis",
    "⚠️ 3. Potential Risk Flags",
    "❓ 4. Document Q&A (RAG)",
    "📖 5. Legal Terms Glossary"
])


# ==============================================================================
# TAB 1: UPLOAD & SIMPLIFY (PRIMARY ACTION)
# ==============================================================================
SAMPLE_FILE_MAP = {
    "English Notarized Property Sale Agreement (నోటరీ విక్రయ ఒప్పందం)": "english_notary_sale_agreement.txt",
    "English Notarized Affidavit & Legal Declaration": "english_notary_affidavit.txt",
    "English Residential Lease & Rental Agreement": "english_rental_agreement.txt",
    "English Non-Disclosure Agreement (NDA)": "english_nda_agreement.txt",
    "Telugu Sada Bainama (సాదా బైనామా - ఖాళీ జాగా విక్రయపత్రం)": "telugu_sada_bainama.txt",
    "Telugu Residential Rental Agreement (అద్దె ఒప్పందం)": "telugu_rental_agreement.txt",
    "Telugu Land Sale Deed (స్థిరాస్తి విక్రయ దస్తావేజు)": "telugu_land_sale_deed.txt",
    "Mixed Telugu-English Commercial Lease": "mixed_telugu_english_contract.txt",
}

with tab_main:
    st.markdown("### 📤 Upload & Simplify Legal Document")
    st.markdown(
        "Upload any Telugu, English, or mixed legal document (PDF, Scanned PDF, DOCX, TXT, or Image). "
        "LexiMind will **simplify the legal language in its original language** by default."
    )

    col_upload, col_sample = st.columns([3, 2])

    with col_upload:
        st.markdown("**Upload Your Own Legal Document:**")
        st.caption("Supports Telugu, English, or Mixed PDF, Scanned PDF, DOCX, TXT, JPG, JPEG, and PNG.")
        uploaded_file = st.file_uploader(
            "Choose a Legal Document",
            type=["pdf", "docx", "txt", "png", "jpg", "jpeg"],
            help="Supports digital PDFs, scanned documents, Word documents, plain text, and photographs."
        )

    with col_sample:
        st.markdown("**Or Test With a Demonstration Document (Optional):**")
        st.caption("Select a sample document below and click 'Load Selected Demo Sample':")
        sample_choice = st.selectbox(
            "Select Demo Document (Optional)",
            ["-- Select a Demo Document --"] + list(SAMPLE_FILE_MAP.keys()),
            index=0
        )
        load_sample_btn = st.button("📂 Load Selected Demo Sample", width="stretch")

    current_upload_signature = f"{uploaded_file.name}_{uploaded_file.size}" if uploaded_file is not None else None

    if load_sample_btn:
        if sample_choice in SAMPLE_FILE_MAP:
            sample_path = BASE_DIR / "sample_documents" / SAMPLE_FILE_MAP[sample_choice]
            if sample_path.exists():
                sample_text = sample_path.read_text(encoding="utf-8")
                st.session_state.raw_text = sample_text
                st.session_state.filename = SAMPLE_FILE_MAP[sample_choice]
                st.session_state.extraction_metadata = {
                    "filename": SAMPLE_FILE_MAP[sample_choice],
                    "extraction_method": "synthetic_sample_txt",
                    "page_count": 1,
                    "pages": [{"page_number": 1, "text": sample_text, "method": "txt"}],
                    "word_count": len(sample_text.split()),
                    "char_count": len(sample_text),
                    "warnings": []
                }
                reset_results()
                # Mark the file still sitting in the uploader as "seen" so it does not overwrite the demo
                st.session_state.last_uploaded_signature = current_upload_signature
                st.success(f"Loaded demo sample: `{SAMPLE_FILE_MAP[sample_choice]}`")
        else:
            st.warning("Please choose a valid demo document from the dropdown first.")

    with st.expander("🛠️ OCR Diagnostics & System Setup Assistant", expanded=False):
        st.markdown("#### Tesseract Optical Character Recognition (OCR) Status")
        col_diag1, col_diag2, col_diag3 = st.columns(3)
        col_diag1.metric("Tesseract Engine", "Installed & Ready" if ocr_diag["is_available"] else "Not Detected")
        col_diag1.caption(f"Path: `{ocr_diag['executable_path']}`")
        col_diag2.metric("English OCR (eng)", "Available" if ocr_diag["has_english"] else "Missing")
        col_diag3.metric("Telugu OCR (tel)", "Available" if ocr_diag["has_telugu"] else "Missing")

        if not ocr_diag["is_available"]:
            st.warning("⚠️ **Tesseract OCR is required for scanned PDFs and image files (JPG, PNG).**")
            st.markdown("""
            **How to set up Tesseract OCR:**
            1. Download the Windows installer from **https://github.com/UB-Mannheim/tesseract/wiki**.
            2. During setup, on **'Choose Components'**, expand **'Additional language data (download)'** and tick **'Telugu'**.
            3. Install to the default path (`C:\\Program Files\\Tesseract-OCR\\tesseract.exe`) or set `TESSERACT_CMD` in `.env`.
            4. Restart LexiMind.

            *(Digital PDFs with selectable text, Word DOCX, and TXT files work without Tesseract.)*
            """)
        elif not ocr_diag["has_telugu"]:
            st.info("💡 **Tesseract is installed, but Telugu language data ('tel.traineddata') is missing.**")
            st.markdown("""
            1. Download `tel.traineddata` from [tesseract-ocr/tessdata](https://github.com/tesseract-ocr/tessdata/blob/main/tel.traineddata).
            2. Copy it into your Tesseract `tessdata` folder or into a `tessdata` folder inside this project.
            3. Restart LexiMind.
            """)
        else:
            st.success("✅ Tesseract OCR and Telugu language models are ready for scanned documents and images.")

    # Handle a newly uploaded file
    if uploaded_file is not None and st.session_state.last_uploaded_signature != current_upload_signature:
        st.session_state.last_uploaded_signature = current_upload_signature
        file_bytes = uploaded_file.getvalue()
        try:
            with st.spinner("Extracting text and analyzing document structure..."):
                ext_res = process_uploaded_document(uploaded_file.name, file_bytes)
                if not ext_res.get("text", "").strip():
                    raise DocumentProcessingError(
                        f"No readable text could be recognized from '{uploaded_file.name}' (0 words). "
                        "If this is a scanned document or photograph, Tesseract OCR with Telugu and English language data is required."
                    )
            st.session_state.raw_text = ext_res["text"]
            st.session_state.filename = uploaded_file.name
            st.session_state.extraction_metadata = ext_res
            reset_results()
            st.success(f"Extracted `{uploaded_file.name}` via {ext_res['extraction_method']} ({ext_res['word_count']} words)")
            for w in ext_res.get("warnings", []):
                st.warning(f"⚠️ {w}")
        except DocumentProcessingError as e:
            st.session_state.raw_text = ""
            st.session_state.filename = uploaded_file.name
            st.session_state.extraction_metadata = {"error": str(e)}
            reset_results()
            st.error(f"❌ Text Extraction Failed for '{uploaded_file.name}'")
            st.markdown(f"""
            <div class="risk-high">
                <b>Diagnostic Error:</b> {html.escape(str(e))}<br><br>
                💡 <b>How to Resolve:</b><br>
                • <b>For Scanned Images / PDFs:</b> Ensure Tesseract OCR is installed and <code>tel.traineddata</code> is present for Telugu OCR.<br>
                • <b>Manual Input:</b> You can paste or type the legal text directly into the editable text area below.
            </div>
            """, unsafe_allow_html=True)

    # Editable text area: inspect & correct extracted text (or paste manually)
    show_editor = bool(st.session_state.raw_text.strip()) or bool(st.session_state.extraction_metadata.get("error"))
    if show_editor:
        st.markdown("---")
        st.markdown("#### 🔍 Step 1: Inspect, Correct & Prepare Legal Text")
        st.caption("Review and fix any OCR or transcription errors below, or paste legal text directly:")

        edited_text = st.text_area(
            "Original Extracted Text (Editable for OCR error correction or manual input)",
            value=st.session_state.raw_text,
            height=220,
            key=f"editor_{st.session_state.editor_version}",
            placeholder="Review extracted text or paste/type legal document text here..."
        )
        st.session_state.raw_text = edited_text

        if st.session_state.raw_text.strip():
            lang_info = detect_document_language(st.session_state.raw_text)
            col_m1, col_m2, col_m3, col_m4 = st.columns(4)
            col_m1.metric("Detected Language", lang_info["language"])
            col_m2.metric("Telugu Character %", f"{lang_info['telugu_pct']}%")
            col_m3.metric("English Character %", f"{lang_info['english_pct']}%")
            col_m4.metric("Word Count", len(st.session_state.raw_text.split()))

            st.markdown("---")
            st.markdown("#### ⚡ Step 2: Generate Same-Language Simplification")

            target_display = "Telugu (తెలుగు)" if lang_info["lang_code"] == "te" else "English"
            if lang_info["lang_code"] == "mixed":
                target_display = "Telugu (తెలుగు)" if lang_info["dominant_lang"] == "te" else "English"
            st.info(f"👉 **Primary Action:** Simplifies from **{lang_info['language']}** into **Simplified {target_display}** (Same-Language Simplification).")

            if st.session_state.processed_text and st.session_state.processed_text != st.session_state.raw_text:
                st.warning("✏️ The text was edited after the last simplification. Click the button again to refresh the results.")

            if st.button("🚀 Simplify Legal Document Now", type="primary", width="stretch"):
                spinner_msg = (
                    f"Asking the AI model (up to {AI_TIMEOUT_SECONDS} s if the service is busy; the offline engine is used after that)..."
                    if use_ai else "Analyzing legal phrasing and generating plain-language simplification..."
                )
                with st.spinner(spinner_msg):
                    text = st.session_state.raw_text
                    st.session_state.simplification_results = simplify_legal_document(
                        text=text,
                        level=simplification_depth,
                        enable_translation=enable_translation,
                        translation_target=translation_target,
                        use_ai=use_ai
                    )
                    st.session_state.clause_results = analyze_document_clauses(text)
                    st.session_state.risk_results = highlight_potential_risks(text, source_lang=lang_info["lang_code"])
                    # Page-level data is only valid if the text was not edited after extraction
                    pages_data = st.session_state.extraction_metadata.get("pages", [])
                    if st.session_state.extraction_metadata.get("text") != text:
                        pages_data = []
                    st.session_state.rag_engine = DocumentRAGEngine(text, pages_data)
                    st.session_state.processed_text = text
                    st.session_state.qa_history = []
                st.rerun()

    # Display Simplification Results & Downloads
    if st.session_state.simplification_results:
        simp = st.session_state.simplification_results
        lang_info = simp["source_language_info"]

        st.markdown("---")
        st.markdown("### 📋 Simplification Results: Original vs. Simplified Comparison")

        ai_errors = simp.get("ai_errors") or []
        if ai_errors:
            busy = any(re.search(r"503|UNAVAILABLE|high demand|429|RESOURCE_EXHAUSTED|DEADLINE|time limit", e) for e in ai_errors)
            headline = (
                "The AI service is busy right now, so the offline engine was used. Try again later, or switch AI off in the sidebar for instant results."
                if busy else "The AI call failed, so the offline engine was used."
            )
            st.warning(f"⚠️ {headline}")
            with st.expander("Technical details"):
                for err in ai_errors:
                    st.caption(err)

        stats = simp.get("stats")
        if stats:
            c1, c2, c3, c4 = st.columns(4)
            c1.metric("Sentences Simplified", stats["sentences_simplified"])
            c2.metric("Legal Phrases Rewritten", stats["phrases_rewritten"])
            c3.metric("Key Facts Found", stats.get("facts_found", 0),
                      help="Parties, dates, labelled amounts and time periods extracted from this document")
            if stats["after"].get("flesch_reading_ease") is not None and stats["before"].get("flesch_reading_ease") is not None:
                c4.metric("Reading Ease (Flesch)", stats["after"]["flesch_reading_ease"],
                          delta=round(stats["after"]["flesch_reading_ease"] - stats["before"]["flesch_reading_ease"], 1))
            else:
                c4.metric("Detected Language", lang_info["language"])

        col_orig, col_simp = st.columns(2)
        with col_orig:
            st.markdown("#### 📜 Original Extracted Legal Text")
            st.markdown(f"<div class='original-box'>{html.escape(st.session_state.processed_text or st.session_state.raw_text)}</div>",
                        unsafe_allow_html=True)

        with col_simp:
            target_lang_title = "Telugu (తెలుగు)" if simp.get("primary_language") == "te" else "Plain English"
            st.markdown(f"#### ✨ Simplified {target_lang_title} ({simp['simplification_level']})")
            st.caption(f"Engine: {simp['primary_engine']}")
            with st.container(height=520, border=True, key="simplified_box"):
                st.markdown(simp["primary_simplified_text"])

        if simp.get("translation_enabled") and simp.get("translated_simplified_text"):
            st.markdown("---")
            st.markdown("#### 🌐 Optional Translated Output")
            st.caption(f"Engine: {simp.get('translation_engine')}")
            with st.container(border=True, key="translated_box"):
                st.markdown(simp["translated_simplified_text"])

        # Download Center
        st.markdown("---")
        st.markdown("### 📥 Download Readable Simplified Document")

        key_details = st.session_state.clause_results["key_details"] if st.session_state.clause_results else None
        risk_data = st.session_state.risk_results
        fname_base = os.path.splitext(st.session_state.filename or "document")[0]
        original_for_report = st.session_state.processed_text or st.session_state.raw_text
        report_args = dict(
            filename=st.session_state.filename,
            original_text=original_for_report,
            simplified_text=simp["primary_simplified_text"],
            source_lang_name=lang_info["language"],
            key_details=key_details,
            risk_data=risk_data,
        )

        col_d1, col_d2, col_d3, col_d4 = st.columns(4)
        col_d1.download_button(
            label="📄 Download DOCX (Word)",
            data=generate_docx_report(**report_args, translated_text=simp.get("translated_simplified_text")),
            file_name=f"{fname_base}_simplified.docx",
            mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            width="stretch"
        )
        col_d2.download_button(
            label="📝 Download TXT (Plain Text)",
            data=generate_txt_report(**report_args, translated_text=simp.get("translated_simplified_text")),
            file_name=f"{fname_base}_simplified.txt",
            mime="text/plain",
            width="stretch"
        )
        col_d3.download_button(
            label="📋 Download Markdown (.md)",
            data=generate_markdown_report(**report_args, translated_text=simp.get("translated_simplified_text")),
            file_name=f"{fname_base}_simplified.md",
            mime="text/markdown",
            width="stretch"
        )
        pdf_res = generate_pdf_report(**report_args)
        if pdf_res["success"]:
            col_d4.download_button(
                label="📑 Download PDF",
                data=pdf_res["pdf_bytes"],
                file_name=f"{fname_base}_simplified.pdf",
                mime="application/pdf",
                width="stretch"
            )
        else:
            col_d4.button(
                label="📑 PDF (Use DOCX for Telugu)",
                disabled=True,
                help=pdf_res.get("error", "Telugu font required for PDF export."),
                width="stretch"
            )


# ==============================================================================
# TAB 2: CLAUSE CLASSIFICATION & KEY DETAILS
# ==============================================================================
with tab_clauses:
    st.markdown("### 📑 Clause Classification & Key Information Extraction")
    if not st.session_state.clause_results:
        st.info("Please upload a legal document and click 'Simplify Legal Document' in Tab 1 to see clause analysis.")
    else:
        cr = st.session_state.clause_results
        key_det = cr["key_details"]

        st.markdown("#### 🔑 Extracted Contract Entities")
        col_k1, col_k2 = st.columns(2)

        with col_k1:
            st.markdown("**Parties & Roles:**")
            for p in key_det.get("Parties Involved", []):
                st.markdown(f"- **{p['role']}:** `{p['name']}`")

            st.markdown("**Key Dates & Deadlines:**")
            for d in key_det.get("Key Dates", []):
                st.markdown(f"- 📅 `{d}`")

            st.markdown(f"**Duration / Term:** `{key_det.get('Agreement Duration / Term', 'Not found')}`")
            st.markdown(f"**Notice Period:** `{key_det.get('Notice Period', 'Not found')}`")
            st.markdown(f"**Lock-in Period:** `{key_det.get('Lock-in Period', 'Not found')}`")

        with col_k2:
            st.markdown("**Financial & Monetary Amounts:**")
            for amt in key_det.get("Amounts Explained", key_det.get("Monetary Amounts", [])):
                st.markdown(f"- 💰 `{amt}`")

            st.markdown("**Property & Identifier Metadata:**")
            prop = key_det.get("Property & Identifier Details", {})
            found = {k: v for k, v in prop.items() if v != "Not found"}
            for pk, pv in found.items():
                st.markdown(f"- **{pk}:** `{pv}`")
            missing = [k for k, v in prop.items() if v == "Not found"]
            if missing:
                st.caption("Not found in this document: " + ", ".join(missing))

        st.markdown("---")
        st.markdown(f"#### 📚 Clauses Categorized ({cr['total_clauses_identified']} Total Clauses)")

        for cat, clauses_in_cat in cr["clauses_by_category"].items():
            with st.expander(f"📁 {cat} ({len(clauses_in_cat)} clauses)", expanded=False):
                for cl in clauses_in_cat:
                    st.markdown(f"**{cl['title']}**")
                    st.code(cl["text"], language=None, wrap_lines=True)
                    plain, _ = simplify_passage(cl["text"])
                    if plain:
                        st.markdown("*Plain meaning:* " + " ".join(plain))


# ==============================================================================
# TAB 3: POTENTIAL RISK HIGHLIGHTS
# ==============================================================================
with tab_risks:
    st.markdown("### ⚠️ Potential-Risk & One-Sided Clause Highlighting")
    st.markdown(
        "LexiMind scans each sentence against recognized legal risk patterns (unilateral termination, "
        "excessive penalties, unlimited liabilities, auto-renewal traps, lock-in, waivers and price escalation)."
    )

    if not st.session_state.risk_results:
        st.info("Please upload and process a document in Tab 1 to view potential risk flags.")
    else:
        rr = st.session_state.risk_results
        col_r1, col_r2, col_r3 = st.columns(3)
        col_r1.metric("🔴 High Risk Clauses", rr["high_risk_count"])
        col_r2.metric("🟡 Medium Risk Clauses", rr["medium_risk_count"])
        col_r3.metric("🟢 Advisory Items", rr["advisory_count"])

        if rr["flagged_risks"]:
            st.markdown("#### 🚨 Flagged Clauses Requiring Review:")
            for risk in rr["flagged_risks"]:
                sev_class = "risk-high" if "High" in risk["severity"] else ("risk-medium" if "Medium" in risk["severity"] else "risk-advisory")
                st.markdown(f"""
                <div class="{sev_class}">
                    <h4 style="margin-top:0;">{html.escape(risk['category'])} <span style="font-size:0.8rem; background:#E2E8F0; padding:2px 8px; border-radius:4px;">{html.escape(risk.get('severity_label', risk['severity']))}</span></h4>
                    <p><b>Exact Source Passage:</b> <i>"{html.escape(risk['source_passage'])}"</i></p>
                    <p><b>Why Flagged:</b> {html.escape(risk['reason_flagged'])}</p>
                    <p><b>Plain Explanation:</b> {html.escape(risk['plain_explanation'])}</p>
                    <p><b>Actionable Review Suggestion:</b> {html.escape(risk['suggestion'])}</p>
                </div>
                """, unsafe_allow_html=True)
        else:
            st.success("✅ No high-risk or severe one-sided clauses were flagged by the heuristic rule set.")

        st.caption(f"⚖️ {rr['disclaimer']}")


# ==============================================================================
# TAB 4: DOCUMENT Q&A (RAG)
# ==============================================================================
with tab_qa:
    st.markdown("### ❓ Grounded Document Question Answering (RAG)")
    st.markdown(
        "Ask questions about the uploaded document. LexiMind retrieves the matching clauses "
        "(TF-IDF word + character n-grams, with English↔Telugu query expansion) and answers only from them, with citations."
    )

    if not st.session_state.rag_engine:
        st.info("Please upload and process a document in Tab 1 to enable document question answering.")
    else:
        src_lang = "en"
        if st.session_state.simplification_results:
            src_lang = st.session_state.simplification_results.get("primary_language", "en")

        with st.form("qa_form", clear_on_submit=True):
            user_question = st.text_input(
                "Enter your question (in Telugu or English):",
                placeholder="e.g. What is the monthly rent and deposit amount? / ఈ ఒప్పందంలో అద్దె మరియు డిపాజిట్ ఎంత?"
            )
            ask_clicked = st.form_submit_button("🔍 Get Answer", type="primary")

        st.markdown("**Quick Preset Questions:**")
        presets = [
            ("👥 Who are the parties?", "Who are the parties involved in this agreement?"),
            ("💰 What payments are due?", "What payments, rent, price, or deposits are required?"),
            ("📅 How long is it valid?", "What is the duration or term of this agreement?"),
            ("🚪 How can it be cancelled?", "How can this agreement be terminated or cancelled, and what notice is needed?"),
        ]
        preset_cols = st.columns(len(presets))
        question_to_ask = user_question.strip() if ask_clicked and user_question.strip() else None
        for col, (label, question) in zip(preset_cols, presets):
            if col.button(label, width="stretch"):
                question_to_ask = question

        if question_to_ask:
            with st.spinner("Searching document context and generating grounded answer..."):
                qa_res = st.session_state.rag_engine.answer_question(question_to_ask, source_lang=src_lang, use_ai=use_ai)
            st.session_state.qa_history.insert(0, {"question": question_to_ask, **qa_res})

        for i, qa in enumerate(st.session_state.qa_history[:10]):
            with st.container(border=True):
                st.markdown(f"**Q: {qa['question']}**")
                st.markdown(qa["answer"])
                st.caption(f"Q&A Engine: {qa['engine']}")
                if qa.get("ai_error"):
                    st.caption("⚠️ AI was unavailable, so this answer was found offline.")
                if qa.get("supporting_passages"):
                    with st.expander("🔍 View Supporting Source Passages & Citations", expanded=False):
                        for p in qa["supporting_passages"]:
                            st.markdown(f"**{p['reference']}** (Relevance Score: `{p.get('similarity_score', 'N/A')}`)")
                            st.code(p["text"], language=None, wrap_lines=True)


# ==============================================================================
# TAB 5: LEGAL GLOSSARY
# ==============================================================================
with tab_glossary:
    st.markdown("### 📖 Legal Terms Glossary")
    st.markdown("Archaic or complex legal vocabulary detected in the document, explained in plain language:")

    if not st.session_state.simplification_results or not st.session_state.simplification_results.get("glossary"):
        st.info("Upload and process a document in Tab 1 to see detected legal terms.")
    else:
        for g in st.session_state.simplification_results["glossary"]:
            st.markdown(f"""
            <div class="legal-card">
                <b>{html.escape(g['term'])}</b> ({g['language']} | Found {g['frequency']} time(s))<br>
                <span style="font-size: 0.95rem;">👉 <b>సరళ వివరణ / Plain Meaning:</b> {html.escape(g['plain_meaning'])}</span>
            </div>
            """, unsafe_allow_html=True)


# Bottom Legal Disclaimer
st.markdown(f"""
<div class="disclaimer-box">
    <b>⚖️ LEGAL DISCLAIMER:</b> {html.escape(LEGAL_SAFETY_DISCLAIMER)}
</div>
""", unsafe_allow_html=True)

"""
Tests for the offline NLP core and the "same template for every document" regression.
Covers sentence splitting, English legalese rewriting, Telugu archaic-form rewriting,
TextRank summarization, duty extraction, and document-specific output.
"""

import difflib
from pathlib import Path

from text_simplifier import (
    split_sentences,
    simplify_english_sentence,
    simplify_telugu_sentence,
    summarize,
    extract_duties,
)
from language_processor import simplify_legal_document, detect_document_type
from clause_analyzer import extract_labeled_amounts, extract_time_periods, extract_dates
from rag_engine import DocumentRAGEngine

SAMPLES = Path(__file__).resolve().parent.parent / "sample_documents"


def _sample(name: str) -> str:
    return (SAMPLES / name).read_text(encoding="utf-8")


def test_sentence_splitter_keeps_abbreviations():
    text = "The rent is Rs. 15,000 per month. Mr. R. Kumar lives at Door No. 12. The term is 11 months."
    sentences = split_sentences(text)
    assert len(sentences) == 3
    assert sentences[0].startswith("The rent is Rs. 15,000")


def test_english_legalese_is_rewritten():
    out, changes = simplify_english_sentence(
        "The Lessee shall pay the rent forthwith, notwithstanding anything contained herein, "
        "and the Lessor hereby agrees prior to the expiry of the term."
    )
    joined = " ".join(out).lower()
    assert changes >= 4
    assert "shall" not in joined and "forthwith" not in joined and "hereby" not in joined
    assert "tenant must pay" in joined and "immediately" in joined and "before" in joined


def test_amount_in_words_duplicate_removed():
    out, _ = simplify_english_sentence("The rent is Rs. 35,000/- (Rupees Thirty Five Thousand Only) per month.")
    assert "Rupees Thirty" not in " ".join(out)
    assert "Rs. 35,000/-" in " ".join(out)


def test_telugu_archaic_forms_become_spoken_telugu():
    out, changes = simplify_telugu_sentence("అద్దెదారుడు ప్రతి నెలా అద్దె చెల్లించవలెను మరియు సదరు పత్రము పై సంతకం చేసినారు.", set())
    text = out[0]
    assert changes >= 3
    assert "చెల్లించాలి" in text
    assert "పత్రం" in text
    assert "చేసారు" in text
    assert "సదరు" not in text


def test_summary_prefers_content_over_witnesses():
    sentences = split_sentences(_sample("english_rental_agreement.txt"))
    chosen = [sentences[i] for i in summarize(sentences, 4)]
    assert any("35,000" in s for s in chosen)
    assert not any("P. Ramesh" in s for s in chosen)


def test_duties_grouped_by_party():
    duties = extract_duties([
        "The Tenant must pay the rent by the 5th of every month.",
        "The Landlord must not enter the premises without notice.",
        "Either party may end this agreement with 2 months notice.",
    ])
    assert "Tenant" in duties and duties["Tenant"]["obligation"]
    assert "Landlord" in duties and duties["Landlord"]["prohibition"]
    assert "Both parties" in duties and duties["Both parties"]["right"]


def test_amounts_and_periods_are_labelled_from_context():
    text = _sample("english_rental_agreement.txt")
    amounts = {a["label_en"]: a["value"] for a in extract_labeled_amounts(text)}
    assert amounts["Monthly rent"].startswith("Rs. 35,000")
    assert amounts["Security deposit"].startswith("Rs. 2,00,000")
    periods = {p["label_en"]: p["value"] for p in extract_time_periods(text)}
    assert periods["Agreement term"] == "11 months"
    assert periods["Notice period"] == "2 months"
    assert periods["Lock-in period"] == "3 months"


def test_person_age_is_not_a_contract_duration():
    periods = extract_time_periods("శ్రీ రాపర్తి శ్రీనివాసరావు, వయస్సు: 52 సంవత్సరాలు. Mr. Rao, aged about 48 years.")
    assert periods == []


def test_telugu_numeric_date_keeps_separators():
    assert "01-11-2026" in extract_dates("ఒప్పందం తేదీ: 01-11-2026 నుండి అమలులోకి వస్తుంది.")


def test_document_type_detection():
    assert "Non-Disclosure" in detect_document_type(_sample("english_nda_agreement.txt"))["en"]
    assert "Lease" in detect_document_type(_sample("english_rental_agreement.txt"))["en"]
    assert "Affidavit" in detect_document_type(_sample("english_notary_affidavit.txt"))["en"]


def test_different_documents_get_different_simplifications():
    """Regression: the old offline engine returned ~60% identical template text for every document."""
    names = ["english_rental_agreement.txt", "english_nda_agreement.txt", "english_notary_affidavit.txt"]
    outputs = [simplify_legal_document(_sample(n))["primary_simplified_text"] for n in names]
    for i in range(len(outputs)):
        for j in range(i + 1, len(outputs)):
            ratio = difflib.SequenceMatcher(None, outputs[i], outputs[j]).ratio()
            assert ratio < 0.3, f"{names[i]} vs {names[j]} too similar ({ratio:.2f})"


def test_nda_output_talks_about_confidentiality_not_land():
    out = simplify_legal_document(_sample("english_nda_agreement.txt"))["primary_simplified_text"]
    assert "Confidential Information" in out
    assert "Survey Number" not in out and "East" not in out


def test_detailed_level_contains_more_than_simple():
    text = _sample("telugu_land_sale_deed.txt")
    simple = simplify_legal_document(text, level="Simple")["primary_simplified_text"]
    detailed = simplify_legal_document(text, level="Detailed")["primary_simplified_text"]
    assert len(detailed) > len(simple)


def test_rag_different_questions_get_different_answers():
    engine = DocumentRAGEngine(_sample("english_rental_agreement.txt"))
    rent = engine.answer_question("What is the monthly rent?")["answer"]
    repairs = engine.answer_question("Who pays for repairs?")["answer"]
    notice = engine.answer_question("How can the agreement be cancelled?")["answer"]
    assert "35,000" in rent
    assert "repairs" in repairs.lower()
    assert "2 months" in notice
    assert len({rent, repairs, notice}) == 3


def test_rag_english_question_on_telugu_document():
    engine = DocumentRAGEngine(_sample("telugu_rental_agreement.txt"))
    res = engine.answer_question("What is the security deposit?", source_lang="te")
    assert res["grounded"] is True
    assert "50,000" in res["answer"]

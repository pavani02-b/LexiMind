"""
Tests for Language Processor Module
Covers source language detection, Telugu Unicode preservation, same-language simplification
(Telugu-to-Telugu, English-to-English), optional translation, and legal glossary extraction.
"""

from language_processor import (
    detect_document_language,
    extract_legal_glossary,
    simplify_legal_document,
    rule_based_simplify_telugu,
    rule_based_simplify_english
)


def test_detect_language_telugu():
    """Verify accurate detection of pure Telugu legal text."""
    telugu_text = (
        "ఇంటి అద్దె ఒప్పంద పత్రము. మొదటి పక్షం యజమాని రాపర్తి శ్రీనివాసరావు. "
        "రెండవ పక్షం అద్దెదారుడు ముత్తా సతీష్ కుమార్. నెలవారీ అద్దె రూ. 15,000/-."
    )
    res = detect_document_language(telugu_text)
    assert res["lang_code"] == "te"
    assert "Telugu" in res["language"]
    assert res["telugu_pct"] > 50.0
    assert res["is_mixed"] is False


def test_detect_language_english():
    """Verify accurate detection of English contract text."""
    english_text = (
        "This Mutual Non-Disclosure Agreement is executed between Disclosing Party and Receiving Party. "
        "The confidentiality duration shall be 3 years."
    )
    res = detect_document_language(english_text)
    assert res["lang_code"] == "en"
    assert "English" in res["language"]
    assert res["english_pct"] > 80.0
    assert res["is_mixed"] is False


def test_detect_language_mixed():
    """Verify detection of mixed Telugu and English documents."""
    mixed_text = (
        "Commercial Lease Agreement / వాణిజ్య లీజు దస్తావేజు. "
        "Lessor (యజమాని): Sri Annavarapu Raghunath. Monthly rent Rs. 85,000/-. "
        "కౌలుదారు చెల్లించవలసిన అడ్వాన్స్ డిపాజిట్ రూ. 3,50,000/-. Term is 24 months."
    )
    res = detect_document_language(mixed_text)
    assert res["lang_code"] == "mixed"
    assert res["is_mixed"] is True


def test_telugu_to_telugu_simplification_default():
    """
    CRITICAL REQUIREMENT TEST:
    Ensure Telugu input produces simplified Telugu output by default without unwanted translation.
    """
    telugu_text = (
        "ఈ అద్దె దస్తావేజు ఉభయ పక్షములవారు పరస్పర సమ్మతితో వ్రాయించుకున్నది. "
        "సదరు స్థిరాస్తిని స్వతంత్ర సర్వ హక్కులతో స్వాధీనపరచడమైనది. "
        "నెలవారీ అద్దె రూ. 15,000/- మరియు ధరావతు సొమ్ము రూ. 50,000/-."
    )
    res = simplify_legal_document(
        text=telugu_text,
        level="Simple",
        enable_translation=False
    )
    # Primary output must be Telugu, preserving facts
    primary_out = res["primary_simplified_text"]
    assert "రూ. 15,000" in primary_out
    assert "రూ. 50,000" in primary_out
    assert any(ord(c) >= 0x0C00 and ord(c) <= 0x0C7F for c in primary_out), "Output must contain Telugu script"
    # Translation should be disabled
    assert res["translation_enabled"] is False
    assert res["translated_simplified_text"] is None


def test_english_to_english_simplification_default():
    """Verify that English contracts are simplified in plain English by default."""
    english_text = (
        "The Recipient covenants and agrees to indemnify and hold harmless the Company "
        "hereinafter referred to as Disclosing Party. Termination shall be forthwith."
    )
    res = simplify_legal_document(
        text=english_text,
        level="Simple",
        enable_translation=False
    )
    primary_out = res["primary_simplified_text"]
    assert "protect and compensate" in primary_out.lower() or "promise" in primary_out.lower() or "recipient" in primary_out.lower()
    assert res["translation_enabled"] is False


def test_optional_translation_when_enabled():
    """Verify that translation is produced ONLY when explicitly enabled."""
    telugu_text = "నెలవారీ అద్దె రూ. 15,000/- ప్రతి నెలా 5వ తేదీ లోపు చెల్లించవలెను."
    res = simplify_legal_document(
        text=telugu_text,
        level="Simple",
        enable_translation=True,
        translation_target="en"
    )
    assert res["translation_enabled"] is True
    assert res["translated_simplified_text"] is not None


def test_extract_legal_glossary_telugu_and_english():
    """Verify extraction of legal vocabulary for both languages."""
    telugu_doc = "సదరు స్థిరాస్తి స్వాధీనపరచడమైనది మరియు ఉభయ పక్షములవారు అంగీకరించినారు."
    glossary_te = extract_legal_glossary(telugu_doc, "te")
    terms_found = [g["term"] for g in glossary_te]
    assert "ఉభయ పక్షములవారు" in terms_found
    assert "సదరు స్థిరాస్తి" in terms_found
    assert "స్వాధీనపరచడమైనది" in terms_found

    eng_doc = "The parties agree to indemnify and hold harmless in witness whereof forthwith."
    glossary_en = extract_legal_glossary(eng_doc, "en")
    terms_eng = [g["term"] for g in glossary_en]
    assert "indemnify and hold harmless" in terms_eng
    assert "forthwith" in terms_eng


def test_sada_bainama_simplification_preserves_facts():
    """Verify that Sada Bainama / Andhra Stamp Paper deed preserves key facts and provides plain Telugu."""
    sada_bainama_snippet = (
        "విక్రయ పత్రం\n"
        "రూ! 40,000/- అక్షరాలా నలబై వేల రూపాయలకు ఖాళీ జాగా విక్రయపత్రం. -\n"
        "తేది: 04-08-2021 రెండు వేలా ఇరవై ఒక్కటవ సంవత్సరం ఆగస్టు నెల నాలుగవ తేదీన\n"
        "వ్రాయించుకున్నవారు:- ఆంధ్రప్రదేశ్ చిత్తూరు జిల్లా కుప్పం మండలం... జి.సి. నాగరాజ్ భార్య ఎన్.విశాలాక్షి గారికి\n"
        "వ్రాయించియిచ్చినవారు:- బి.సోమప్ప కుమారుడు బి.ఎస్. గురుముర్తి అను నేను వ్రాయించియిచ్చిన విక్రయపత్రం"
    )
    res = simplify_legal_document(sada_bainama_snippet, level="Simple")
    out = res["primary_simplified_text"]
    assert "విశాలాక్షి" in out, "Buyer name must be preserved"
    assert "గురుముర్తి" in out, "Seller name must be preserved"
    assert "40,000" in out, "Amount must be preserved"
    assert "04-08-2021" in out, "Date must be preserved"
    assert "LexiMind Rule-Based Engine (Telugu Legal NLP Heuristics — Offline Mode)" in res["primary_engine"]


def test_rule_based_engine_labels_accurately():
    """Verify accurate engine labeling across Telugu, English, and Mixed contracts without mislabeling."""
    te_res = simplify_legal_document("విక్రయ దస్తావేజు క్రయధనం రూ. 50,000/-.", level="Simple")
    assert "Telugu Legal NLP Heuristics" in te_res["primary_engine"]

    en_res = simplify_legal_document("This Non-Disclosure Agreement is executed between Disclosing Party and Receiving Party.", level="Simple")
    assert "English Legal NLP Heuristics" in en_res["primary_engine"]

    mixed_text = (
        "Commercial Lease Agreement / వాణిజ్య లీజు దస్తావేజు.\n"
        "Lessor: Sri Annavarapu Raghunath. Monthly rent Rs. 85,000/-.\n"
        "కౌలుదారు చెల్లించవలసిన డిపాజిట్ రూ. 3,50,000/-. Term is 24 months."
    )
    mixed_res = simplify_legal_document(mixed_text, level="Simple")
    assert "Bilingual Legal NLP Heuristics" in mixed_res["primary_engine"]


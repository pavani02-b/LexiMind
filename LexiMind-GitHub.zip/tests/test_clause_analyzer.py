"""
Tests for Clause Analyzer Module
Covers segmentation, classification into categories, and verified key information extraction.
"""

from clause_analyzer import (
    segment_into_clauses,
    classify_single_clause,
    extract_parties,
    extract_dates,
    extract_monetary_amounts,
    extract_property_identifiers,
    extract_key_contract_details,
    analyze_document_clauses
)


def test_segment_into_clauses_numbered():
    """Verify segmentation of numbered clauses."""
    text = (
        "Clause 1: Monthly rent shall be Rs. 20,000.\n\n"
        "Clause 2: The term is 12 months.\n\n"
        "Clause 3: Either party may terminate with 30 days notice."
    )
    clauses = segment_into_clauses(text)
    assert len(clauses) >= 3
    assert "Clause 1" in clauses[0]["clause_id"] or "Clause" in clauses[0]["title"]


def test_classify_single_clause():
    """Verify clause classification across key categories."""
    payment_clause = "The monthly rent is Rs. 15,000 payable on or before 5th of every month."
    assert classify_single_clause(payment_clause) == "Payment and Financial Terms"

    term_clause = "This agreement shall terminate upon 30 days prior written notice."
    assert classify_single_clause(term_clause) == "Term and Termination"

    conf_clause = "The receiving party shall keep all proprietary trade secrets confidential."
    assert classify_single_clause(conf_clause) == "Confidentiality and Non-Disclosure"

    telugu_property = "విజయవాడ సర్వే నెం. 142/3 నందు గల స్థిరాస్తి చతుస్సీమలు."
    assert classify_single_clause(telugu_property) == "Property, Ownership, and Title"


def test_extract_parties_telugu_and_english():
    """Verify accurate party and role extraction in Telugu and English."""
    telugu_contract = (
        "మొదటి పక్షం (యజమాని): రాపర్తి శ్రీనివాసరావు\n"
        "రెండవ పక్షం (అద్దెదారుడు): ముత్తా సతీష్ కుమార్"
    )
    parties_te = extract_parties(telugu_contract)
    assert len(parties_te) >= 2
    assert any("శ్రీనివాసరావు" in p["name"] for p in parties_te)
    assert any("సతీష్ కుమార్" in p["name"] for p in parties_te)

    eng_contract = "Lessor: Johnathan Smith\nLessee: Robert Williams\nRent is $2,000."
    parties_en = extract_parties(eng_contract)
    assert len(parties_en) >= 2
    assert any("Johnathan Smith" in p["name"] for p in parties_en)
    assert any("Robert Williams" in p["name"] for p in parties_en)


def test_extract_monetary_amounts():
    """Verify extraction of diverse currency formats without hallucination."""
    text = "The monthly rent is Rs. 15,000/-. Advance deposit is రూ. 50,000/- and fee is $1,200."
    amts = extract_monetary_amounts(text)
    assert any("15,000" in a for a in amts)
    assert any("50,000" in a for a in amts)
    assert any("1,200" in a for a in amts)


def test_extract_property_identifiers():
    """Verify extraction of survey number, plot number, and boundaries."""
    text = (
        "సర్వే నెం: 142/3B\n"
        "ప్లాట్ నెం: 24\n"
        "విస్తీర్ణం: 250 చదరపు గజములు\n"
        "చతుస్సీమలు: తూర్పు: రోడ్డు, పడమర: స్థలం"
    )
    props = extract_property_identifiers(text)
    assert props["Survey Number"] == "142/3B"
    assert props["Plot / Flat Number"] == "24"
    assert "250" in props["Area / Extent"]
    assert "రోడ్డు" in props["Boundaries (చతుస్సీమలు)"]


def test_missing_fields_show_not_found():
    """Ensure missing fields display 'Not found' and are not fabricated."""
    empty_text = "General discussion without names or numbers."
    details = extract_key_contract_details(empty_text)
    assert details["Agreement Duration / Term"] == "Not found"
    assert details["Notice Period"] == "Not found"
    assert details["Property & Identifier Details"]["Survey Number"] == "Not found"

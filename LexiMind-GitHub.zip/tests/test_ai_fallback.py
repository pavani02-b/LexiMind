"""
Tests for Gemini error handling (no network): busy models are retried, then another flash
model is used; retired models are replaced; real failures are reported, not hidden.
"""

import types

import language_processor as lp


class FakeModels:
    def __init__(self, behaviour, available):
        self.behaviour = behaviour      # model -> list of results ("ok" or an error message)
        self.available = available
        self.calls = []

    def generate_content(self, model, contents):
        self.calls.append(model)
        outcome = self.behaviour.get(model, ["404 NOT_FOUND model not found"]).pop(0)
        if outcome == "ok":
            return types.SimpleNamespace(text=f"answer from {model}")
        raise RuntimeError(outcome)

    def list(self):
        return [types.SimpleNamespace(name=f"models/{n}", supported_actions=["generateContent"]) for n in self.available]


def _setup(monkeypatch, behaviour, available):
    fake = types.SimpleNamespace(models=FakeModels(behaviour, available))
    monkeypatch.setattr(lp, "_make_gemini_client", lambda timeout_seconds: fake)
    monkeypatch.setattr(lp, "GEMINI_API_KEY", "test-key")
    monkeypatch.setattr(lp, "OPENAI_API_KEY", "")
    monkeypatch.setattr(lp, "GEMINI_MODEL", "gemini-3.8-flash")
    monkeypatch.setattr(lp, "_working_gemini_model", None)
    monkeypatch.setattr(lp.time, "sleep", lambda s: None)
    return fake.models


BUSY = "503 UNAVAILABLE. This model is currently experiencing high demand."


def test_busy_model_is_retried(monkeypatch):
    models = _setup(monkeypatch, {"gemini-3.8-flash": [BUSY, "ok"]}, ["gemini-3.8-flash"])
    res = lp.call_ai_model("hello")
    assert res["text"] == "answer from gemini-3.8-flash"
    assert res["errors"] == []
    assert models.calls == ["gemini-3.8-flash", "gemini-3.8-flash"]


def test_persistently_busy_model_switches_to_other_flash(monkeypatch):
    _setup(monkeypatch,
           {"gemini-3.8-flash": [BUSY, BUSY, BUSY], "gemini-3.5-flash": ["ok"]},
           ["gemini-3.8-flash", "gemini-3.5-flash", "gemini-3.8-flash-lite"])
    res = lp.call_ai_model("hello")
    assert res["text"] == "answer from gemini-3.5-flash"
    assert "busy" in res["engine"]
    assert lp._working_gemini_model is None   # busy is temporary: keep using the configured model next time


def test_retired_model_is_replaced(monkeypatch):
    _setup(monkeypatch,
           {"gemini-3.8-flash": ["404 NOT_FOUND. Please use models/gemini-4.0-flash instead."], "gemini-4.0-flash": ["ok"]},
           ["gemini-4.0-flash"])
    res = lp.call_ai_model("hello")
    assert res["text"] == "answer from gemini-4.0-flash"
    assert "GEMINI_MODEL=gemini-4.0-flash" in res["engine"]


def test_all_failures_are_reported(monkeypatch):
    _setup(monkeypatch, {"gemini-3.8-flash": [BUSY, BUSY, BUSY]}, ["gemini-3.8-flash"])
    res = lp.call_ai_model("hello")
    assert res["text"] is None
    assert any("503" in e for e in res["errors"])

def test_request_deadline_never_below_google_minimum(monkeypatch):
    models = _setup(monkeypatch,
                    {"gemini-3.8-flash": [BUSY, BUSY], "gemini-3.7-flash": [BUSY], "gemini-3.6-flash": [BUSY]},
                    ["gemini-3.8-flash", "gemini-3.7-flash", "gemini-3.6-flash"])
    timeouts = []
    fake = lp._make_gemini_client(0)
    monkeypatch.setattr(lp, "_make_gemini_client", lambda timeout_seconds: timeouts.append(timeout_seconds) or fake)
    # Each call "takes" 20 seconds of a 60-second budget
    clock = {"t": 0.0}
    monkeypatch.setattr(lp.time, "monotonic", lambda: clock["t"])
    original = models.generate_content
    def slow(model, contents):
        clock["t"] += 20
        return original(model, contents)
    monkeypatch.setattr(models, "generate_content", slow)
    monkeypatch.setattr(lp, "AI_TIMEOUT_SECONDS", 60)
    res = lp.call_ai_model("hello")
    assert res["text"] is None
    assert timeouts and min(timeouts) >= lp.GEMINI_MIN_REQUEST_SECONDS
    assert any("time limit" in e for e in res["errors"])

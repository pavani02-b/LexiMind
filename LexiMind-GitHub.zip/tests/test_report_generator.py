"""
Tests for Report Generator Module
Covers TXT, Markdown, DOCX, and PDF generation with Telugu Unicode preservation.
"""

from report_generator import (
    generate_txt_report,
    generate_markdown_report,
    generate_docx_report,
    generate_pdf_report
)


def test_generate_txt_report():
    """Verify TXT export contains all sections and UTF-8 Telugu characters."""
    txt_bytes = generate_txt_report(
        filename="rental.txt",
        original_text="నెలవారీ అద్దె రూ. 15,000.",
        simplified_text="ప్రతి నెలా రూ. 15,000 చెల్లించాలి.",
        source_lang_name="Telugu",
        key_details={"Monthly Rent": "Rs. 15,000"}
    )
    assert len(txt_bytes) > 0
    decoded = txt_bytes.decode("utf-8")
    assert "LEXIMIND" in decoded
    assert "15,000" in decoded
    assert "నెలవారీ" in decoded


def test_generate_markdown_report():
    """Verify Markdown report generation."""
    md_bytes = generate_markdown_report(
        filename="lease.docx",
        original_text="Original Lease Text",
        simplified_text="Simplified Lease Text",
        source_lang_name="English"
    )
    assert len(md_bytes) > 0
    decoded = md_bytes.decode("utf-8")
    assert "# ⚖️ LexiMind" in decoded
    assert "Simplified Lease Text" in decoded


def test_generate_docx_report():
    """Verify Word DOCX generation."""
    docx_bytes = generate_docx_report(
        filename="agreement.pdf",
        original_text="Original text here.",
        simplified_text="Simplified explanation in English and తెలుగు.",
        source_lang_name="Mixed",
        key_details={"Parties": ["First Party", "Second Party"]}
    )
    assert len(docx_bytes) > 1000
    assert docx_bytes.startswith(b"PK")  # Standard ZIP/DOCX header


def test_generate_pdf_report():
    """Verify PDF generation or proper fallback without unhandled crashes."""
    pdf_res = generate_pdf_report(
        filename="contract.pdf",
        original_text="Digital English Contract text.",
        simplified_text="Plain English simplification of the contract.",
        source_lang_name="English"
    )
    assert "success" in pdf_res
    if pdf_res["success"]:
        assert len(pdf_res["pdf_bytes"]) > 0
        assert pdf_res["pdf_bytes"].startswith(b"%PDF")

"""
Tests for Risk Analyzer Module
Covers detection of unilateral termination, excessive penalties, unlimited liability,
and verification of safety disclaimers.
"""

from risk_analyzer import highlight_potential_risks
from config import RISK_LEVEL_HIGH, RISK_LEVEL_MEDIUM, LEGAL_SAFETY_DISCLAIMER


def test_detect_unilateral_termination_english():
    """Verify detection of unilateral termination clause in English."""
    text = (
        "Section 5: Notwithstanding anything to the contrary, Disclosing Party "
        "reserves the right to terminate immediately without cause or notice upon its sole discretion."
    )
    res = highlight_potential_risks(text, source_lang="en")
    assert res["total_risks_flagged"] >= 1
    assert res["high_risk_count"] >= 1
    categories = [r["category"] for r in res["flagged_risks"]]
    assert any("Termination" in c for c in categories)


def test_detect_deposit_forfeiture_telugu():
    """Verify detection of deposit forfeiture and sudden cancellation in Telugu."""
    text = (
        "ఒకవేళ అద్దెదారుడు చెల్లింపు చేయనిచో యజమాని ఎటువంటి నోటీసు లేకుండా తక్షణమే రద్దు చేసి "
        "డిపాజిట్ మొత్తాన్ని జప్తు చేసే హక్కు కలదు."
    )
    res = highlight_potential_risks(text, source_lang="te")
    assert res["total_risks_flagged"] >= 1
    flagged = res["flagged_risks"]
    # Check that plain explanation is in Telugu
    assert any("నోటీసు" in r["plain_explanation"] or "జప్తు" in r["plain_explanation"] for r in flagged)


def test_detect_unlimited_liability():
    """Verify detection of uncapped indemnity clause."""
    text = (
        "Receiving Party shall indemnify and defend Disclosing Party against any and all claims "
        "without any limitation of liability or cap."
    )
    res = highlight_potential_risks(text, source_lang="en")
    assert res["total_risks_flagged"] >= 1
    categories = [r["category"] for r in res["flagged_risks"]]
    assert any("Liability" in c or "Indemnity" in c for c in categories)


def test_safety_disclaimer_included():
    """Verify legal safety disclaimer is always included."""
    res = highlight_potential_risks("Normal clause without flags.", source_lang="en")
    assert res["disclaimer"] == LEGAL_SAFETY_DISCLAIMER
    assert "LEGAL DISCLAIMER" in res["disclaimer"]

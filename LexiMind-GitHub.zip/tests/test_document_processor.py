"""
Tests for Document Processor Module
Covers file validation, extraction for digital PDF, DOCX, TXT, and OCR failure handling.
"""

import io
import pytest
from PIL import Image
import fitz
import docx

from document_processor import (
    validate_file,
    extract_from_pdf,
    extract_from_docx,
    extract_from_txt,
    extract_from_image_file,
    process_uploaded_document,
    DocumentProcessingError,
    is_tesseract_available
)


def test_validate_file_valid():
    """Test valid file extensions and sizes."""
    validate_file("sample.pdf", 1024)
    validate_file("document.docx", 2048)
    validate_file("notes.txt", 500)
    validate_file("scan.png", 5000)


def test_validate_file_invalid_extension():
    """Test rejection of unsupported file extensions."""
    with pytest.raises(DocumentProcessingError, match="Unsupported file format"):
        validate_file("malicious.exe", 1024)
    with pytest.raises(DocumentProcessingError, match="Unsupported file format"):
        validate_file("archive.zip", 2048)


def test_validate_file_empty():
    """Test rejection of zero-byte files."""
    with pytest.raises(DocumentProcessingError, match="empty"):
        validate_file("empty.pdf", 0)


def test_extract_from_txt():
    """Test text extraction from UTF-8 and encoded TXT files."""
    sample_text = "ఇది తెలుగు లీగల్ దస్తావేజు పరీక్ష. Residential Rental Agreement."
    txt_bytes = sample_text.encode("utf-8")
    res = extract_from_txt(txt_bytes)
    assert res["success"] is True
    assert "Residential Rental Agreement" in res["text"]
    assert "తెలుగు" in res["text"]
    assert res["page_count"] == 1


def test_extract_from_docx():
    """Test text extraction from DOCX document containing paragraphs and tables."""
    doc = docx.Document()
    doc.add_heading("Commercial Lease Agreement", level=1)
    doc.add_paragraph("This agreement is made between Lessor and Lessee.")
    table = doc.add_table(rows=2, cols=2)
    table.cell(0, 0).text = "Rent"
    table.cell(0, 1).text = "Rs. 25,000"
    table.cell(1, 0).text = "Deposit"
    table.cell(1, 1).text = "Rs. 1,00,000"

    buf = io.BytesIO()
    doc.save(buf)
    docx_bytes = buf.getvalue()

    res = extract_from_docx(docx_bytes)
    assert res["success"] is True
    assert "Commercial Lease Agreement" in res["text"]
    assert "Rs. 25,000" in res["text"]
    assert res["extraction_method"] == "docx"


def test_extract_from_digital_pdf():
    """Test digital PDF text extraction with PyMuPDF."""
    doc = fitz.open()
    page = doc.new_page()
    page.insert_text(
        (50, 50),
        "LEGAL CONTRACT DEED\nParty A: Ramakrishna\nParty B: Sitaram\nConsideration: Rs. 5,00,000\nSurvey No: 45/2"
    )
    pdf_bytes = doc.tobytes()
    doc.close()

    res = extract_from_pdf(pdf_bytes)
    assert res["success"] is True
    assert "LEGAL CONTRACT DEED" in res["text"]
    assert "Ramakrishna" in res["text"]
    assert res["page_count"] == 1
    assert "digital" in res["extraction_method"]


def test_image_ocr_handling():
    """Test image extraction and honest reporting if Tesseract is not installed."""
    img = Image.new("RGB", (200, 100), color="white")
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    img_bytes = buf.getvalue()

    if not is_tesseract_available():
        with pytest.raises(DocumentProcessingError, match="Tesseract"):
            extract_from_image_file(img_bytes)
    else:
        with pytest.raises(DocumentProcessingError, match="0 readable words"):
            extract_from_image_file(img_bytes)


def test_ocr_diagnostics():
    """Test that OCR diagnostics return structured information."""
    from document_processor import get_ocr_diagnostics
    diag = get_ocr_diagnostics()
    assert "is_available" in diag
    assert "executable_path" in diag
    assert "languages" in diag
    assert "has_telugu" in diag
    assert "has_english" in diag


def test_process_uploaded_document_dispatch():
    """Test unified process_uploaded_document function with TXT file."""
    text = "Clause 1: Monthly rent is Rs. 15,000. Notice period is 30 days."
    res = process_uploaded_document("agreement.txt", text.encode("utf-8"))
    assert res["filename"] == "agreement.txt"
    assert res["word_count"] > 0
    assert "Monthly rent" in res["text"]

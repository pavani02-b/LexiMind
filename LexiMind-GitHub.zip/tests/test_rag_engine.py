"""
Tests for RAG Engine Module
Covers indexing, semantic retrieval, citations, and 'information not found' handling.
"""

from rag_engine import DocumentRAGEngine


def test_rag_retrieval_and_answer():
    """Verify semantic retrieval and grounded answer for payment terms."""
    doc_text = (
        "This Lease Agreement is executed on 01-11-2026.\n\n"
        "Section 1: The monthly rent shall be Rs. 18,000 payable by the 5th of each month.\n\n"
        "Section 2: The security deposit of Rs. 60,000 was paid in advance.\n\n"
        "Section 3: The agreement ends after 11 months on 30-09-2027."
    )
    engine = DocumentRAGEngine(doc_text)
    qa_res = engine.answer_question("What is the monthly rent?", source_lang="en")

    assert qa_res["grounded"] is True
    assert "18,000" in qa_res["answer"]
    assert len(qa_res["supporting_passages"]) > 0
    assert "Section 1" in qa_res["supporting_passages"][0]["reference"]


def test_rag_telugu_query_and_citations():
    """Verify Telugu retrieval and citation."""
    doc_text = (
        "ఇంటి అద్దె ఒప్పందం.\n\n"
        "నిబంధన 1: నెలవారీ అద్దె రూ. 15,000/- గా నిర్ణయించడమైనది.\n\n"
        "నిబంధన 2: సెక్యూరిటీ డిపాజిట్ రూ. 50,000/- చెల్లించినారు."
    )
    engine = DocumentRAGEngine(doc_text)
    qa_res = engine.answer_question("అద్దె ఎంత?", source_lang="te")

    assert qa_res["grounded"] is True
    assert "15,000" in qa_res["answer"]


def test_rag_information_not_found():
    """Verify that asking for non-existent information returns 'not found' rather than hallucinating."""
    doc_text = "This contract is between Alice and Bob regarding gardening services."
    engine = DocumentRAGEngine(doc_text)
    qa_res = engine.answer_question("What is the penalty for copyright infringement in Germany?", source_lang="en")

    # Should report not found or ungrounded
    assert "not found" in qa_res["answer"].lower() or qa_res["grounded"] is False

# ⚖️ LexiMind: An AI-Powered Legal Document Simplification and Intelligent Contract Analysis System

**LexiMind** is an end-to-end, full-stack NLP system engineered to transform difficult, archaic, and convoluted legal agreements into clear, plain-language explanations. Designed with **same-language simplification as its primary feature**, LexiMind rewrites Telugu legal documents into simple conversational Telugu, and English legal documents into plain modern English, preserving all essential legal obligations, party identities, dates, and numbers.

---

## 📌 1. Project Overview & Problem Statement

### The Problem
Legal contracts—such as residential rental agreements, land sale deeds, employment contracts, and affidavits—are frequently drafted in opaque "legalese" and archaic phrasing. For laypersons, rural citizens, and small business owners, understanding their rights and liabilities is difficult. This opacity often leads to unfavorable terms, unbudgeted penalties, and protracted litigation.

In regional Indian contexts, particularly for **Telugu legal documents** (విక్రయ దస్తావేజులు, కౌలు ఒప్పందాలు), existing commercial tools either fail completely or force unwanted translations into English, which alters contextual legal nuances and makes the content inaccessible to regional speakers.

### The LexiMind Solution
LexiMind addresses this challenge by providing:
1. **Same-Language Legal Simplification (Default)**:
   - **Telugu Input → Simplified Telugu Output**: Converts court terminology into modern spoken Telugu without forced English translation.
   - **English Input → Plain English Output**: Rewrites covenants, indemnities, and Latin maxims into accessible English.
   - **Optional Cross-Translation**: Disabled by default; can be toggled on when bilingual review is specifically required.
2. **Multi-Format Ingestion**:
   - Digital PDFs (PyMuPDF)
   - Scanned PDFs and raster images (Pillow + Tesseract OCR with Telugu & English language models)
   - Microsoft Word DOCX (python-docx)
   - Plain text (UTF-8, UTF-16, Latin-1)
3. **Editable Pre-Processing**: Users can inspect and manually correct OCR transcriptions before simplification.
4. **Intelligent Contract Analytics**:
   - Automated clause segmentation and classification (10 standard legal categories).
   - Verifiable key entity extraction (Parties, Dates, Monetary Amounts, Survey Numbers, Boundaries / చతుస్సీమలు). Missing fields are displayed as *"Not found"*, never hallucinated.
5. **Potential-Risk Highlighting**:
   - Flags onerous clauses (unilateral termination, deposit forfeiture, uncapped liability, lock-in penalties).
   - Quotes the exact source passage and offers actionable review recommendations.
6. **Grounded Document Q&A (RAG)**:
   - Chunked semantic TF-IDF vector retrieval.
   - Answers questions strictly grounded in document excerpts with exact section citations.
7. **Multi-Format Export**:
   - Downloadable as DOCX, TXT, Markdown, and PDF (with Telugu Unicode font rendering).

---

## 🏗️ 2. System Architecture

```mermaid
flowchart TD
    A["Uploaded Document (PDF / Scanned PDF / DOCX / TXT / Image)"] --> B["document_processor.py"]
    B --> C{"Extraction Mode"}
    C -->|Digital PDF / DOCX / TXT| D["Direct Text Stream"]
    C -->|Scanned PDF / Image| E["Pillow Preprocessing + Tesseract OCR (tel+eng)"]
    D --> F["Inspection & Manual Text Correction UI"]
    E --> F
    F --> G["language_processor.py + text_simplifier.py (Language Detection & Simplification)"]
    G --> H{"Target Output"}
    H -->|Default| I["Same-Language Simplification (Telugu ➔ Telugu / English ➔ English)"]
    H -->|Optional Toggle| J["Cross-Language Translation"]
    I --> K["Side-by-Side Comparison Dashboard"]
    J --> K
    F --> L["clause_analyzer.py (Segmentation, Categorization & Entity Extraction)"]
    F --> M["risk_analyzer.py (Heuristic Risk Detection)"]
    F --> N["rag_engine.py (Semantic TF-IDF Index & Grounded Q&A)"]
    K --> O["report_generator.py (DOCX, TXT, Markdown, Unicode PDF)"]
    L --> O
    M --> O
```

---

## 🛠️ 3. Technologies Used & Their Purposes

| Component | Technology | Purpose |
| :--- | :--- | :--- |
| **User Interface** | Streamlit 1.65+ | High-interactivity web dashboard with side-by-side comparison and downloads |
| **PDF Extraction** | PyMuPDF (fitz) | Fast, lossless digital PDF text extraction with page tracking |
| **Word Extraction & Generation** | python-docx | Ingestion and export of Microsoft Word documents with full Telugu Unicode support |
| **Image Preprocessing** | Pillow (PIL) | Contrast adjustment, auto-orientation, and binarization for OCR |
| **OCR Engine** | Tesseract OCR (pytesseract) | Scanned PDF and image text recognition with Telugu (`tel.traineddata`) support |
| **Vector Retrieval & RAG** | Scikit-learn (TF-IDF) & NumPy | Lightweight, deterministic semantic search without heavyweight torch checkpoints |
| **AI LLM API** | Google Gemini (`google-genai`) / OpenAI | Deep legal reasoning, clause synthesis, and natural conversational simplification |
| **Offline NLP Engine** | `text_simplifier.py` (regex rewriting, TextRank, TF-IDF) | Rewrites the document's own sentences (legalese → plain English, archaic Telugu → spoken Telugu), TextRank summary, per-party obligations, readability scores |
| **Telugu PDF Shaping** | uharfbuzz (HarfBuzz) | Correct Telugu conjuncts and vowel signs in exported PDFs |
| **PDF Generation** | ReportLab 5.1+ | High-fidelity PDF compilation with Windows `Nirmala.ttc` Telugu font embedding |
| **Automated Testing** | Pytest 9.1+ | Automated test suite (55 unit & integration tests) |

---

## 📂 4. Project Folder Structure

```
LexiMind_Project/
├── app.py                     # Streamlit frontend & interactive dashboard
├── config.py                  # Environment config, paths, fonts, constants
├── document_processor.py      # PDF, DOCX, TXT, image OCR & validation
├── language_processor.py      # Language detection, simplification orchestration, AI calls & glossary
├── text_simplifier.py         # Offline NLP core: sentence splitting, rewriting, TextRank, duties, readability
├── clause_analyzer.py         # Clause segmentation, categorization & entity extraction
├── risk_analyzer.py           # Onerous clause detection, risk flags & safety advice
├── rag_engine.py              # Semantic TF-IDF chunk index & grounded Q&A engine
├── report_generator.py        # Multi-format export (DOCX, TXT, Markdown, PDF)
├── requirements.txt           # Verified Python dependency specifications
├── .env.example               # Configuration template for API keys & OCR path
├── .gitignore                 # Excludes secrets, caches, and temporary files
├── run_leximind.bat           # 1-click Windows batch launcher
│
├── sample_documents/          # Synthetic test legal agreements
│   ├── telugu_rental_agreement.txt
│   ├── telugu_land_sale_deed.txt
│   ├── english_nda_agreement.txt
│   └── mixed_telugu_english_contract.txt
│
├── tests/                     # Automated pytest suite (55 tests passing)
│   ├── test_document_processor.py
│   ├── test_language_processor.py
│   ├── test_text_simplifier.py   # regression: different documents => different output
│   ├── test_ai_fallback.py       # AI timeouts, busy/retired model handling (no network)
│   ├── test_clause_analyzer.py
│   ├── test_risk_analyzer.py
│   ├── test_rag_engine.py
│   └── test_report_generator.py
│
├── architecture.md            # Detailed processing flow and design specifications
├── research_notes.md          # Real NLP benchmarks, datasets, and literature citations
├── resume_notes.md            # Truthful resume bullet points based on implementation
└── viva_questions.md          # Faculty defense questions, answers, and technical rationale
```

---

## 💻 5. Installation Instructions (Windows)

### Prerequisites
- Python 3.10+ installed on your system.

### Step 1: Open Terminal in the Project Directory
```powershell
cd path\to\LexiMind_Project
```

### Step 2: Initialize Virtual Environment
```powershell
python -m venv .venv
```

### Step 3: Activate Virtual Environment
```powershell
.venv\Scripts\activate
```

### Step 4: Install Dependencies
```powershell
pip install -r requirements.txt
```

---

## 🔍 6. Tesseract OCR & Telugu Language Data Setup

Tesseract OCR is required **only** if you intend to process scanned PDFs or photographic images. If you only process digital PDFs, DOCX, or TXT files, this step is optional.

1. Download the Windows installer for Tesseract OCR from UB-Mannheim:
   - `https://github.com/UB-Mannheim/tesseract/wiki`
2. Install Tesseract to the standard path:
   - `C:\Program Files\Tesseract-OCR\tesseract.exe`
3. Download the Telugu trained data file (`tel.traineddata`):
   - From: `https://github.com/tesseract-ocr/tessdata/raw/main/tel.traineddata`
4. Copy `tel.traineddata` into:
   - `C:\Program Files\Tesseract-OCR\tessdata\`
5. In your `.env` file, ensure `TESSERACT_CMD` points to:
   ```env
   TESSERACT_CMD=C:\Program Files\Tesseract-OCR\tesseract.exe
   ```

---

## 🧠 How the Offline Engine Works (no API key needed)

When no Gemini/OpenAI key is configured, `text_simplifier.py` builds a **document-specific** explanation:

1. **Sentence segmentation** — abbreviation-aware (Rs., No., S/o, Sri), repairs PDF/OCR line wraps, drops OCR noise and stamp-paper headers.
2. **Lexical & syntactic simplification** of every sentence:
   - English: ~100 legalese rules (*hereinafter*, *shall*, *notwithstanding*, *forthwith*, *S/o*, amount-in-words duplicates), long-sentence splitting.
   - Telugu: archaic written forms → modern spoken Telugu (చెల్లించవలెను → చెల్లించాలి, పత్రము → పత్రం, కలదు → ఉంది, సదరు → ఈ) plus inline meanings for difficult terms.
3. **TextRank summary** over character n-gram TF-IDF vectors (works for Telugu morphology), with boosts for sentences containing amounts, dates and obligations.
4. **Who must do what** — obligations / rights / prohibitions grouped by party (Tenant, Landlord, Buyer, Seller, …).
5. **Labelled facts** — every amount and time period is labelled from its context (monthly rent vs deposit vs advance; notice vs lock-in vs term; a person's age is ignored).
6. **Readability metrics** — Flesch Reading Ease and average sentence length before vs. after.

With an API key, the same pipeline calls Gemini/OpenAI; if the call fails, the error is shown in the UI and the offline engine is used.

## 🔑 7. AI API Configuration (Optional)

LexiMind runs **100% offline out of the box** using its built-in Legal NLP Heuristic Engine. To connect live cloud AI reasoning:

1. Copy `.env.example` to `.env`:
   ```powershell
   Copy-Item .env.example .env
   ```
2. Open `.env` and paste your Google Gemini or OpenAI API key:
   ```env
   GEMINI_API_KEY=your_gemini_api_key_here
   GEMINI_MODEL=gemini-3.8-flash
   ```
   *(A ChatGPT subscription is not an API key; API keys must be generated from Google AI Studio or OpenAI Platform).*

---

## ▶️ 8. How to Launch and Run the Application

Execute either of the following commands:

### Option A: Using the 1-Click Batch Script
Double-click `run_leximind.bat` in the project root folder.

### Option B: Using the PowerShell Command Line
```powershell
.venv\Scripts\activate
streamlit run app.py
```
The application will launch in your default web browser at `http://localhost:8501`.

---

## 🎯 9. Faculty Demonstration Walkthrough

Follow this 5-minute script during an academic presentation or faculty review:

### Step 1: Telugu-to-Simple-Telugu Simplification (Primary Feature)
1. In **Tab 1: Upload & Simplify**, go to the dropdown **"Select Synthetic Sample Document"**.
2. Select **"Telugu Residential Rental Agreement (అద్దె ఒప్పందం)"**.
3. Point out that the system instantly detects the language:
   - *Detected Language: Telugu (తెలుగు)* with character distribution breakdown.
4. Show the **"Original Extracted Text"** preview box, explaining that users can manually edit any OCR or spelling errors before processing.
5. Click **"🚀 Simplify Legal Document Now"**.
6. View the **Side-by-Side Comparison**:
   - **Left**: Original Telugu legal wording (`ఉభయ పక్షములవారు`, `సదరు స్థిరాస్తి`, `స్వాధీనపరచడమైనది`, `ధరావతు సొమ్ము`).
   - **Right**: Simplified Telugu explanation (`ఇరు పక్షాలు`, `ఇల్లు లేదా భూమి`, `తాళాలను అప్పగించారు`, `సెక్యూరిటీ డిపాజిట్`).
   - **Highlight to faculty**: The system simplified directly from **Telugu into Plain Telugu** without forcing translation to English.

### Step 2: Verifiable Contract Extraction (Tab 2)
1. Switch to **Tab 2: Clause & Details Analysis**.
2. Show the **Extracted Contract Entities**:
   - Parties: `రాపర్తి శ్రీనివాసరావు (యజమాని)`, `ముత్తా సతీష్ కుమార్ (అద్దెదారుడు)`
   - Rent: `రూ. 15,000/-`, Security Deposit: `రూ. 50,000/-`
   - Term: `11 నెలలు`, Notice Period: `1 నెల నోటీసు`
3. Expand the **Clauses Categorized** accordion to show automated classification into *Payment*, *Termination*, and *Property* categories.

### Step 3: Potential-Risk Highlighting (Tab 3)
1. Switch to **Tab 3: Potential Risk Flags**.
2. Show the red **High Risk** flag:
   - *Clause:* `Unilateral Termination / Discretion`
   - *Source Passage:* *"యజమాని ఎటువంటి నోటీసు లేకుండా తక్షణమే రద్దు చేసి..."*
   - *Plain Explanation in Telugu:* Explains why abrupt termination harms the tenant.
   - *Actionable Review Advice:* Recommends mandatory 30-day notice.
3. Point to the prominent **Legal Safety Disclaimer**: LexiMind assists understanding; it is not a certified legal ruling.

### Step 4: Grounded Document Q&A (Tab 4)
1. Switch to **Tab 4: Document Q&A (RAG)**.
2. Click the preset button: **"💰 What payments are due?"** or type: `అద్దె మరియు డిపాజిట్ ఎంత?`.
3. Show the grounded answer citing the exact section reference (`Section 2`, `Section 3`).

### Step 5: Multi-Format Download Center
1. Return to Tab 1 and scroll to **Download Center**.
2. Click **"📄 Download DOCX (Word)"** and **"📑 Download PDF"**.
3. Open the downloaded file to demonstrate complete Unicode Telugu rendering without square symbols or broken characters.

---

## 🧪 10. Automated Testing

LexiMind includes a comprehensive automated test suite built with `pytest`:

```powershell
.venv\Scripts\pytest -v tests
```

**Results:**
- `test_document_processor.py`: 8 tests covering PDF, DOCX, TXT, image OCR, and validation errors.
- `test_language_processor.py`: 7 tests covering language detection, Telugu Unicode preservation, same-language simplification, and glossary extraction.
- `test_clause_analyzer.py`: 6 tests covering clause segmentation, 10-category classification, entity extraction, and missing field handling.
- `test_risk_analyzer.py`: 4 tests covering unilateral cancellation, deposit forfeiture, uncapped liability, and safety disclaimers.
- `test_rag_engine.py`: 3 tests covering semantic TF-IDF retrieval, Telugu queries, citations, and out-of-domain rejection.
- `test_report_generator.py`: 4 tests covering TXT, Markdown, DOCX, and PDF report compilation.

- `test_text_simplifier.py`: 15 tests covering legalese and Telugu rewriting, TextRank summary, duty extraction, labelled amounts/periods, and the regression that different documents must produce different simplifications.

**All 55 tests pass in under 30 seconds.**

---

## 🔒 11. Privacy & Legal Safety

- **Zero Permanent Storage**: Uploaded documents are processed in memory and are never written to permanent disk storage by default.
- **No Data Retention / Training**: Document text is never utilized for model training.
- **Informational Tool**: LexiMind outputs are clearly marked as educational assistance and do not constitute formal legal advice or substitute an attorney's review.
- **Factual Integrity**: The system never hallucinates missing contract clauses, dates, or monetary amounts; missing information is explicitly marked as *"Not found"*.

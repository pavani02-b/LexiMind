"""
LexiMind Document Processor
Handles file validation, text extraction from digital PDFs, scanned PDFs, DOCX, TXT,
and image OCR with image preprocessing and Telugu OCR language support.
Provides detailed diagnostic checks and honest error reporting.
"""

import io
import os
from typing import Dict, Any, List
from PIL import Image, ImageEnhance, ImageOps
import pymupdf as fitz  # PyMuPDF
import docx
import pytesseract

from config import (
    TESSERACT_CMD,
    BASE_DIR,
    SUPPORTED_EXTENSIONS,
    find_tesseract_binary,
    find_tessdata_dir
)


class DocumentProcessingError(Exception):
    """Custom exception for document processing errors."""
    pass


def get_ocr_diagnostics() -> Dict[str, Any]:
    """
    Return comprehensive diagnostics regarding Tesseract installation,
    executable path, version, and installed language packs (Telugu and English).
    """
    cmd = TESSERACT_CMD or find_tesseract_binary()
    is_installed = bool(cmd and os.path.isfile(cmd))
    version_str = None
    installed_langs = []
    has_tel = False
    has_eng = False
    error_note = None

    if is_installed:
        try:
            pytesseract.pytesseract.tesseract_cmd = cmd
            version_str = str(pytesseract.get_tesseract_version())
            
            # Check tessdata directory
            tessdata_dir = find_tessdata_dir()
            custom_config = f'--tessdata-dir "{tessdata_dir}"' if tessdata_dir else ""
            try:
                installed_langs = pytesseract.get_languages(config=custom_config)
            except Exception:
                installed_langs = pytesseract.get_languages()

            # Also check local project tessdata directory
            local_tessdata = BASE_DIR / "tessdata"
            if (local_tessdata / "tel.traineddata").is_file() and "tel" not in installed_langs:
                installed_langs.append("tel")
            if (local_tessdata / "eng.traineddata").is_file() and "eng" not in installed_langs:
                installed_langs.append("eng")

            has_tel = "tel" in installed_langs
            has_eng = "eng" in installed_langs
        except Exception as e:
            error_note = str(e)
    else:
        error_note = (
            "Tesseract OCR binary was not found at standard Windows paths "
            "(C:\\Program Files\\Tesseract-OCR\\tesseract.exe) or on system PATH."
        )

    return {
        "is_available": is_installed and version_str is not None,
        "executable_path": cmd if is_installed else "Not Installed / Not Found",
        "version": version_str if version_str else "N/A",
        "languages": installed_langs,
        "has_telugu": has_tel,
        "has_english": has_eng,
        "tessdata_dir": find_tessdata_dir() or str(BASE_DIR / "tessdata"),
        "error_note": error_note
    }


def is_tesseract_available() -> bool:
    """Check if Tesseract OCR binary is installed and callable."""
    diag = get_ocr_diagnostics()
    return diag["is_available"]


def get_available_ocr_languages() -> List[str]:
    """Return the list of installed Tesseract language packs."""
    diag = get_ocr_diagnostics()
    return diag["languages"]


def validate_file(file_name: str, file_size: int) -> None:
    """
    Validate uploaded file name and size.
    Raises DocumentProcessingError if invalid.
    """
    if not file_name:
        raise DocumentProcessingError("No filename provided.")
    
    ext = os.path.splitext(file_name)[1].lower()
    if ext not in SUPPORTED_EXTENSIONS:
        raise DocumentProcessingError(
            f"Unsupported file format '{ext}'. Supported formats: {', '.join(SUPPORTED_EXTENSIONS)}"
        )
    
    if file_size <= 0:
        raise DocumentProcessingError("The uploaded file is empty (0 bytes). Please upload a valid document.")
    
    # 25MB maximum threshold
    if file_size > 25 * 1024 * 1024:
        raise DocumentProcessingError("File size exceeds 25 MB limit. Please upload a smaller document.")


def preprocess_image(image: Image.Image) -> Image.Image:
    """
    Preprocess image for optimal OCR extraction:
    - Fix EXIF orientation
    - Convert to grayscale
    - Enhance contrast
    - Auto-binarize using adaptive thresholding
    """
    try:
        # Correct image orientation based on EXIF tag
        image = ImageOps.exif_transpose(image)
    except Exception:
        pass

    # Small photos / screenshots: upscale so Telugu vowel signs are large enough for Tesseract
    if image.width < 1600:
        scale = 1600 / max(image.width, 1)
        image = image.resize((int(image.width * scale), int(image.height * scale)), Image.LANCZOS)

    # Convert to grayscale
    gray = image.convert("L")

    # Enhance contrast
    enhancer = ImageEnhance.Contrast(gray)
    enhanced = enhancer.enhance(1.8)

    # Clean sharpness
    sharpener = ImageEnhance.Sharpness(enhanced)
    sharpened = sharpener.enhance(1.4)

    return sharpened


def run_ocr_on_image(image: Image.Image, preferred_langs: str = "tel+eng") -> Dict[str, Any]:
    """
    Run Tesseract OCR on a PIL Image with Telugu and English support.
    Returns text and diagnostic metadata. Never fakes success.
    """
    diag = get_ocr_diagnostics()
    if not diag["is_available"]:
        return {
            "success": False,
            "text": "",
            "error": (
                "Tesseract OCR is not installed or not found on system PATH. "
                "Scanned documents and image files (such as JPG, JPEG, PNG) require the Tesseract OCR engine. "
                "Install it from https://github.com/UB-Mannheim/tesseract/wiki (tick 'Telugu' language data) "
                "or set TESSERACT_CMD in your .env file."
            )
        }

    # Ensure pytesseract points to discovered binary
    pytesseract.pytesseract.tesseract_cmd = diag["executable_path"]
    has_telugu = diag["has_telugu"]

    # Set TESSDATA_PREFIX in environment if custom tessdata directory is available
    tessdata_dir = diag.get("tessdata_dir", "")
    if tessdata_dir and os.path.isdir(tessdata_dir):
        os.environ["TESSDATA_PREFIX"] = tessdata_dir

    chosen_lang = "eng"
    warning = None

    if "tel" in preferred_langs:
        if has_telugu:
            chosen_lang = "tel+eng"
        else:
            chosen_lang = "eng"
            warning = (
                "Telugu OCR language data ('tel.traineddata') was not found in your Tesseract tessdata folder. "
                "Text was recognized using English mode only. For accurate Telugu legal document OCR, place "
                "'tel.traineddata' into your Tesseract tessdata directory."
            )

    preprocessed = preprocess_image(image)

    try:
        extracted = pytesseract.image_to_string(
            preprocessed,
            lang=chosen_lang
        )
        return {
            "success": True,
            "text": extracted.strip(),
            "lang_used": chosen_lang,
            "warning": warning
        }
    except Exception as e:
        return {
            "success": False,
            "text": "",
            "error": f"Tesseract OCR execution failed: {str(e)}"
        }


def extract_from_pdf(file_bytes: bytes) -> Dict[str, Any]:
    """
    Extract text from PDF (digital or scanned) page by page.
    Falls back to OCR if digital text is empty or minimal.
    """
    doc = None
    pages_data = []
    total_text = []
    warnings = []
    extraction_methods = set()

    try:
        doc = fitz.open(stream=file_bytes, filetype="pdf")
        total_pages = len(doc)
        if total_pages == 0:
            raise DocumentProcessingError("The PDF document has 0 pages.")

        for page_idx in range(total_pages):
            page = doc[page_idx]
            page_num = page_idx + 1
            page_text = page.get_text("text").strip()

            # Check if page has sufficient digital text
            if len(page_text) >= 40:
                pages_data.append({
                    "page_number": page_num,
                    "text": page_text,
                    "method": "digital"
                })
                total_text.append(f"--- Page {page_num} ---\n{page_text}")
                extraction_methods.add("digital_pdf")
            else:
                # Scanned page or image-only page: render to pixmap and run OCR
                pix = page.get_pixmap(dpi=200)
                img = Image.open(io.BytesIO(pix.tobytes("png")))
                ocr_res = run_ocr_on_image(img, preferred_langs="tel+eng")

                if ocr_res["success"] and ocr_res["text"]:
                    pages_data.append({
                        "page_number": page_num,
                        "text": ocr_res["text"],
                        "method": f"ocr ({ocr_res.get('lang_used', 'unknown')})"
                    })
                    total_text.append(f"--- Page {page_num} (Scanned OCR) ---\n{ocr_res['text']}")
                    extraction_methods.add("scanned_pdf_ocr")
                    if ocr_res.get("warning"):
                        warnings.append(f"Page {page_num}: {ocr_res['warning']}")
                else:
                    # Digital text was empty and OCR failed/unavailable
                    err_msg = ocr_res.get("error", "No readable text detected on this scanned page.")
                    pages_data.append({
                        "page_number": page_num,
                        "text": "",
                        "method": "failed",
                        "error": err_msg
                    })
                    warnings.append(f"Page {page_num}: {err_msg}")

        full_extracted = "\n\n".join(total_text).strip()
        method_str = ", ".join(extraction_methods) if extraction_methods else "none"

        return {
            "success": bool(full_extracted),
            "text": full_extracted,
            "page_count": total_pages,
            "pages": pages_data,
            "extraction_method": method_str,
            "warnings": warnings
        }
    except Exception as e:
        if isinstance(e, DocumentProcessingError):
            raise
        raise DocumentProcessingError(f"Failed to process PDF: {str(e)}")
    finally:
        if doc:
            doc.close()


def extract_from_docx(file_bytes: bytes) -> Dict[str, Any]:
    """Extract text from a DOCX Word document including paragraphs and tables."""
    try:
        doc = docx.Document(io.BytesIO(file_bytes))
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
        
        # Also extract table text
        table_texts = []
        for table in doc.tables:
            for row in table.rows:
                row_str = " | ".join([cell.text.strip() for cell in row.cells if cell.text.strip()])
                if row_str:
                    table_texts.append(row_str)

        combined = paragraphs + table_texts
        full_text = "\n\n".join(combined).strip()

        if not full_text:
            raise DocumentProcessingError("The uploaded DOCX document does not contain any readable text.")

        return {
            "success": True,
            "text": full_text,
            "page_count": 1,
            "pages": [{"page_number": 1, "text": full_text, "method": "docx"}],
            "extraction_method": "docx",
            "warnings": []
        }
    except Exception as e:
        if isinstance(e, DocumentProcessingError):
            raise
        raise DocumentProcessingError(f"Failed to process DOCX document: {str(e)}")


def extract_from_txt(file_bytes: bytes) -> Dict[str, Any]:
    """Extract text from a TXT file with multi-encoding fallback."""
    encodings = ["utf-8", "utf-8-sig", "utf-16", "latin-1", "cp1252"]
    text = ""
    used_encoding = None

    for enc in encodings:
        try:
            text = file_bytes.decode(enc).strip()
            used_encoding = enc
            break
        except (UnicodeDecodeError, LookupError):
            continue

    if not text and file_bytes:
        raise DocumentProcessingError("Unable to decode text file. Please ensure it is saved in UTF-8 encoding.")

    return {
        "success": bool(text),
        "text": text,
        "page_count": 1,
        "pages": [{"page_number": 1, "text": text, "method": f"txt ({used_encoding})"}],
        "extraction_method": f"txt_{used_encoding}",
        "warnings": []
    }


def extract_from_image_file(file_bytes: bytes) -> Dict[str, Any]:
    """
    Extract text from an image (PNG, JPG, JPEG) using OCR.
    Explicitly raises DocumentProcessingError if OCR is unavailable or fails,
    preventing silent reporting of zero words.
    """
    try:
        img = Image.open(io.BytesIO(file_bytes))
    except Exception as e:
        raise DocumentProcessingError(f"Failed to open image file: {str(e)}. Please ensure it is a valid JPG, JPEG, or PNG.")

    ocr_res = run_ocr_on_image(img, preferred_langs="tel+eng")

    if not ocr_res["success"]:
        # Honest error: Tesseract is not installed or failed
        raise DocumentProcessingError(ocr_res.get("error", "OCR execution failed on the uploaded image."))

    recognized_text = ocr_res.get("text", "").strip()
    if not recognized_text:
        # Honest reporting: 0 words recognized
        raise DocumentProcessingError(
            "Tesseract OCR processed the image, but recognized 0 readable words. "
            "Possible causes: (1) The image resolution or contrast is too low; (2) The document is in Telugu but 'tel.traineddata' is not installed; (3) The image is blank or handwritten. "
            "Please upload a clearer image or use digital PDF/DOCX format."
        )

    warnings = []
    if ocr_res.get("warning"):
        warnings.append(ocr_res["warning"])

    return {
        "success": True,
        "text": recognized_text,
        "page_count": 1,
        "pages": [{"page_number": 1, "text": recognized_text, "method": f"image_ocr ({ocr_res.get('lang_used', 'eng')})"}],
        "extraction_method": f"image_ocr ({ocr_res.get('lang_used', 'eng')})",
        "warnings": warnings
    }


def process_uploaded_document(file_name: str, file_bytes: bytes) -> Dict[str, Any]:
    """
    Main dispatch function for uploaded legal documents.
    Validates file, invokes appropriate extractor, and returns standardized result.
    Raises DocumentProcessingError on failure.
    """
    validate_file(file_name, len(file_bytes))
    ext = os.path.splitext(file_name)[1].lower()

    if ext == ".pdf":
        result = extract_from_pdf(file_bytes)
    elif ext == ".docx":
        result = extract_from_docx(file_bytes)
    elif ext == ".txt":
        result = extract_from_txt(file_bytes)
    elif ext in [".png", ".jpg", ".jpeg"]:
        result = extract_from_image_file(file_bytes)
    else:
        raise DocumentProcessingError(f"Unsupported file format: {ext}")

    result["filename"] = file_name
    result["file_size_bytes"] = len(file_bytes)
    result["word_count"] = len(result["text"].split()) if result["text"] else 0
    result["char_count"] = len(result["text"]) if result["text"] else 0

    return result

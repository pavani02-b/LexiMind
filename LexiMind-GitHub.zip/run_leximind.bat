@echo off
TITLE LexiMind - AI Legal Document Simplification System
REM Always run from this file's folder, with this project's own virtual environment
cd /d "%~dp0"

IF NOT EXIST ".venv\Scripts\python.exe" (
    echo [SETUP] Creating virtual environment and installing requirements - first run only, takes a few minutes...
    python -m venv .venv || (echo [ERROR] Python not found. Install Python 3.10+ and try again. & pause & exit /b 1)
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt || (echo [ERROR] Installing requirements failed. & pause & exit /b 1)
)

echo Starting LexiMind at http://localhost:8501 ...
".venv\Scripts\python.exe" -m streamlit run app.py
pause
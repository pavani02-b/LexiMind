"""
LexiMind Configuration Module
Handles environment variables, API configurations, system paths, and application constants.
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Base directory paths
BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env", override=True)

# AI API Configurations
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY", "")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")

# Preferred AI Model identifiers (older models get retired; LexiMind auto-falls back to an available flash model)
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

# Maximum seconds to wait for the AI service before using the offline engine instead
AI_TIMEOUT_SECONDS = int(os.getenv("AI_TIMEOUT_SECONDS", "60"))

# Primary Application Behavior Defaults
DEFAULT_SIMPLIFICATION_LEVEL = "Simple"  # "Simple" or "Detailed"
TRANSLATION_ENABLED_BY_DEFAULT = False   # Primary workflow is same-language simplification

# Tesseract OCR Executable Paths
DEFAULT_TESSERACT_PATHS = [
    os.getenv("TESSERACT_CMD", ""),
    r"C:\Program Files\Tesseract-OCR\tesseract.exe",
    r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
    os.path.expandvars(r"%LOCALAPPDATA%\Tesseract-OCR\tesseract.exe"),
    os.path.expandvars(r"%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe"),
    str(BASE_DIR / "tesseract" / "tesseract.exe"),
]

def find_tesseract_binary() -> str:
    """Find a valid Tesseract OCR binary on Windows or system PATH."""
    for p in DEFAULT_TESSERACT_PATHS:
        if p and os.path.isfile(p):
            return p
    import shutil
    path_exec = shutil.which("tesseract")
    if path_exec:
        return path_exec
    return ""

TESSERACT_CMD = find_tesseract_binary()

# Tessdata Language Model Paths
DEFAULT_TESSDATA_DIRS = [
    os.getenv("TESSDATA_PREFIX", ""),
    os.path.expandvars(r"%LOCALAPPDATA%\Programs\Tesseract-OCR\tessdata"),
    r"C:\Program Files\Tesseract-OCR\tessdata",
    r"C:\Program Files (x86)\Tesseract-OCR\tessdata",
    str(BASE_DIR / "tessdata"),
]

def find_tessdata_dir() -> str:
    """Find an existing tessdata folder with language models."""
    for d in DEFAULT_TESSDATA_DIRS:
        if d and os.path.isdir(d):
            return d
    if TESSERACT_CMD:
        parent_tessdata = os.path.join(os.path.dirname(TESSERACT_CMD), "tessdata")
        if os.path.isdir(parent_tessdata):
            return parent_tessdata
    return ""

TESSDATA_DIR = find_tessdata_dir()
if TESSDATA_DIR:
    os.environ["TESSDATA_PREFIX"] = TESSDATA_DIR

# System Fonts for Telugu & Unicode Rendering in PDF
DEFAULT_TELUGU_FONT_PATHS = [
    r"C:\Windows\Fonts\Nirmala.ttc",
    r"C:\Windows\Fonts\NirmalaB.ttc",
    r"C:\Windows\Fonts\gautami.ttf",
    r"C:\Windows\Fonts\gautamib.ttf",
    str(BASE_DIR / "fonts" / "Nirmala.ttf"),
    str(BASE_DIR / "fonts" / "Mandali-Regular.ttf"),
]

def find_telugu_font() -> str:
    """Find an installed or bundled TrueType / OpenType font supporting Telugu script."""
    for font_path in DEFAULT_TELUGU_FONT_PATHS:
        if os.path.isfile(font_path):
            return font_path
    return ""

TELUGU_FONT_PATH = find_telugu_font()

# Supported file extensions
SUPPORTED_EXTENSIONS = [".pdf", ".docx", ".txt", ".png", ".jpg", ".jpeg"]

# Clause Classification Categories
CLAUSE_CATEGORIES = [
    "Payment and Financial Terms",
    "Term and Termination",
    "Renewal and Extension",
    "Confidentiality and Non-Disclosure",
    "Liability and Limitation of Liability",
    "Indemnification",
    "Dispute Resolution and Jurisdiction",
    "Property, Ownership, and Title",
    "Obligations and Covenants of Parties",
    "Representations and Warranties",
    "General and Miscellaneous Provisions",
]

# Risk Severity Levels
RISK_LEVEL_HIGH = "High Risk"
RISK_LEVEL_MEDIUM = "Medium Risk"
RISK_LEVEL_LOW = "Advisory / Review"

# Legal Safety Disclaimer
LEGAL_SAFETY_DISCLAIMER = (
    "LEGAL DISCLAIMER: LexiMind is an AI-powered academic and informational assistance tool. "
    "The simplified texts, clause classifications, risk indicators, and extracted details generated "
    "by this application DO NOT constitute formal legal advice, certified translation, or a substitute "
    "for an attorney's professional review. The original document remains the sole legally binding version."
)

"""
LexiMind Clause Analyzer
Segments contracts into logical clauses, classifies clauses into standard legal categories,
and extracts verified key entities (parties, dates, amounts, property details, numbers).
Preserves original wording and outputs 'Not found' when fields are missing.
"""

import re
from typing import Dict, Any, List, Tuple
from text_simplifier import normalize_text, is_heading_line, split_sentences


# Keyword definitions for Telugu & English Clause Classification
CLASSIFICATION_KEYWORDS = {
    "Payment and Financial Terms": [
        "payment", "rent", "fee", "consideration", "deposit", "installment", "price", "amount",
        "చెల్లింపు", "అద్దె", "ధరావతు", "రూపాయలు", "మొత్తం", "క్రయధనం", "సెక్యూరిటీ డిపాజిట్", "నెలవారీ"
    ],
    "Term and Termination": [
        "termination", "terminate", "term", "term of", "duration", "expiration", "expire", "notice period", "cancel", "lock-in",
        "రద్దు", "ముగింపు", "కాలపరిమితి", "నోటీసు", "రద్దుపరచబడును", "గడువు", "లాక్-ఇన్"
    ],
    "Renewal and Extension": [
        "renewal", "renew", "extension", "extend", "prolong",
        "పునరుద్ధరణ", "పొడిగింపు", "మరల", "కాలం పొడిగించు"
    ],
    "Confidentiality and Non-Disclosure": [
        "confidential", "proprietary", "trade secret", "non-disclosure", "disclose",
        "రహస్య", "గోప్యత", "బహిర్గతం చేయరాదు", "రహస్య సమాచారం"
    ],
    "Liability and Limitation of Liability": [
        "liability", "liable", "limitation of liability", "consequential damages", "penalty",
        "బాధ్యత", "నష్టపరిహారం", "జరిమానా", "బాధ్యులు", "నష్టపరిహార బాధ్యత"
    ],
    "Indemnification": [
        "indemnify", "indemnity", "hold harmless", "defend",
        "పరిహారము", "పూచీకత్తు", "రక్షణ కల్పించు", "హామీ"
    ],
    "Dispute Resolution and Jurisdiction": [
        "dispute", "arbitration", "jurisdiction", "court", "governing law", "venue",
        "వివాద", "కోర్టు", "న్యాయస్థానం", "మధ్యవర్తిత్వం", "పరిధి", "వివాద పరిష్కారము"
    ],
    "Property, Ownership, and Title": [
        "property", "premises", "land", "plot", "survey no", "boundaries", "title", "ownership",
        "ఆస్తి", "స్థిరాస్తి", "స్థలం", "సర్వే నెం", "చతుస్సీమలు", "హక్కులు", "తాళాలు", "స్వాధీనం"
    ],
    "Obligations and Covenants of Parties": [
        "obligations", "covenant", "undertake", "shall not", "maintain", "maintenance", "repair", "duties",
        "నిబంధనలు", "కర్తవ్యం", "చేయకూడదు", "నిర్వహణ", "బాధ్యతలు"
    ],
    "Representations and Warranties": [
        "represent", "warrants", "representation", "warranty", "as is",
        "ధృవీకరణ", "హామీలు", "ప్రకటన"
    ]
}


SIGNATURE_BLOCK_PATTERN = re.compile(
    r"(?:\n|^)\s*(?:IN\s+WITNESS\s+WHEREOF|WITNESSES\s*:|సాక్షులు\s*:|ఉభయ\s*పక్షములవారు\s*పూర్తి\s*సమ్మతితో\s*సాక్షుల)",
    re.IGNORECASE
)


def _split_unnumbered_text(text: str) -> List[str]:
    """Split text without numbered clauses into sections using blank lines, headings, or sentence groups."""
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    if len(paragraphs) >= 3:
        return paragraphs

    # Headings (ALL CAPS lines or short lines ending with ':') start new sections
    sections: List[str] = []
    for line in text.split("\n"):
        if not line.strip():
            continue
        if is_heading_line(line) or not sections:
            sections.append(line.strip())
        else:
            sections[-1] += "\n" + line.strip()
    if len(sections) >= 3:
        return sections

    # Last resort: groups of 4 sentences
    sentences = split_sentences(text)
    return [" ".join(sentences[i:i + 4]) for i in range(0, len(sentences), 4)] or [text.strip()]


def segment_into_clauses(text: str) -> List[Dict[str, Any]]:
    """
    Split contract text into individual clauses or logical sections.
    Recognizes numbered clauses (1., 1.1, Clause 1, Article 1, నిబంధన 1, etc.),
    headings, paragraph boundaries, and the closing signature / witness block.
    """
    if not text or not text.strip():
        return []

    text = normalize_text(text)

    # Separate the signature / witness block so witness numbering is not mistaken for clauses
    signature_text = ""
    sig_match = SIGNATURE_BLOCK_PATTERN.search(text)
    if sig_match and sig_match.start() > len(text) * 0.4:
        signature_text = text[sig_match.start():].strip()
        text = text[:sig_match.start()].rstrip()

    # Regex pattern to match clause boundaries
    boundary_pattern = re.compile(
        r"(?:\n|^)\s*(?:(?:Clause|Section|Article|Point|నిబంధన|షరతు|ఆర్టికల్)\s*\d+[\.\:\)]?|\d+[\.\:\)]|\([a-z0-9]+\))\s+",
        re.IGNORECASE
    )

    matches = list(boundary_pattern.finditer(text))
    clauses = []

    if not matches:
        for idx, para in enumerate(_split_unnumbered_text(text), start=1):
            first_line = para.split("\n")[0].strip()
            title = first_line[:60] if is_heading_line(first_line) else f"Section {idx}"
            clauses.append({
                "clause_id": f"Section {idx}",
                "title": title,
                "text": para,
                "category": classify_single_clause(para)
            })
        if signature_text:
            clauses.append(_signature_clause(signature_text))
        return clauses

    # Process preamble/recital if present before first clause
    first_start = matches[0].start()
    if first_start > 30:
        preamble = text[:first_start].strip()
        if preamble:
            clauses.append({
                "clause_id": "Preamble / Recitals",
                "title": "Preamble / Recitals (ప్రవేశిక / పూర్వాపరాలు)",
                "text": preamble,
                "category": "Property, Ownership, and Title" if any(k in preamble.lower() for k in ["property", "స్థిరాస్తి", "survey"]) else "General and Miscellaneous Provisions"
            })

    for i in range(len(matches)):
        start_idx = matches[i].start()
        end_idx = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        chunk = text[start_idx:end_idx].strip()

        # Extract title from first line
        first_line = chunk.split("\n")[0].strip()
        title = first_line[:60] if len(first_line) > 60 else first_line
        clause_id = f"Clause {i + 1}"

        category = classify_single_clause(chunk)

        clauses.append({
            "clause_id": clause_id,
            "title": title,
            "text": chunk,
            "category": category
        })

    if signature_text:
        clauses.append(_signature_clause(signature_text))

    return clauses


def _signature_clause(signature_text: str) -> Dict[str, Any]:
    return {
        "clause_id": "Signatures & Witnesses",
        "title": "Signatures & Witnesses (సంతకాలు / సాక్షులు)",
        "text": signature_text,
        "category": "General and Miscellaneous Provisions"
    }


def _keyword_count(keyword: str, text_lower: str) -> int:
    """Count keyword hits; English keywords must match whole words ('fee' must not match 'feet')."""
    kw = keyword.lower()
    if re.search(r"[a-z]", kw):
        return len(re.findall(r"(?<![a-z])" + re.escape(kw) + r"(?:s|es|ed|ing)?(?![a-z])", text_lower))
    return text_lower.count(kw)


def classify_single_clause(clause_text: str) -> str:
    """Classify a clause text into one of the standard legal categories."""
    text_lower = clause_text.lower()
    scores = {}

    # A clause heading (e.g. "3. RENT AND PAYMENT:") is the strongest signal, so it counts double
    first_line = text_lower.split("\n")[0][:80]

    for category, keywords in CLASSIFICATION_KEYWORDS.items():
        score = 0
        for kw in keywords:
            hits = _keyword_count(kw, text_lower)
            if hits:
                score += 1 + (2 if _keyword_count(kw, first_line) else 0)
        if score > 0:
            scores[category] = score

    if not scores:
        return "General and Miscellaneous Provisions"

    # Return category with highest keyword matches
    return max(scores, key=scores.get)


def extract_parties(text: str) -> List[Dict[str, str]]:
    """Extract parties, their legal roles, and names from Telugu and English contracts."""
    parties = []
    
    # 1. Telugu patterns (Standard and Traditional Deed / Sada Bainama formats)
    telugu_roles = [
        ("విక్రయదారుడు / అమ్మకందారుడు (Seller/Vendor)", r"(?:విక్రయదారు(?:డు)?|అమ్మకందారు(?:డు)?)\s*(?:\([^\)]+\))?\s*[:\-]?\s*([^\n,]+)"),
        ("ఖరీదుదారుడు / కొనుగోలుదారు (Buyer/Purchaser)", r"(?:ఖరీదుదారు(?:డు)?|కొనుగోలుదారు(?:డు)?)\s*(?:\([^\)]+\))?\s*[:\-]?\s*([^\n,]+)"),
        ("యజమాని / కౌలుకు ఇచ్చేవారు (Lessor/Landlord)", r"(?:యజమాని|కౌలు\s*ఇచ్చేవారు|మొదటి\s*పక్షం)\s*(?:\([^\)]+\))?\s*[:\-]?\s*([^\n,]+)"),
        ("అద్దెదారుడు / కౌలుదారు (Lessee/Tenant)", r"(?:అద్దెదారు(?:డు)?|కౌలుదారు|రెండవ\s*పక్షం)\s*(?:\([^\)]+\))?\s*[:\-]?\s*([^\n,]+)"),
    ]
    for role_name, pattern in telugu_roles:
        m = re.search(pattern, text)
        if m:
            clean_name = m.group(1).strip()
            # If line is empty or just punctuation/colons, check next line
            clean_name = re.sub(r"^\s*\([^\)]+\)\s*[:\-]?", "", clean_name).strip()
            if not clean_name or clean_name.startswith(":"):
                rest = text[m.end():].strip()
                clean_name = rest.split("\n")[0].split(",")[0].strip() if rest else ""
            clean_name = re.sub(r"^[\s\.\-–—_0-9॥లసం\:]+", "", clean_name).strip()
            if len(clean_name) > 2 and len(clean_name) < 80:
                parties.append({"role": role_name, "name": clean_name})

    # Traditional Telugu Deed Parties: వ్రాయించుకున్నవారు (Buyer) and వ్రాయించియిచ్చినవారు (Seller)
    if not any("ఖరీదుదారుడు" in p["role"] for p in parties):
        m_buyer = re.search(r"(?:వ్రాయించుకున్నవారు|రాయించుకున్నవారు)[\s\:\-]+([\s\S]+?)(?=(?:వ్రాయించి|రాయించి|బ్రాయీంచి|వ్రాయించిన|\Z))", text)
        if m_buyer:
            b_text = m_buyer.group(1).strip()
            m_gari = re.search(r"([^\n]+)\s*గారికి", b_text)
            m_kapuram = re.search(r"కాపురం\s*(?:[A-Za-z]+)?\s*([A-Za-z\u0C00-\u0C7F\.\s]+)", b_text)
            if m_gari:
                raw_gari = m_gari.group(1).strip()
                clean_name = re.sub(r"^[-–—\.\s]+", "", raw_gari)
                clean_name = re.sub(r"(?:భార్య|కుమారుడు|కుమారై|సుమారు|\d+\s*సం[\.|\/|ల]*|గారికి)", "", clean_name).strip()
                clean_name = re.sub(r"^[\s\.\-–—_0-9॥లసం\:]+", "", clean_name).strip()
            elif m_kapuram:
                clean_name = m_kapuram.group(1).split("\n")[0].split(",")[0].strip()
                clean_name = re.sub(r"(?:భార్య|కుమారుడు|కుమారై|సుమారు|\d+\s*సం[\.|\/|ల]*|గారికి)", "", clean_name).strip()
                clean_name = re.sub(r"^[\s\.\-–—_0-9॥లసం\:]+", "", clean_name).strip()
            else:
                raw_lines = [l.strip() for l in b_text.split("\n") if l.strip()]
                clean_name = raw_lines[-1] if raw_lines else b_text
                clean_name = re.sub(r"(?:భార్య|కుమారుడు|కుమారై|సుమారు|\d+\s*సం[\.|\/|ల]*|గారికి)", "", clean_name).strip()
                clean_name = re.sub(r"^[\s\.\-–—_0-9॥లసం\:]+", "", clean_name).strip()
            if len(clean_name) > 2:
                parties.append({"role": "ఖరీదుదారుడు / కొనుగోలుదారు (Buyer/Purchaser)", "name": clean_name})

    if not any("విక్రయదారుడు" in p["role"] for p in parties):
        m_seller = re.search(r"(?:వ్రాయించియిచ్చినవారు|రాయించియిచ్చినవారు|బ్రాయీంచియిచ్చినవారు)[\s\:\-]+([\s\S]+?)(?=(?:అను\s*నేను|\Z))", text)
        if m_seller:
            s_text = m_seller.group(1).strip()
            raw_lines = [l.strip() for l in s_text.split("\n") if l.strip()]
            clean_name = raw_lines[-1] if raw_lines else s_text
            clean_name = re.sub(r"(?:కుమారుడు|కుమారై|భార్య|సుమారు|\d+\s*(?:Sous|సం)[\.|\/|ల]*|అను\s*నేను)", "", clean_name).strip()
            clean_name = re.sub(r"^[\s\.\-–—_0-9॥లసం\:]+", "", clean_name).strip()
            if len(clean_name) > 2:
                parties.append({"role": "విక్రయదారుడు / అమ్మకందారుడు (Seller/Vendor)", "name": clean_name})

    # 2. English Preamble Patterns:
    # "BETWEEN <Party 1> ... (hereinafter called the "<Role 1>") ... AND <Party 2> ... (hereinafter called the "<Role 2>")"
    role_map = {
        "vendor": "Vendor / Seller",
        "seller": "Vendor / Seller",
        "purchaser": "Purchaser / Buyer",
        "buyer": "Purchaser / Buyer",
        "lessor": "Lessor / Landlord",
        "landlord": "Lessor / Landlord",
        "lessee": "Lessee / Tenant",
        "tenant": "Lessee / Tenant",
        "first party": "First Party",
        "second party": "Second Party",
        "disclosing party": "Disclosing Party",
        "receiving party": "Receiving Party",
        "employer": "Employer / Company",
        "employee": "Employee / Contractor",
        "deponent": "Deponent / Executant",
        "executant": "Deponent / Executant"
    }

    p1_m = re.search(
        r"(?:BETWEEN|Between)\s+([A-Za-z\s\.]+?)(?:,|\s+S\/o|\s+D\/o|\s+W\/o|\s+son\s+of|\s+daughter\s+of|\s+wife\s+of|\s+aged|\s+residing|\s*\(hereinafter|\s*\(\s*hereinafter)[\s\S]{0,350}?(?:hereinafter\s+called|referred\s+to\s+as|called\s+the)\s+[\"']?(?:the\s+)?([A-Za-z\s\/]+?)[\"']?\s*[\,\)]",
        text,
        re.IGNORECASE
    )
    if p1_m:
        raw_name = p1_m.group(1).strip()
        role = p1_m.group(2).strip()
        name = re.sub(r"^(?:AND|OR|BETWEEN|THE|MR\.?|MRS\.?|MS\.?|SRI)\s+", "", raw_name, flags=re.IGNORECASE).strip()
        name = re.sub(r"\s+(?:S\/o|D\/o|W\/o|aged|residing).*", "", name, flags=re.IGNORECASE).strip()
        name = re.sub(r"[\s\,\;]+$", "", name).strip()
        clean_role = role_map.get(role.lower(), role.title())
        if len(name) > 2 and name.lower() not in ["years", "part", "other", "first", "second", "one"]:
            parties.append({"role": clean_role, "name": name})

    p2_m = re.search(
        r"(?:AND|And)\s+([A-Za-z\s\.]+?)(?:,|\s+S\/o|\s+D\/o|\s+W\/o|\s+son\s+of|\s+daughter\s+of|\s+wife\s+of|\s+aged|\s+residing|\s*\(hereinafter|\s*\(\s*hereinafter)[\s\S]{0,350}?(?:hereinafter\s+called|referred\s+to\s+as|called\s+the)\s+[\"']?(?:the\s+)?([A-Za-z\s\/]+?)[\"']?\s*[\,\)]",
        text,
        re.IGNORECASE
    )
    if p2_m:
        raw_name = p2_m.group(1).strip()
        role = p2_m.group(2).strip()
        name = re.sub(r"^(?:AND|OR|BETWEEN|THE|MR\.?|MRS\.?|MS\.?|SRI)\s+", "", raw_name, flags=re.IGNORECASE).strip()
        name = re.sub(r"\s+(?:S\/o|D\/o|W\/o|aged|residing).*", "", name, flags=re.IGNORECASE).strip()
        name = re.sub(r"[\s\,\;]+$", "", name).strip()
        clean_role = role_map.get(role.lower(), role.title())
        if len(name) > 2 and name.lower() not in ["years", "part", "other", "first", "second", "one"] and not any(p["name"] == name for p in parties):
            parties.append({"role": clean_role, "name": name})

    # 3. English explicit role header patterns (e.g. "Vendor: Ravi Kumar")
    english_roles = [
        ("Vendor / Seller", r"(?:Vendor|Seller)\s*(?:\([^\)]+\))?\s*[:\-]\s*([^\n,]+)?"),
        ("Purchaser / Buyer", r"(?:Purchaser|Buyer)\s*(?:\([^\)]+\))?\s*[:\-]\s*([^\n,]+)?"),
        ("Lessor / Landlord", r"(?:Lessor|Landlord|First Party)\s*(?:\([^\)]+\))?\s*[:\-]\s*([^\n,]+)?"),
        ("Lessee / Tenant", r"(?:Lessee|Tenant|Second Party)\s*(?:\([^\)]+\))?\s*[:\-]\s*([^\n,]+)?"),
        ("Deponent / Executant", r"(?:Deponent|Executant|Declarant)\s*(?:\([^\)]+\))?\s*[:\-]\s*([^\n,]+)?"),
        ("Disclosing Party", r"(?:Disclosing Party)\s*(?:\([^\)]+\))?\s*[:\-]\s*([^\n,]+)?"),
        ("Receiving Party", r"(?:Receiving Party)\s*(?:\([^\)]+\))?\s*[:\-]\s*([^\n,]+)?"),
        ("Employer", r"(?:Employer|Company)\s*(?:\([^\)]+\))?\s*[:\-]\s*([^\n,]+)?"),
        ("Employee / Contractor", r"(?:Employee|Consultant)\s*(?:\([^\)]+\))?\s*[:\-]\s*([^\n,]+)?"),
    ]
    for role_name, pattern in english_roles:
        if not any(role_name in p["role"] for p in parties):
            m = re.search(pattern, text, re.IGNORECASE)
            if m:
                clean_name = m.group(1).strip() if m.group(1) else ""
                if not clean_name or clean_name.startswith(":"):
                    rest = text[m.end():].strip()
                    clean_name = rest.split("\n")[0].split(",")[0].strip() if rest else ""
                clean_name = re.sub(r"^[–—\-:\s]+", "", clean_name).strip()
                clean_name = re.sub(r"\s*\([^)]*\)\s*$", "", clean_name).strip()  # "Rajesh M. (Deponent)" -> "Rajesh M."
                if len(clean_name) > 2 and len(clean_name) < 80 and not any(p["name"] == clean_name for p in parties):
                    parties.append({"role": role_name, "name": clean_name})

    # Signature blocks & role annotations: e.g. "Ravi Kumar (Vendor)" or "Suresh Babu (Purchaser)"
    if not any("Vendor" in p["role"] for p in parties):
        m_vend = re.search(r"([A-Za-z\.\s\n]+?)\s*\(\s*(?:Vendor|Seller)\s*\)", text, re.IGNORECASE)
        if m_vend:
            clean_n = m_vend.group(1).split("\n")[-1].strip()
            clean_n = re.sub(r"^(?:AND|OR|BETWEEN|THE|MR\.?|MRS\.?|MS\.?|SRI)\s+", "", clean_n, flags=re.IGNORECASE).strip()
            clean_n = re.sub(r"\([^\)]*\)", "", clean_n).strip()
            if len(clean_n) > 2 and len(clean_n) < 60 and clean_n.lower() not in ["years", "part", "other", "first", "second", "one"]:
                parties.append({"role": "Vendor / Seller", "name": clean_n})

    if not any("Purchaser" in p["role"] for p in parties):
        m_purch = re.search(r"([A-Za-z\.\s\n]+?)\s*\(\s*(?:Purchaser|Buyer)\s*\)", text, re.IGNORECASE)
        if m_purch:
            clean_n = m_purch.group(1).split("\n")[-1].strip()
            clean_n = re.sub(r"^(?:AND|OR|BETWEEN|THE|MR\.?|MRS\.?|MS\.?|SRI)\s+", "", clean_n, flags=re.IGNORECASE).strip()
            clean_n = re.sub(r"\([^\)]*\)", "", clean_n).strip()
            if len(clean_n) > 2 and len(clean_n) < 60 and clean_n.lower() not in ["years", "part", "other", "first", "second", "one"]:
                parties.append({"role": "Purchaser / Buyer", "name": clean_n})

    if not any("Deponent" in p["role"] for p in parties):
        m_dep = re.search(r"([A-Za-z\.\s\n]+?)\s*\(\s*(?:Deponent|Executant)\s*\)", text, re.IGNORECASE)
        if m_dep:
            clean_n = m_dep.group(1).split("\n")[-1].strip()
            clean_n = re.sub(r"^(?:AND|OR|BETWEEN|THE|MR\.?|MRS\.?|MS\.?|SRI)\s+", "", clean_n, flags=re.IGNORECASE).strip()
            clean_n = re.sub(r"\([^\)]*\)", "", clean_n).strip()
            if len(clean_n) > 2 and len(clean_n) < 60 and clean_n.lower() not in ["years", "part", "other", "first", "second", "one"]:
                parties.append({"role": "Deponent / Executant", "name": clean_n})

    # Lessor / Lessee signature or hereinafter patterns
    if not any("Lessor" in p["role"] for p in parties):
        m_less = re.search(r"([A-Za-z\.\s\n]+?)(?:,\s*residing|\s*\(hereinafter|\s*\(\s*(?:Lessor|Landlord)\s*\))[\s\S]{0,120}?(?:Lessor|Landlord)", text, re.IGNORECASE)
        if m_less:
            clean_n = m_less.group(1).split("\n")[-1].strip()
            clean_n = re.sub(r"^(?:AND|OR|BETWEEN|THE|MR\.?|MRS\.?|MS\.?|SRI)\s+", "", clean_n, flags=re.IGNORECASE).strip()
            clean_n = re.sub(r"\([^\)]*\)", "", clean_n).strip()
            if len(clean_n) > 2 and len(clean_n) < 60 and clean_n.lower() not in ["years", "part", "other", "first", "second", "one"]:
                parties.append({"role": "Lessor / Landlord", "name": clean_n})

    if not any("Lessee" in p["role"] for p in parties):
        m_lessee = re.search(r"(?:AND|AND\s+THE)[\s\S]*?([A-Za-z\.\s\n]+?)(?:,\s*residing|\s*\(hereinafter|\s*\(\s*(?:Lessee|Tenant)\s*\))[\s\S]{0,120}?(?:Lessee|Tenant)", text, re.IGNORECASE)
        if m_lessee:
            clean_n = m_lessee.group(1).split("\n")[-1].strip()
            clean_n = re.sub(r"^(?:AND|OR|BETWEEN|THE|MR\.?|MRS\.?|MS\.?|SRI)\s+", "", clean_n, flags=re.IGNORECASE).strip()
            clean_n = re.sub(r"\([^\)]*\)", "", clean_n).strip()
            if len(clean_n) > 2 and len(clean_n) < 60 and clean_n.lower() not in ["years", "part", "other", "first", "second", "one"]:
                parties.append({"role": "Lessee / Tenant", "name": clean_n})

    # Generic Party Matching if specific roles not found
    if not parties:
        between_match = re.search(r"between\s+([A-Za-z\s\.]+?)\s+and\s+([A-Za-z\s\.]+?)(?:\.|\n|dated)", text, re.IGNORECASE)
        if between_match:
            parties.append({"role": "First Party", "name": between_match.group(1).strip()})
            parties.append({"role": "Second Party", "name": between_match.group(2).strip()})

    return parties


def extract_dates(text: str) -> List[str]:
    """Extract execution dates, commencement dates, and deadlines."""
    dates = []
    
    # 1. Preamble execution date (e.g. "entered into on this 27th day of October, 2026")
    preamble_date = re.search(
        r"(?:entered\s+into\s+on\s+this|made\s+(?:and\s+entered\s+into\s+)?on\s+this|dated|executed\s+on)\s+([0-9]{1,2}(?:st|nd|rd|th)?\s+(?:day\s+of\s+)?[A-Za-z]+\s*,?\s*\d{4})",
        text,
        re.IGNORECASE
    )
    if preamble_date:
        dates.append(preamble_date.group(1).strip())

    # 2. Date formats with full month names (e.g. "27th day of October, 2026", "October 27, 2026", "27 October 2026")
    pat_month1 = r"\b\d{1,2}(?:st|nd|rd|th)?\s+(?:day\s+of\s+)?(?:January|February|March|April|May|June|July|August|September|October|November|December),?\s+\d{4}\b"
    pat_month2 = r"\b(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2}(?:st|nd|rd|th)?,?\s+\d{4}\b"
    for m in re.finditer(pat_month1, text, re.IGNORECASE):
        d = m.group(0).strip()
        if d not in dates:
            dates.append(d)
    for m in re.finditer(pat_month2, text, re.IGNORECASE):
        d = m.group(0).strip()
        if d not in dates:
            dates.append(d)

    # 3. Telugu date formats
    te_months = r"(?:జనవరి|ఫిబ్రవరి|మార్చి|ఏప్రిల్|మే|జూన్|జూలై|ఆగస్టు|సెప్టెంబర్|సెప్టెంబరు|అక్టోబర్|అక్టోబరు|నవంబర్|నవంబరు|డిసెంబర్|డిసెంబరు)"
    for m in re.finditer(rf"\d{{4}}\s*(?:వ\s*సంవత్సరం)?\s*{te_months}\s*(?:నెల)?\s*\d{{1,2}}\s*(?:వ)?\s*తేదీ", text):
        d = m.group(0).strip()
        if d not in dates:
            dates.append(d)
    pattern_te = r"(?:తేదీ|తేది)\s*[:\-]?\s*(\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4})"
    for clean_d in re.findall(pattern_te, text):
        if clean_d not in dates:
            dates.append(clean_d)

    # 4. Standard Numeric Date formats (DD/MM/YYYY, DD-MM-YYYY), guarded against Door / Plot / Survey numbers
    pat_num = re.compile(r"\b(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{2,4})\b")
    for match in pat_num.finditer(text):
        start_idx = match.start()
        prefix = text[max(0, start_idx-30):start_idx].lower()
        if any(bad in prefix for bad in ["door", "d.no", "plot", "sy", "survey", "no.", "house"]):
            continue
        d_str = match.group(0)
        if d_str not in dates:
            dates.append(d_str)

    return dates[:6]  # top dates


def extract_monetary_amounts(text: str) -> List[str]:
    """Extract financial sums (Rent, Consideration, Deposit, Penalties) in Rupees, Dollars, etc."""
    amounts = []
    # Match Rs., INR, రూ., $, requiring at least one digit and word boundary for Latin letters
    pattern = r"(?:\bRs\.?|\bINR|రూ[\.\!\:]?|రూపాయలు|\$)\s*(\d[\d,]*(?:\.\d{2})?)(?:\/\-)?(?:\s*(?:lakhs?|crores?|లక్షలు|కోట్లు))?"
    matches = re.finditer(pattern, text, re.IGNORECASE)

    for m in matches:
        amt_clean = m.group(0).strip()
        if re.search(r"\d", amt_clean) and amt_clean not in amounts:
            amounts.append(amt_clean)

    return amounts[:8]


def extract_property_identifiers(text: str) -> Dict[str, str]:
    """
    Extract comprehensive property, land, and title details including location,
    survey numbers, plot numbers, door numbers, extent/measurements, four-sided boundaries,
    and document/stamp registration numbers.
    Preserves original wording and outputs 'Not found' when missing.
    """
    details = {}
    text_lower = text.lower()

    # 1. Property Type / Asset Nature
    prop_type = "Not found"
    if any(k in text_lower for k in ["ఖాళీ జాగా", "ఖాళీ స్థలం", "ఓపెన్ ప్లాట్", "వేకెంట్ సైట్", "vacant plot", "vacant site", "vacant land", "vacant residential plot", "residential vacant site"]):
        prop_type = "ఖాళీ జాగా (నివాస నివేశన ఖాళీ స్థలం / Vacant Plot)"
    elif any(k in text_lower for k in ["నివాస గృహము", "నివాస భవనం", "residential house", "flat", "apartment", "భవనం", "residential premises"]):
        prop_type = "నివాస భవనం / గృహము (Residential Building / Flat)"
    elif any(k in text_lower for k in ["వాణిజ్య ప్రాంగణం", "కమర్షియల్", "office space", "commercial premises", "shop", "షాపూ"]):
        prop_type = "వాణిజ్య ప్రాంగణం (Commercial Premises / Office Space)"
    elif any(k in text_lower for k in ["వ్యవసాయ భూమి", "పొలం", "agricultural land"]):
        prop_type = "వ్యవసాయ భూమి (Agricultural Land)"
    elif any(k in text_lower for k in ["immovable property", "స్థిరాస్తి"]):
        prop_type = "స్థిరాస్తి / స్థలం (Immovable Property / Land Plot)"
    elif any(k in text_lower for k in ["plot", "site", "భూమి"]):
        prop_type = "స్థలం / ప్లాట్ (Land / Plot)"
    details["Property Type"] = prop_type

    # 2. Property Location / Jurisdiction (District, Mandal, Town/Village, SRO)
    locs = []
    dist_m = re.search(r"([A-Za-z\u0C00-\u0C7F]+)\s*(?:జిల్లా|District)", text, re.IGNORECASE)
    if dist_m and len(dist_m.group(1).strip()) > 2:
        locs.append(f"{dist_m.group(1).strip()} District / జిల్లా")
    mand_m = re.search(r"([A-Za-z\u0C00-\u0C7F]+(?:\s+[A-Za-z\u0C00-\u0C7F]+)?)\s*(?:మండలం|Mandal|Taluk)", text, re.IGNORECASE)
    if mand_m:
        clean_m = re.sub(r"^(?:జిల్లా|District|పోస్టు|Post)\s*", "", mand_m.group(1), flags=re.IGNORECASE).strip()
        if len(clean_m) > 2 and clean_m not in " ".join(locs):
            locs.append(f"{clean_m} Mandal / మండలం")
    sro_m = re.search(r"(?:సబ్[\-\s]*రిజిస్ట్రార్|SRO|Sub[\-\s]*Registrar)[\s\:\,]+([A-Za-z\u0C00-\u0C7F\s]+)", text, re.IGNORECASE)
    if sro_m and len(sro_m.group(1).strip()) > 2:
        clean_sro = sro_m.group(1).strip().replace("|", "").strip()
        if clean_sro and clean_sro not in " ".join(locs):
            locs.append(f"Sub-Registrar / సబ్-రిజిస్ట్రార్: {clean_sro}")
    
    # Generic situated at / located at pattern if no specific administrative units matched
    if not locs:
        sit_m = re.search(
            r"(?:situated\s+at|located\s+at|premises\s+at|situated\s+in)[\s\:\-]+([^\n;]+?)"
            r"(?=,\s*(?:comprised|measuring|admeasuring|bearing|having|within|bounded)|\.\s+[A-Z]|\.\s*$|\n|;|$)",
            text, re.IGNORECASE)
        if sit_m and len(sit_m.group(1).strip()) > 3:
            locs.append(sit_m.group(1).strip())

    details["Property Location"] = ", ".join(locs) if locs else "Not found"

    # 3. Survey Number (supports alphanumeric like 142/3B, 45-A, Sy. No. 89)
    survey_match = re.search(r"(?:survey\s*no\.?|sy\.?\s*no\.?|సర్వే\s*నెం(?:బరు|\.)?)\s*[:\-]?\s*([0-9A-Za-z\/\-]+)", text, re.IGNORECASE)
    details["Survey Number"] = survey_match.group(1).strip() if survey_match else "Not found"

    # 4. Plot or Flat Number (differentiating schedule property from party residential addresses)
    plot_match = re.search(r"(?:plot\s*no\.?|flat\s*no\.?|ఫ్లాట్\s*నెం(?:\.|\s*బరు)?|ప్లాట్\s*నెం(?:\.|\s*బరు)?)\s*[:\-]?\s*([0-9A-Za-z\/\-]+)", text, re.IGNORECASE)
    if plot_match:
        prefix = text[max(0, plot_match.start()-40):plot_match.start()].lower()
        if any(w in prefix for w in ["residing at", "residing", "కాపురం"]):
            sched_plot = re.search(r"(?:Schedule\s+Property|bearing|situated)[\s\S]{0,350}?(?:plot\s*no\.?|flat\s*no\.?)\s*[:\-]?\s*([0-9A-Za-z\/\-]+)", text, re.IGNORECASE)
            details["Plot / Flat Number"] = sched_plot.group(1).strip() if sched_plot else "Not found"
        else:
            details["Plot / Flat Number"] = plot_match.group(1).strip()
    else:
        details["Plot / Flat Number"] = "Not found"

    # 5. Door Number (differentiating schedule property from party residential addresses)
    door_match = re.search(r"(?:డోర్\s*నెం(?:బరు|\.)?|దోర్‌\s*నెం(?:బరు|\.)?|door\s*no\.?|d\.no\.?)\s*[:\-]?\s*([0-9A-Za-z\/\-]+)", text, re.IGNORECASE)
    if door_match:
        prefix = text[max(0, door_match.start()-40):door_match.start()].lower()
        if any(w in prefix for w in ["residing at", "residing", "కాపురం"]):
            sched_door = re.search(r"(?:Schedule\s+Property|bearing|situated)[\s\S]{0,350}?(?:door\s*no\.?|d\.no\.?)\s*[:\-]?\s*([0-9A-Za-z\/\-]+)", text, re.IGNORECASE)
            details["Door Number"] = sched_door.group(1).strip() if sched_door else "Not found"
        else:
            details["Door Number"] = door_match.group(1).strip()
    else:
        details["Door Number"] = "Not found"

    # 6. Extent / Area (supports numbers with commas like 2,400 sq. ft.)
    extent_match = re.search(r"(?:extent\s*(?:of)?|measuring|విస్తీర్ణం|వైశాల్యం|కొలతలు)\s*[:\-]?\s*(\d[\d,]*(?:\.\d+)?\s*(?:sq\.?\s*ft\.?|square\s*feet|sq\.?\s*yards?|చదరపు\s*గజములు|గజములు|acres?|cents?|ఎకరాల?|గుంటలు?|సెంట్లు?)[^\n,;]*)", text, re.IGNORECASE)
    if not extent_match:
        extent_match = re.search(r"(?:extent\s*(?:of)?|measuring|విస్తీర్ణం|వైశాల్యం|కొలతలు)\s*[:\-]?\s*([^\n;]+?)(?=(?:,\s*(?:situated|bounded|bearing|having)|[\.\n;]|$))", text, re.IGNORECASE)
    if extent_match:
        details["Area / Extent"] = extent_match.group(1).strip()
    else:
        unit_match = re.search(r"(\d[\d,]*(?:\.\d+)?\s*(?:చదరపు\s*గజములు|గజములు|ఎకరాల|ఎకరాలు|గుంటలు|సెంటు|సెంట్లు|sq\.?\s*yards?|sq\.?\s*ft\.?|square\s*feet|acres?|cents?))", text, re.IGNORECASE)
        details["Area / Extent"] = unit_match.group(1).strip() if unit_match else "Not found"

    # 7. Boundaries / చతుస్సీమలు (supports both single line and multiline boundaries)
    boundary_match = re.search(r"(?:చతుస్సీమలు|boundaries)[\s\:\-]+([^\n]+(?:\n[^\n]+){0,4})", text, re.IGNORECASE)
    details["Boundaries (చతుస్సీమలు)"] = boundary_match.group(1).strip() if boundary_match else "Not found"

    # 8. Four-Directional Boundaries Breakdown with line-wrap awareness
    def clean_dir_boundary(te_dir, en_dir):
        pat = rf"(?:{te_dir}|{en_dir}(?:\s*by)?)\s*[\:\-\=సరిహద్దు]*\s*([^\n,;\(]+)"
        m = re.search(pat, text, re.IGNORECASE)
        if not m:
            return "Not found"
        val = m.group(1).strip()
        # If line ended with a preposition (line-wrap in OCR or formatted legal document), capture remainder from next line
        if re.search(r"\b(?:of|by|to|for|at)\s*$", val, re.IGNORECASE):
            rem_m = re.search(r"\n\s*([^\n,;\(]+)", text[m.end():])
            if rem_m:
                val += " " + rem_m.group(1).strip()
        val = re.sub(r"\s+", " ", val).strip()
        val = re.sub(r"^(?:by|సరిహద్దు)\s+", "", val, flags=re.IGNORECASE).strip()
        val = re.split(r"\s+(?:and|మరియు)\s+(?:East|West|North|South|తూర్పు|పడమర|ఉత్తర|దక్షిణ)", val, flags=re.IGNORECASE)[0].strip()
        val = re.split(r"(?:,\s*(?:East|West|North|South|తూర్పు|పడమర|ఉత్తర|దక్షిణ))", val, flags=re.IGNORECASE)[0].strip()
        val = re.sub(r"[\s\,\;]+$", "", val).strip()
        return val if len(val) > 1 else "Not found"

    details["East Boundary"] = clean_dir_boundary(r"తూర్పు(?:న)?", "East")
    details["West Boundary"] = clean_dir_boundary(r"పడమర(?:న)?", "West")
    details["North Boundary"] = clean_dir_boundary(r"ఉత్తర(?:ం|ాన|న)?", "North")
    details["South Boundary"] = clean_dir_boundary(r"దక్షిణ(?:ం|ాన|న)?", "South")

    # 9. Registration / Document Number
    doc_num_match = re.search(r"(?:document\s*no\.?|దస్తావేజు\s*నెం(?:బరు|\.)?|రిజిస్ట్రేషన్\s*నెం(?:బరు|\.)?|regd?\.\s*no\.?|register\s*(?:serial\s*)?no\.?|notary\s*regn?\s*no\.?)\s*[:\-]?\s*([0-9\/\-]+)", text, re.IGNORECASE)
    if not doc_num_match:
        stamp_m = re.search(r"(?:N[_\s]+(\d{5,8})|స్టాంప్\s*నెం(?:బరు|\.)?\s*[:\-]?\s*(\d{5,8})|stamp\s*no\.?\s*[:\-]?\s*(\d{5,8})|(?:Sea\s*ON|Ser\s*No|Sea\s*No)\s*[:\.]?\s*([0-9A-Za-z]{5,8}))", text, re.IGNORECASE)
        if stamp_m:
            val = stamp_m.group(1) or stamp_m.group(2) or stamp_m.group(3) or stamp_m.group(4)
            details["Document / Registration No."] = f"Stamp No. {val}"
        else:
            details["Document / Registration No."] = "Not found"
    else:
        details["Document / Registration No."] = doc_num_match.group(1).strip()

    return details


# Context keywords used to label each amount / time period with what it is for
AMOUNT_LABELS = [
    ("Security deposit", "సెక్యూరిటీ డిపాజిట్", r"deposit|ధరావతు|డిపాజిట్"),
    ("Advance / earnest money", "అడ్వాన్స్ చెల్లింపు", r"advance|earnest|token amount|అడ్వాన్స్|బయానా"),
    ("Balance amount", "మిగిలిన మొత్తం", r"balance|remaining|మిగిలిన|బాకీ"),
    ("Monthly rent", "నెలవారీ అద్దె", r"\brent\b|\blease rent\b|అద్దె"),
    ("Sale price / consideration", "అమ్మకపు ధర (క్రయధనం)", r"consideration|sale price|total price|sale amount|క్రయధనం|విక్రయ|ఖరీదు|అమ్మకపు"),
    ("Penalty / damages", "జరిమానా / నష్టపరిహారం", r"penalt|liquidated damages|fine\b|జరిమానా|నష్టపరిహార"),
    ("Late payment interest", "ఆలస్య వడ్డీ", r"interest(?!-free| free)|వడ్డీ(?!\s*లేని)"),
    ("Fee / charges", "ఫీజు / చార్జీలు", r"\bfees?\b|charges|maintenance|ఫీజు|చార్జీ|నిర్వహణ"),
    ("Salary / remuneration", "జీతం", r"salary|remuneration|wages|జీతం"),
    ("Stamp value", "స్టాంప్ విలువ", r"stamp|denomination|స్టాంప్"),
]

TIME_PERIOD_LABELS = [
    ("Notice period", "నోటీసు గడువు", r"notice|నోటీసు"),
    ("Lock-in period", "లాక్-ఇన్ కాలం", r"lock-in|లాక్-ఇన్"),
    ("Confidentiality period", "గోప్యత కాలం", r"confidential|non-disclosure|గోప్య|రహస్య"),
    ("Agreement term", "ఒప్పంద కాలపరిమితి", r"\bterm\b|duration|period|lease|valid|tenure|కాలపరిమితి|వ్యవధి|ఒప్పంద"),
    ("Payment deadline", "చెల్లింపు గడువు", r"within|pay|చెల్లించ|లోపు"),
]

# Specific labels beat the generic "Agreement term" when both keywords are nearby
PRIORITY_LABELS = {"Notice period", "Lock-in period", "Confidentiality period"}

AGE_CONTEXT = r"(?:aged|age|వయస్సు|వయసు|సుమారు)\s*(?:about|around|[:\-])?\s*$"


def _context_window(text: str, start: int, end: int) -> Tuple[str, int]:
    """Return the line/sentence-bounded text around a match and the match offset inside it."""
    left = -1
    for sep in ("\n", "।", ". "):
        idx = text.rfind(sep, 0, start)
        # "Rs. 35,000" or "No. 12" must not end the window
        while sep == ". " and idx != -1 and re.search(r"(?:Rs|No|Sy|Mr|Mrs|Dr|Sri|రూ|నెం)$", text[max(0, idx - 4):idx]):
            idx = text.rfind(sep, 0, idx)
        left = max(left, idx)
    rights = [i for i in (text.find("\n", end), text.find(". ", end), text.find("।", end)) if i != -1]
    right = min(rights) if rights else len(text)
    # Include the clause heading line just above, e.g. "3. RENT AND PAYMENT:"
    head_start = text.rfind("\n", 0, max(left, 0))
    heading = text[head_start + 1:max(left, 0)] if left > 0 else ""
    if not heading.strip().endswith(":"):
        heading = ""
    window = heading + " " + text[left + 1:right]
    return window, (start - (left + 1)) + len(heading) + 1


def _closest_label(window: str, offset: int, labels: List[Tuple[str, str, str]]) -> Tuple[str, str]:
    """Pick the label whose keyword occurs closest to the match (keywords before the match win ties)."""
    best = None
    for en, te, kw in labels:
        for km in re.finditer(kw, window, re.IGNORECASE):
            dist = offset - km.end() if km.end() <= offset else (km.start() - offset) * 2.0
            if en in PRIORITY_LABELS:
                dist -= 20
            if best is None or dist < best[0]:
                best = (dist, en, te)
    return (best[1], best[2]) if best else (None, None)


def extract_labeled_amounts(text: str) -> List[Dict[str, str]]:
    """Money amounts with a label inferred from the surrounding sentence (rent, deposit, price ...)."""
    results: List[Dict[str, str]] = []
    pattern = r"(?:\bRs\.?|\bINR|రూ[\.\!\:]?|\$)\s*(\d[\d,]*(?:\.\d{1,2})?)(?:\s*/-)?(?:\s*(?:lakhs?|crores?|లక్షలు|కోట్లు))?"
    for m in re.finditer(pattern, text, re.IGNORECASE):
        window, offset = _context_window(text, m.start(), m.end())
        label_en, label_te = _closest_label(window, offset, AMOUNT_LABELS)
        if not label_en:
            label_en, label_te = "Amount", "మొత్తం"
        value = m.group(0).strip()
        if not any(r["value"] == value and r["label_en"] == label_en for r in results):
            results.append({"label_en": label_en, "label_te": label_te, "value": value})
    return results[:10]


def extract_time_periods(text: str) -> List[Dict[str, str]]:
    """Durations such as '11 months' or '30 days', labelled by context; a person's age is ignored."""
    results: List[Dict[str, str]] = []
    pattern = r"(\d+|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve)\s*\(?\d*\)?\s*(days?|weeks?|months?|years?|రోజులు|రోజుల|వారాలు|నెలలు|నెలల|నెల|సంవత్సరాలు|సంవత్సరాల|సంవత్సరం)(?![A-Za-z])"
    for m in re.finditer(pattern, text, re.IGNORECASE):
        before = text[max(0, m.start() - 25):m.start()]
        if re.search(AGE_CONTEXT, before, re.IGNORECASE):
            continue
        window, offset = _context_window(text, m.start(), m.end())
        label_en, label_te = _closest_label(window, offset, TIME_PERIOD_LABELS)
        if not label_en:
            label_en, label_te = "Time period", "కాలం"
        value = m.group(0).strip()
        number = re.match(r"\w+", value).group(0)
        # "3 months" and "3 నెలల" in the same clause are the same period written twice
        if not any(r["label_en"] == label_en and re.match(r"\w+", r["value"]).group(0) == number for r in results):
            results.append({"label_en": label_en, "label_te": label_te, "value": value})
    return results[:8]


def extract_key_contract_details(text: str) -> Dict[str, Any]:
    """
    Consolidated extraction of key contractual details.
    Preserves original wording and outputs 'Not found' when missing.
    """
    parties = extract_parties(text)
    dates = extract_dates(text)
    amounts = extract_monetary_amounts(text)
    labeled_amounts = extract_labeled_amounts(text)
    periods = extract_time_periods(text)
    prop_details = extract_property_identifiers(text)

    def first_period(label: str) -> str:
        return next((p["value"] for p in periods if p["label_en"] == label), "Not found")

    duration = first_period("Agreement term")
    notice = first_period("Notice period")

    return {
        "Parties Involved": parties if parties else [{"role": "Parties", "name": "Not found"}],
        "Key Dates": dates if dates else ["Not found"],
        "Monetary Amounts": amounts if amounts else ["Not found"],
        "Amounts Explained": [f"{a['label_en']}: {a['value']}" for a in labeled_amounts] or ["Not found"],
        "Agreement Duration / Term": duration,
        "Notice Period": notice,
        "Lock-in Period": first_period("Lock-in period"),
        "Property & Identifier Details": prop_details
    }


def analyze_document_clauses(text: str) -> Dict[str, Any]:
    """
    Main entry point for clause segmentation, classification, and key information extraction.
    """
    clauses = segment_into_clauses(text)
    key_details = extract_key_contract_details(text)

    # Group clauses by category
    categorized = {}
    for cl in clauses:
        cat = cl["category"]
        if cat not in categorized:
            categorized[cat] = []
        categorized[cat].append(cl)

    return {
        "total_clauses_identified": len(clauses),
        "clauses": clauses,
        "clauses_by_category": categorized,
        "key_details": key_details
    }

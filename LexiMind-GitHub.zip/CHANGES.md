# LexiMind — Fixes & Improvements

## Why every document got the "same template" answer

1. **No API key → fixed template.** With `GEMINI_API_KEY`/`OPENAI_API_KEY` empty, the old offline
   simplifier printed the same ~40 hard-coded lines for every document (property type, survey number,
   4 boundaries, possession, clear title, indemnity, deposit…) and only filled in a few regex values.
   An NDA was "explained" with *Survey Number: Not found, East boundary: Not found*.
   Measured: outputs for three different English documents were **~60% identical text**.
2. **Retired AI model + silent failure.** The default `gemini-1.5-flash` is retired, and every AI error
   was swallowed with `except: pass`, so even with a key the app quietly fell back to the template.
3. **Markdown shown as raw text.** The simplified Markdown was injected into an HTML `<div>`, so the UI
   displayed literal `###`, `**` and `*` characters.
4. **Q&A returned the same passage.** Chunking split only on blank lines; digital PDFs have none, so a
   whole page became one chunk and every question returned that same page.

## What was fixed

| Area | Fix |
|---|---|
| **Simplification (offline)** | New `text_simplifier.py`: rewrites the document's *own* sentences (legalese → plain English; archaic → spoken Telugu), TextRank summary, obligations/rights/prohibitions per party, readability scores. Output is now 3–14% similar between different documents (was ~60%). |
| **AI path** | Default model `gemini-2.5-flash`; errors are returned and shown in the UI; better prompt (document-only, no invented facts); 30k-character context (was 12k). |
| **Fact extraction** | Amounts labelled by context (rent / deposit / advance / balance / price); periods labelled (term / notice / lock-in); ages ignored; Telugu dates no longer mangled (`01-11-2026` used to become `01112026`); Telugu written dates; landlord role label fixed (it said కౌలుదారు = tenant); affidavit deponent name cleaned. |
| **Clause segmentation** | Recognises `నిబంధన 1 (…)` / `Section 1 (…)` headings, separates the signature/witness block, handles PDFs without blank lines; keyword matching uses word boundaries (`fee` no longer matches `feet`, `rent` no longer matches `parent`). |
| **Risk analysis** | Quotes the exact risky sentence (not a whole page); checks Telugu + English patterns for every document; Telugu category/severity labels; 2 new rules (one-sided waiver, rent escalation). |
| **RAG Q&A** | Clause-level chunks, hybrid word + character n-gram TF-IDF (handles Telugu suffixes), English↔Telugu query expansion, plain-language text indexed too, intent-aware answers (amount / time / parties), stricter "not found" check, answer history kept in the UI. |
| **UI (`app.py`)** | Markdown renders properly; original text HTML-escaped; demo sample no longer overwritten by a previously uploaded file; warning when text is edited after simplifying; AI errors shown; metrics (sentences simplified, phrases rewritten, facts found, reading ease); plain meaning shown for every clause; works offline (no remote sidebar image); removed reference to a non-existent `tesseract_installer.exe`; replaced deprecated `use_container_width`. |
| **Exports** | PDF: fixed double-escaping bug (`&` escaped after `<`), emoji removed (black boxes), Telugu shaped correctly with HarfBuzz (`uharfbuzz`), risk section added. DOCX/TXT: real headings & bullets instead of raw Markdown; parties printed as names, not Python dicts. |
| **OCR** | Small images upscaled before Tesseract; noisy OCR lines (stamp headers, table borders) filtered out of the explanation. |
| **Tests** | 15 new tests (50 total), including a regression test that different documents must get different simplifications. |

## Project clean-up

Files from other projects were removed from this folder (they are still in your original zip):
the ADCT compression project (`adct_compression/`, `cli.py`, `benchmark.py`, `PROJECT_REPORT.md`,
`run_cli.bat`, `run_gui.bat`, `*.adct`, `my_restored.txt`, `sample_code_restored.py`), the Amazon /
food-delivery review sentiment data and models (`data/`, `models/`, `report_figures/`), the crop-yield
figures (`report_assets/`), and the scratch OCR output `extracted_b1.txt`.

## Run

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
.venv\Scripts\pytest -q tests
```

For AI-quality explanations, put a key in `.env` (`GEMINI_API_KEY=...`). Without a key the offline NLP
engine is used and every output is still built from the uploaded document.

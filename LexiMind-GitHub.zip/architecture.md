# 🏛️ LexiMind: Architectural & System Design Document

This document provides a comprehensive technical overview of **LexiMind**, detailing the component relationships, processing pipelines, memory models, and algorithmic strategies employed across the application.

---

## 1. High-Level System Architecture

LexiMind is engineered with a modular, decoupled architecture consisting of five core subsystems:
1. **Document Ingestion & Optical Recognition Subsystem** (`document_processor.py`)
2. **Language Processing & Simplification Subsystem** (`language_processor.py`)
3. **Contract Intelligence & Information Extraction Subsystem** (`clause_analyzer.py`, `risk_analyzer.py`)
4. **Retrieval-Augmented Generation (RAG) Subsystem** (`rag_engine.py`)
5. **Presentation & Document Compilation Subsystem** (`app.py`, `report_generator.py`)

```mermaid
graph TD
    subgraph Ingestion["1. Ingestion & Preprocessing"]
        PDF["Digital / Scanned PDF"]
        DOCX["DOCX Document"]
        TXT["TXT File"]
        IMG["PNG / JPG Image"]
        DocProc["document_processor.py"]
        OCR["pytesseract (tel+eng)"]
    end

    subgraph LanguageEngine["2. Language & Simplification Engine"]
        LangDetect["Language Detector (te / en / mixed)"]
        Glossary["Legal Glossary Extractor"]
        SimpRouter{"Simplification Router"}
        SameLangSimp["Same-Language Simplifier (Primary)"]
        OptionalTrans["Optional Cross-Translator (Secondary)"]
        AI_API["Gemini AI / OpenAI API"]
        OfflineNLP["Rule-Based NLP Heuristics (Fallback)"]
    end

    subgraph Intelligence["3. Contract Intelligence"]
        ClauseSeg["Clause Segmenter"]
        ClauseClass["10-Category Classifier"]
        EntityExt["Verified Entity Extractor"]
        RiskDetect["Potential Risk Detector"]
    end

    subgraph RAG["4. RAG Search Engine"]
        Chunker["Clause & Page Chunker"]
        TFIDF["TF-IDF Matrix (1-2 N-grams)"]
        Cosine["Cosine Similarity Ranker"]
        QA["Grounded Answer Synthesizer"]
    end

    subgraph Presentation["5. UI & Export Compilation"]
        StreamlitUI["Streamlit Interactive Web UI"]
        ReportGen["report_generator.py"]
        DOCXOut["DOCX Document"]
        PDFOut["Unicode PDF (Nirmala Font)"]
        TXTOut["Plain Text / Markdown"]
    end

    PDF --> DocProc
    DOCX --> DocProc
    TXT --> DocProc
    IMG --> DocProc
    DocProc --> OCR
    DocProc --> LangDetect
    LangDetect --> SimpRouter
    SimpRouter --> SameLangSimp
    SimpRouter -.-> OptionalTrans
    SameLangSimp --> AI_API
    SameLangSimp --> OfflineNLP
    DocProc --> ClauseSeg
    ClauseSeg --> ClauseClass
    DocProc --> EntityExt
    DocProc --> RiskDetect
    DocProc --> Chunker
    Chunker --> TFIDF
    TFIDF --> Cosine
    Cosine --> QA
    SameLangSimp --> StreamlitUI
    ClauseClass --> StreamlitUI
    EntityExt --> StreamlitUI
    RiskDetect --> StreamlitUI
    QA --> StreamlitUI
    StreamlitUI --> ReportGen
    ReportGen --> DOCXOut
    ReportGen --> PDFOut
    ReportGen --> TXTOut
```

---

## 2. Ingestion & Preprocessing Pipeline

### 2.1 Format Normalization
The ingestion pipeline accepts five file extensions (`.pdf`, `.docx`, `.txt`, `.png`, `.jpg`, `.jpeg`).
- **Digital PDFs**: Evaluated page-by-page using PyMuPDF (`fitz`). For each page, character density is calculated. If a page yields fewer than 40 characters and contains raster drawings or images, the engine dynamically renders the page to a 200 DPI bitmap and invokes OCR.
- **Scanned Images**: Preprocessed using Pillow (`ImageEnhance.Contrast`, `ImageEnhance.Sharpness`, and `ImageOps.exif_transpose` for rotation correction) prior to feeding into Tesseract.
- **DOCX**: Traversed hierarchically across `paragraphs` and `tables` to preserve tabular contractual schedules (e.g., rent matrices, payment milestones).
- **TXT**: Processed through multi-encoding detection (`utf-8`, `utf-8-sig`, `utf-16`, `latin-1`).

### 2.2 Inspection & Error Rectification
Recognizing that no OCR engine is 100% immune to noise in historical or low-contrast stamps, LexiMind provides an interactive, editable text area in the Streamlit UI immediately after extraction. The user can inspect the raw text and correct any spelling or numerical artifacts before AI simplification or analysis begins.

---

## 3. Language Processing & Same-Language Simplification

### 3.1 Source Language Detection
Rather than relying on naive language detection models that require external internet calls, LexiMind uses character-level Unicode frequency inspection:
- Telugu characters are identified via the block `[\u0C00-\u0C7F]`.
- English characters are identified via `[a-zA-Z]`.
- Distribution ratios are computed to classify the document as **Telugu**, **English**, or **Mixed (Telugu + English)**.

### 3.2 Primary Same-Language Workflow
By default, LexiMind routes documents to same-language simplification:
- **Telugu Document**: Transformed into clear, modern conversational Telugu. Archaic court expressions (`ఉభయ పక్షములవారు`, `సదరు స్థిరాస్తి`, `స్వాధీనపరచడమైనది`) are rewritten into everyday colloquial terms (`ఇరు పక్షాలు`, `ఇల్లు లేదా భూమి`, `తాళాలను అప్పగించారు`) while maintaining all names, dates, amounts, and survey numbers.
- **English Document**: Onerous legalese (`hereinafter referred to as`, `indemnify and hold harmless`, `liquidated damages`) is converted into clear, modern English.
- **Secondary Translation**: Available as an opt-in checkbox, ensuring that cross-language translation is strictly an intentional user choice.

### 3.3 Dual-Engine Execution Strategy (AI + Offline Fallback)
1. **Cloud AI Tier**: When an API key (`GEMINI_API_KEY` or `OPENAI_API_KEY`) is present, the system sends an engineering prompt with strict negative constraints (zero hallucination, strict factual preservation).
2. **Deterministic Offline Tier**: If running in an offline environment or without API credentials, LexiMind activates its rule-based heuristic legal simplifier. This engine uses curated legal substitution dictionaries and structural formatting heuristics, guaranteeing 100% functionality without network dependencies.

---

## 4. Contract Intelligence & Risk Highlighting

### 4.1 Clause Segmentation & Categorization
Contract text is tokenized into clauses using regular expression boundary matching on numbering patterns (`Clause X`, `Section X`, `Article X`, `నిబంధన X`, `షరతు X`, `1.1`, etc.).
Each segmented clause is mapped into one of 10 standard legal categories:
1. *Payment and Financial Terms*
2. *Term and Termination*
3. *Renewal and Extension*
4. *Confidentiality and Non-Disclosure*
5. *Liability and Limitation of Liability*
6. *Indemnification*
7. *Dispute Resolution and Jurisdiction*
8. *Property, Ownership, and Title*
9. *Obligations and Covenants of Parties*
10. *Representations and Warranties*

### 4.2 Verifiable Entity Extraction
Contract details are parsed using custom regex extractors designed for Indian legal formats:
- **Parties & Roles**: Extracts Lessor, Lessee, Vendor, Vendee, Employer, Employee, Disclosing Party, Receiving Party, విక్రయదారుడు, ఖరీదుదారుడు, కౌలుదారు.
- **Financial Values**: Captures currency symbols (`Rs.`, `INR`, `రూ.`, `రూపాయలు`, `$`) and numeric sums including Lakhs (`లక్షలు`) and Crores.
- **Property Identifiers**: Extracts Survey Numbers (`సర్వే నెం`), Plot/Flat Numbers, Areas (Square Yards / గజములు), and Boundaries (చతుస్సీమలు: తూర్పు, పడమర, ఉత్తరం, దక్షిణం).
- **Missing Field Policy**: Unmatched entities are returned as `"Not found"` rather than guessed.

### 4.3 Potential-Risk Highlighting
The system scans clause text for onerous patterns:
- *Unilateral Termination*: Immediate cancellation without cause or notice.
- *Excessive Penalty & Deposit Forfeiture*: Unreasonable interest rates or non-refundable deposit seizures.
- *Uncapped Liability*: One-sided indemnification without financial ceiling.
- *Strict Lock-In*: Mandatory tenancy periods with penalty rent.
- *Auto-Renewal Traps*: Evergreen clauses with narrow opt-out windows.

For every flag, the exact source passage is quoted alongside a plain-language explanation in the document's language and actionable review advice.

---

## 5. RAG Retrieval Architecture

```
User Query (e.g. "What is the monthly rent and deposit?")
       │
       ▼
TfidfVectorizer.transform([query])
       │
       ▼
Cosine Similarity against Document Chunk Matrix
       │
       ▼
Relevance Filtering (Threshold >= 0.10 & Non-stopword Overlap Check)
       │
       ├─ No Matches ──► "Information not found in the uploaded document."
       │
       ▼
Top 3 Supporting Chunks Selected
       │
       ├─ Cloud AI Mode: Gemini/OpenAI prompt with strictly bounded excerpts
       │
       └─ Offline Mode: Extractive sentence ranker with Section/Page citation
```

The TF-IDF vectorizer utilizes Unicode-aware token patterns `(?u)\b\w+\b` and sublinear term frequency scaling, providing zero-latency retrieval without heavy memory footprint.

---

## 6. Document Compilation & Font Engineering

When exporting simplified documents:
- **DOCX**: Formatted via `python-docx` using standard OpenXML XML tables and callout shading. Renders Telugu script natively on any modern operating system without font configuration.
- **PDF**: Built with `reportlab.platypus`.
  - On Windows, the system dynamically registers `C:\Windows\Fonts\Nirmala.ttc` (subfontIndex=0).
  - If a compatible Telugu Unicode font is not present, the system disables PDF export with a clear explanatory tooltip, directing the user to the DOCX export to prevent corrupted or unrendered glyphs.

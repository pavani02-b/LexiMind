"""
LexiMind Language Processor
Handles source language detection (Telugu, English, Mixed), same-language legal simplification
(Telugu-to-Telugu, English-to-English), optional translation, legal glossary extraction,
and AI API integration (Gemini / OpenAI).

When no AI key is configured, the offline engine (text_simplifier.py) rewrites the uploaded
document's OWN sentences, summarizes them with TextRank, extracts obligations per party and
labels every amount / time period from context — so each document gets its own explanation.
"""

import re
import time
from typing import Dict, Any, List, Optional

from config import GEMINI_API_KEY, OPENAI_API_KEY, GEMINI_MODEL, OPENAI_MODEL, AI_TIMEOUT_SECONDS
from clause_analyzer import (
    extract_parties,
    extract_dates,
    extract_labeled_amounts,
    extract_time_periods,
    extract_property_identifiers,
    segment_into_clauses,
)
from risk_analyzer import highlight_potential_risks
from text_simplifier import (
    split_sentences,
    is_noise_sentence,
    is_heading_line,
    simplify_sentence,
    simplify_passage,
    summarize,
    extract_duties,
    readability_stats,
)

# Comprehensive Telugu Legal Glossary
TELUGU_LEGAL_GLOSSARY = {
    "సాదా బైనామా": "రిజిస్ట్రేషన్ చేయకుండా తెల్ల కాగితం లేదా స్టాంప్ పేపర్‌పై పరస్పర నమ్మకంతో రాసుకున్న ప్రాథమిక ఆస్తి అమ్మకపు ఒప్పందం",
    "విక్రయపత్రం": "భూమి లేదా ఆస్తిని శాశ్వతంగా విక్రయిస్తూ రాసిచ్చే పూర్తి యాజమాన్య బదిలీ పత్రం (సేల్ డీడ్)",
    "క్రయధనం": "ఆస్తి కొనుగోలుకు ప్రతిఫలంగా కొనుగోలుదారుడు అమ్మకందారునికి చెల్లించే అసలు ఖరీదు మొత్తం",
    "ఉభయ పక్షములవారు": "ఇరు పక్షాలు (ఒప్పందం చేసుకుంటున్న రెండు వైపులా ఉన్న వ్యక్తులు)",
    "విక్రయదారుడు": "ఆస్తిని విక్రయిస్తున్న అసలు యజమాని (అమ్మే వ్యక్తి / వెండర్)",
    "ఖరీదుదారుడు": "ఆస్తిని లేదా వస్తువును డబ్బు చెల్లించి కొంటున్న వ్యక్తి (కొనుగోలుదారు / పర్చేజర్)",
    "కౌలుదారు": "స్థలాన్ని లేదా ఇంటిని అద్దెకు తీసుకుంటున్న వ్యక్తి (టెనెంట్ / అద్దెదారు)",
    "యజమాని": "ఆస్తికి సంబంధించిన పూర్తి చట్టపరమైన హక్కులు కలిగిన వ్యక్తి (ల్యాండ్‌లార్డ్)",
    "స్వాధీనపరచడమైనది": "ఆస్తి తాళాలు, పత్రాలు మరియు పూర్తి భౌతిక అనుభవాన్ని వెంటనే ఎదుటి వ్యక్తికి అప్పగించడం (పొసెషన్ హ్యాండోవర్)",
    "సదరు స్థిరాస్తి": "ఈ దస్తావేజులో పైన పేర్కొనబడిన నిర్దిష్ట ఇల్లు, ప్లాట్ లేదా భూమి",
    "తనఖా": "రుణం లేదా అప్పు కోసం పూచీకత్తుగా ఆస్తి పత్రాలను తాకట్టు పెట్టడం (మార్ట్‌గేజ్)",
    "నష్టపరిహారము": "నష్టం లేదా లోపం జరిగినప్పుడు బాధ్యత గల వ్యక్తి చెల్లించవలసిన ఆర్థిక పరిహారం మొత్తం (ఇండెమ్నిటీ)",
    "చతుస్సీమలు": "ఆస్తి యొక్క నాలుగు వైపులా గల సరిహద్దులు (తూర్పు, పడమర, ఉత్తరం, దక్షిణం)",
    "స్వతంత్ర సర్వ హక్కులతో": "ఎలాంటి వివాదాలు, బంధువుల పేచీలు లేకుండా పూర్తి సర్వాధికార యాజమాన్య హక్కులతో",
    "రద్దుపరచబడును": "ఈ ఒప్పందం వెంటనే రద్దవుతుంది (చట్టపరమైన చెల్లుబాటు కోల్పోతుంది)",
    "నోటీసు వ్యవధి": "ఒప్పందం ముగించే ముందు ఎదుటి పక్షానికి అధికారికంగా తెలియజేయాల్సిన ముందస్తు రోజుల గడువు",
    "ధరావతు సొమ్ము": "ముందస్తుగా చెల్లించిన భద్రతా డిపాజిట్ (సెక్యూరిటీ డిపాజిట్)",
    "బాధ్యతాయుతమైన": "చట్టపరంగా లేదా నైతికంగా తప్పనిసరిగా పాటించవలసిన కర్తవ్యం (లీగల్ ఆబ్లిగేషన్)",
    "వివాద పరిష్కారము": "సమస్యలు లేదా తగాదాలు వచ్చినప్పుడు కోర్టు లేదా మధ్యవర్తి ద్వారా పరిష్కరించే మార్గం",
    "నిర్దిష్ట గడువు": "పని పూర్తి చేయవలసిన లేదా చెల్లింపు చేయవలసిన ఖచ్చితమైన తేదీ",
    "అంగీకారము": "రెండు పక్షాలు పూర్తి సమ్మతితో చేసుకున్న ఒప్పందం",
    "దస్తావేజు": "రిజిస్ట్రేషన్ లేదా చట్టపరమైన చెల్లుబాటు కలిగిన అధికారిక లిఖితపూర్వక పత్రం",
    "పూర్వపు హక్కులు": "గతంలో ఆస్తిపై ఉన్న లేదా ఇతరులకు సంబంధించిన వారసత్వ హక్కులు / లింక్ డాక్యుమెంట్లు",
    "ఖాళీ జాగా": "ఎటువంటి నిర్మాణం లేని నివాస నివేశన ఖాళీ స్థలం (వేకెంట్ సైట్ / ఓపెన్ ప్లాట్)",
    "సర్వే నెంబరు": "రెవెన్యూ మరియు రిజిస్ట్రేషన్ రికార్డులలో భూమికి కేటాయించిన అధికారిక గుర్తింపు సంఖ్య"
}

# Comprehensive English Legal Glossary
ENGLISH_LEGAL_GLOSSARY = {
    "hereinafter referred to as": "referred to by this shortened title in the remainder of this agreement",
    "indemnify and hold harmless": "protect and financially compensate against losses, damages, or legal claims",
    "in witness whereof": "confirming agreement by officially signing the document",
    "force majeure": "unforeseeable events beyond reasonable human control (e.g., natural disasters, wars)",
    "liquidated damages": "a pre-determined financial penalty payable if a specific clause is breached",
    "null and void": "having no legal force, effect, or enforceability",
    "severability": "if one clause is ruled invalid by a court, the remaining clauses continue in full effect",
    "covenants and agrees": "formally and legally promises to perform specific obligations",
    "forthwith": "immediately without any unreasonable delay",
    "inter alia": "among other things",
    "unilateral termination": "one party ending the agreement without needing the agreement of the other party",
    "security deposit": "refundable advance payment held to secure against damages or unpaid rent",
    "jurisdiction": "the specific geographic court or legal authority empowered to hear disputes",
    "confidential information": "private business, financial, or technical data that must not be disclosed",
    "lock-in period": "a mandatory minimum time during which neither party can terminate without penalty",
    "warranty of title": "guarantee that the seller owns the property cleanly with no undisclosed liens",
    "encumbrance": "a claim, mortgage, or legal liability attached to property that diminishes its value",
    "lessor": "the owner who rents out the property (landlord)",
    "lessee": "the person who takes the property on rent (tenant)",
    "vendor": "the person selling the property (seller)",
    "purchaser": "the person buying the property (buyer)",
    "consideration": "the price or value one party gives the other in exchange for the promise",
    "deponent": "the person who makes and signs a sworn statement (affidavit)",
    "affidavit": "a written statement that the signer swears is true, usually before a notary",
    "notary": "an official who verifies the identity of signers and attests documents",
    "arbitration": "settling a dispute through a private referee (arbitrator) instead of a court",
    "indemnity": "a promise to pay for losses or claims the other party suffers",
    "possession": "physical control and use of the property",
    "schedule property": "the exact property described in the schedule (list) at the end of the deed",
    "stamp duty": "government tax paid on legal documents to make them valid evidence",
    "sub-registrar": "government officer who registers property documents",
    "governing law": "the law of the place that will be used to interpret the agreement"
}


def detect_document_language(text: str) -> Dict[str, Any]:
    """
    Detect the primary source language of the document based on Unicode character counts.
    Distinguishes pure Telugu, pure English, and mixed documents with dominant language awareness.
    """
    if not text or not text.strip():
        return {
            "lang_code": "unknown",
            "language": "Unknown / Empty",
            "telugu_pct": 0.0,
            "english_pct": 0.0,
            "is_mixed": False,
            "dominant_lang": "en"
        }

    # Telugu Unicode block: \u0C00-\u0C7F
    telugu_chars = len(re.findall(r"[\u0C00-\u0C7F]", text))
    # Latin / English letters
    english_chars = len(re.findall(r"[a-zA-Z]", text))
    total_letters = telugu_chars + english_chars

    if total_letters == 0:
        return {
            "lang_code": "en",
            "language": "English (Numeric/Symbolic)",
            "telugu_pct": 0.0,
            "english_pct": 100.0,
            "is_mixed": False,
            "dominant_lang": "en"
        }

    telugu_pct = round((telugu_chars / total_letters) * 100, 1)
    english_pct = round((english_chars / total_letters) * 100, 1)

    dominant_lang = "te" if telugu_chars >= english_chars else "en"

    # Telugu legal documents often have English stamp headers (e.g. 'Denomination 400', 'Sub Registrar')
    if telugu_pct >= 65.0:
        lang_code = "te"
        language = "Telugu (తెలుగు)"
        is_mixed = False
    elif english_pct >= 85.0:
        lang_code = "en"
        language = "English"
        is_mixed = False
    elif telugu_pct >= 15.0 and english_pct >= 15.0:
        lang_code = "mixed"
        language = "Mixed (Telugu + English)"
        is_mixed = True
    elif telugu_chars >= english_chars:
        lang_code = "te"
        language = "Telugu (తెలుగు)"
        is_mixed = False
    else:
        lang_code = "en"
        language = "English"
        is_mixed = False

    return {
        "lang_code": lang_code,
        "language": language,
        "telugu_pct": telugu_pct,
        "english_pct": english_pct,
        "is_mixed": is_mixed,
        "dominant_lang": dominant_lang
    }


def extract_legal_glossary(text: str, lang_code: str) -> List[Dict[str, str]]:
    """
    Scan document text for complex legal terminology and build an explanatory glossary.
    Returns list of dicts with 'term', 'plain_meaning', 'language', and 'frequency'.
    """
    glossary_items = []
    text_lower = text.lower()

    if lang_code in ["te", "mixed"]:
        for term, meaning in TELUGU_LEGAL_GLOSSARY.items():
            if term in text:
                count = text.count(term)
                glossary_items.append({
                    "term": term,
                    "plain_meaning": meaning,
                    "language": "Telugu",
                    "frequency": count
                })

    if lang_code in ["en", "mixed"]:
        for term, meaning in ENGLISH_LEGAL_GLOSSARY.items():
            if term.lower() in text_lower:
                pattern = re.compile(r"\b" + re.escape(term) + r"\b", re.IGNORECASE)
                count = len(pattern.findall(text))
                if count > 0:
                    glossary_items.append({
                        "term": term,
                        "plain_meaning": meaning,
                        "language": "English",
                        "frequency": count
                    })

    # Sort by frequency descending
    glossary_items.sort(key=lambda x: x["frequency"], reverse=True)
    return glossary_items


# ----------------------------------------------------------------------------------------
# Document type detection (keyword scoring, title-weighted)
# ----------------------------------------------------------------------------------------

DOC_TYPES = [
    ("lease", "Residential / Commercial Lease (Rental) Agreement", "ఇంటి / వాణిజ్య అద్దె ఒప్పంద పత్రం",
     [r"\blease\b", r"\brent(?:al)?\b", r"\btenant\b", r"\blessee\b", r"\blessor\b", r"\blandlord\b", "అద్దె", "కౌలు", "అద్దెదారు", "లీజు"]),
    ("sada_bainama", "Sada Bainama (Unregistered Sale Deed for Land)", "సాదా బైనామా (రిజిస్ట్రేషన్ లేని భూమి అమ్మకపు పత్రం)",
     ["సాదా బైనామా", "బైనామా", "ఖాళీ జాగా", "జాగా విక్రయ", "వ్రాయించియిచ్చినవారు", "రాయించియిచ్చినవారు", "వ్రాయించుకున్నవారు", "రాయించుకున్నవారు", r"\bsada bainama\b"]),
    ("sale", "Sale Agreement / Sale Deed (Immovable Property)", "స్థిరాస్తి విక్రయ ఒప్పందం / విక్రయ దస్తావేజు",
     [r"\bsale\b", r"\bvendor\b", r"\bpurchaser\b", r"\bconveyance\b", r"\bsale deed\b", "విక్రయ", "క్రయధనం", "కొనుగోలుదారు", "విక్రయదారు", "ఖరీదుదారు"]),
    ("nda", "Non-Disclosure (Confidentiality) Agreement", "సమాచార గోప్యత ఒప్పందం (NDA)",
     [r"\bnon-disclosure\b", r"\bconfidential", r"\btrade secret", r"\bdisclosing party\b", r"\breceiving party\b", "గోప్యత", "రహస్య"]),
    ("affidavit", "Affidavit / Sworn Declaration", "అఫిడవిట్ / ప్రమాణ పత్రం",
     [r"\baffidavit\b", r"\bdeponent\b", r"\bsolemnly\b", r"\bdeclare\b", r"\bon oath\b", "అఫిడవిట్", "ప్రమాణ"]),
    ("mortgage", "Mortgage / Loan Security Deed", "తనఖా / రుణ హామీ పత్రం",
     [r"\bmortgage", r"\bpledge\b", r"\bhypothecat", r"\bborrower\b", r"\blender\b", "తనఖా", "తాకట్టు", "రుణం"]),
    ("employment", "Employment / Service Agreement", "ఉద్యోగ / సేవా ఒప్పందం",
     [r"\bemployee\b", r"\bemployer\b", r"\bsalary\b", r"\bemployment\b", r"\bprobation\b", "ఉద్యోగ", "జీతం"]),
    ("poa", "Power of Attorney", "పవర్ ఆఫ్ అటార్నీ (అధికార పత్రం)",
     [r"\bpower of attorney\b", r"\battorney\b", r"\bagent\b", r"\bprincipal\b", "జిపిఏ", "అధికార పత్రం"]),
    ("partnership", "Partnership Deed", "భాగస్వామ్య ఒప్పందం",
     [r"\bpartnership\b", r"\bpartners?\b", r"\bprofit sharing\b", "భాగస్వామ"]),
]


def detect_document_type(text: str) -> Dict[str, str]:
    """Score each document type by keyword hits; hits in the title area count three times."""
    lower = text.lower()
    title_zone = lower[:400]
    best = ("general", "Legal Agreement / Contract", "చట్టపరమైన ఒప్పంద పత్రం", 0)
    for key, en, te, keywords in DOC_TYPES:
        score = 0
        for kw in keywords:
            score += len(re.findall(kw, lower)) + 3 * len(re.findall(kw, title_zone))
        if score > best[3]:
            best = (key, en, te, score)
    key, en, te, _ = best
    if re.search(r"\bnotar(?:y|ized|ised)\b|నోటరీ", lower):
        en, te = f"Notarized {en}", f"నోటరీ చేసిన {te}"
    return {"key": key, "en": en, "te": te}


def extract_contract_profile(text: str, lang_code: str) -> Dict[str, Any]:
    """Structured facts used to ground the simplification (only values present in the document)."""
    doc_type = detect_document_type(text)
    amounts = extract_labeled_amounts(text)
    periods = extract_time_periods(text)
    written_amt_match = re.search(r"అక్షరాలా\s*([^\n\.\,\)]+?)\s*(?:రూపాయలు|రూ\.)", text)

    def first_period(label: str) -> Optional[str]:
        return next((p["value"] for p in periods if p["label_en"] == label), None)

    return {
        "doc_type": doc_type,
        "doc_type_en": doc_type["en"],
        "doc_type_te": doc_type["te"],
        "parties": extract_parties(text),
        "dates": extract_dates(text),
        "amounts": [a["value"] for a in amounts],
        "labeled_amounts": amounts,
        "periods": periods,
        "written_amount": written_amt_match.group(1).strip() if written_amt_match else None,
        "property_details": extract_property_identifiers(text),
        "duration": first_period("Agreement term"),
        "notice": first_period("Notice period"),
        "lock_in": first_period("Lock-in period"),
    }


# ----------------------------------------------------------------------------------------
# Offline (rule-based) simplification — built entirely from the uploaded document
# ----------------------------------------------------------------------------------------

LABELS = {
    "en": {
        "title_suffix": "Plain English Version",
        "stats": "{n} sentences simplified · {r} legal phrases rewritten · average sentence length {a} → {b} words",
        "flesch": " · reading ease {x} → {y} (higher = easier)",
        "summary": "🧾 In Short — What This Document Says",
        "facts": "🔑 Key Facts Found in the Document",
        "parties": "Parties",
        "dates": "Dates mentioned",
        "money": "Money",
        "periods": "Time periods",
        "property": "Property",
        "duties": "✅ Who Must Do What",
        "must": "Must",
        "can": "Can",
        "must_not": "Must not",
        "risks": "⚠️ Points to Watch Before Signing",
        "clauses": "📑 What Each Section Says",
        "glossary": "📖 Difficult Legal Terms Explained",
        "no_facts": "No names, amounts, or dates could be identified automatically — please check the original text.",
        "general_party": "General",
        "written": "in words",
    },
    "te": {
        "title_suffix": "సులభమైన తెలుగు వివరణ",
        "stats": "{n} వాక్యాలు సరళీకరించబడ్డాయి · {r} క్లిష్టమైన పదాలు / రూపాలు మార్చబడ్డాయి · సగటు వాక్య పొడవు {a} → {b} పదాలు",
        "flesch": "",
        "summary": "🧾 సంక్షిప్తంగా — ఈ పత్రం ఏం చెబుతోంది",
        "facts": "🔑 పత్రంలో దొరికిన ముఖ్య వివరాలు",
        "parties": "పక్షాలు (వ్యక్తులు)",
        "dates": "తేదీలు",
        "money": "డబ్బు వివరాలు",
        "periods": "కాల వ్యవధులు",
        "property": "ఆస్తి వివరాలు",
        "duties": "✅ ఎవరు ఏమి చేయాలి",
        "must": "చేయాలి",
        "can": "చేయవచ్చు / హక్కు ఉంది",
        "must_not": "చేయకూడదు",
        "risks": "⚠️ సంతకం చేసే ముందు జాగ్రత్తగా గమనించవలసినవి",
        "clauses": "📑 ఒక్కో నిబంధన అర్థం",
        "glossary": "📖 కష్టమైన చట్టపరమైన పదాలకు సరళార్థం",
        "no_facts": "పేర్లు, మొత్తాలు లేదా తేదీలు స్వయంచాలకంగా గుర్తించబడలేదు — దయచేసి అసలు పత్రాన్ని చూడండి.",
        "general_party": "ఇతర నిబంధనలు",
        "written": "అక్షరాలా",
    },
}

PROPERTY_LABELS_TE = {
    "Property Location": "ప్రదేశం",
    "Survey Number": "సర్వే నెంబరు",
    "Plot / Flat Number": "ప్లాట్ / ఫ్లాట్ నెంబరు",
    "Door Number": "డోర్ నెంబరు",
    "Area / Extent": "విస్తీర్ణం",
    "East Boundary": "తూర్పు హద్దు",
    "West Boundary": "పడమర హద్దు",
    "North Boundary": "ఉత్తర హద్దు",
    "South Boundary": "దక్షిణ హద్దు",
    "Document / Registration No.": "దస్తావేజు / స్టాంప్ నెంబరు",
}


def _clean_title(title: str) -> str:
    title = re.sub(r"[:\-–—\s]+$", "", title.strip())
    letters = re.findall(r"[A-Za-z]", title)
    if letters and sum(1 for c in letters if c.isupper()) / len(letters) > 0.8:
        title = title.title()
    simplified, _ = simplify_sentence(title, set())
    return re.sub(r"\.$", "", simplified[0]) if simplified else title


def _found(value: Optional[str]) -> bool:
    return bool(value) and value.strip() not in ("Not found", "None", "")


def _build_facts(profile: Dict[str, Any], lang: str) -> List[str]:
    L = LABELS[lang]
    lines: List[str] = []
    if profile["parties"]:
        parts = [f"{p['name']} ({p['role']})" for p in profile["parties"]]
        lines.append(f"* **{L['parties']}:** " + "; ".join(parts))
    if profile["dates"]:
        lines.append(f"* **{L['dates']}:** " + ", ".join(profile["dates"][:4]))
    if profile["labeled_amounts"]:
        key = "label_te" if lang == "te" else "label_en"
        money = [f"{a[key]} — **{a['value']}**" for a in profile["labeled_amounts"][:6]]
        line = f"* **{L['money']}:** " + "; ".join(money)
        if profile.get("written_amount"):
            line += f" ({L['written']}: {profile['written_amount']})"
        lines.append(line)
    if profile["periods"]:
        key = "label_te" if lang == "te" else "label_en"
        periods = [f"{p[key]} — **{p['value']}**" for p in profile["periods"][:5]]
        lines.append(f"* **{L['periods']}:** " + "; ".join(periods))
    props = profile["property_details"]
    prop_parts = []
    for field, te_label in PROPERTY_LABELS_TE.items():
        val = props.get(field)
        if _found(val):
            prop_parts.append(f"{te_label if lang == 'te' else field}: {val}")
    if not any(k in " ".join(prop_parts) for k in ("East", "తూర్పు")) and _found(props.get("Boundaries (చతుస్సీమలు)")):
        prop_parts.append(("చతుస్సీమలు" if lang == "te" else "Boundaries") + ": " + props["Boundaries (చతుస్సీమలు)"].replace("\n", " | "))
    if prop_parts:
        lines.append(f"* **{L['property']}:** " + "; ".join(prop_parts))
    return lines or [f"* {L['no_facts']}"]


def _build_duties(sentences: List[str], lang: str, limit: int) -> List[str]:
    L = LABELS[lang]
    duties = extract_duties(sentences)
    lines: List[str] = []
    general = L["general_party"]
    ordered = sorted(duties.items(), key=lambda kv: (kv[0] in ("General", "ఇతర నిబంధనలు"), kv[0]))
    for party, buckets in ordered:
        if party in ("General", "ఇతర నిబంధనలు"):
            party = general
            if len(ordered) > 1 and limit < 10:
                continue
        lines.append(f"**{party}**")
        for kind, label in (("obligation", L["must"]), ("right", L["can"]), ("prohibition", L["must_not"])):
            for s in buckets[kind][:limit]:
                lines.append(f"* *{label}:* {s}")
        lines.append("")
    return lines


def _build_risks(text: str, lang: str) -> List[str]:
    risks = highlight_potential_risks(text, source_lang=lang)["flagged_risks"]
    lines = []
    for r in risks:
        passage, _ = simplify_passage(r["source_passage"])
        quote = " ".join(passage)
        if len(quote) > 260:
            quote = quote[:260].rsplit(" ", 1)[0] + " …"
        lines.append(f"* **{r['category']}** ({r.get('severity_label', r['severity'])}): {r['plain_explanation']}")
        if quote:
            lines.append(f"  > {quote}")
    return lines


def _build_clauses(text: str, level: str, lang: str) -> List[str]:
    lines: List[str] = []
    clauses = [c for c in segment_into_clauses(text) if not c["clause_id"].startswith("Signatures")]
    max_clauses = 40 if level == "Detailed" else 12
    per_clause = 50 if level == "Detailed" else 2
    for cl in clauses[:max_clauses]:
        glossed: set = set()
        sentences, _ = simplify_passage(cl["text"], glossed)
        first_line = cl["text"].strip().split("\n")[0]
        if cl["title"].startswith("Preamble"):
            title = "ప్రారంభ వివరాలు (పక్షాలు)" if lang == "te" else "Opening Details (Parties)"
        elif is_heading_line(first_line) or re.match(r"^(?:Section|Clause|Article|నిబంధన|షరతు)\s*\d+\s*[\(\:]", first_line, re.IGNORECASE):
            title = _clean_title(cl["title"])
        else:
            # Numbered sentence without a heading: label it "Point N" instead of cutting the sentence
            num = re.search(r"\d+", cl["clause_id"])
            title = (f"అంశం {num.group(0)}" if lang == "te" else f"Point {num.group(0)}") if num else cl["clause_id"]
        body = [s for s in sentences if not is_heading_line(s) and _clean_title(s) != title]
        if not body:
            continue
        lines.append(f"**🔹 {title}**")
        for s in body[:per_clause]:
            lines.append(f"* {s}")
        if level == "Detailed":
            facts = [a["value"] for a in extract_labeled_amounts(cl["text"])] + [p["value"] for p in extract_time_periods(cl["text"])]
            if facts:
                lines.append(("  *ముఖ్య అంకెలు:* " if lang == "te" else "  *Key figures:* ") + ", ".join(dict.fromkeys(facts)))
        lines.append("")
    return lines


def rule_based_simplify(text: str, level: str = "Simple", lang: str = "en") -> Dict[str, Any]:
    """
    Offline same-language simplification. Every bullet is produced from the uploaded
    document's own sentences, facts and clauses — nothing is a fixed template.
    Returns the markdown plus statistics for the UI.
    """
    lang = "te" if lang == "te" else "en"
    L = LABELS[lang]
    profile = extract_contract_profile(text, lang)

    original_sentences = [s for s in split_sentences(text) if not is_noise_sentence(s)]
    simplified_sentences, rewrites = simplify_passage(text)
    before = readability_stats(original_sentences)
    after = readability_stats(simplified_sentences)

    out: List[str] = []
    out.append(f"#### 📄 {profile['doc_type_te'] if lang == 'te' else profile['doc_type_en']} — {L['title_suffix']}")
    stats_line = L["stats"].format(
        n=len(simplified_sentences), r=rewrites,
        a=before["avg_words_per_sentence"], b=after["avg_words_per_sentence"],
    )
    if lang == "en" and before["flesch_reading_ease"] is not None and after["flesch_reading_ease"] is not None:
        stats_line += L["flesch"].format(x=before["flesch_reading_ease"], y=after["flesch_reading_ease"])
    out.append(f"_{stats_line}_\n")

    # 1. Summary (TextRank)
    n_summary = 4 if level == "Simple" else 7
    content_sentences = [s for s in simplified_sentences if not is_heading_line(s)]
    out.append(f"##### {L['summary']}")
    for idx in summarize(content_sentences, max_sentences=n_summary):
        out.append(f"* {content_sentences[idx]}")
    out.append("")

    # 2. Key facts
    out.append(f"##### {L['facts']}")
    out.extend(_build_facts(profile, lang))
    out.append("")

    # 3. Obligations / rights / prohibitions
    duty_lines = _build_duties(content_sentences, lang, limit=3 if level == "Simple" else 10)
    if duty_lines:
        out.append(f"##### {L['duties']}")
        out.extend(duty_lines)

    # 4. Risks
    risk_lines = _build_risks(text, lang)
    if risk_lines:
        out.append(f"##### {L['risks']}")
        out.extend(risk_lines)
        out.append("")

    # 5. Clause-by-clause
    clause_lines = _build_clauses(text, level, lang)
    if clause_lines:
        out.append(f"##### {L['clauses']}")
        out.extend(clause_lines)

    # 6. Glossary
    glossary = extract_legal_glossary(text, "mixed" if lang == "te" and re.search(r"[A-Za-z]{4,}", text) else lang)
    if glossary:
        out.append(f"##### {L['glossary']}")
        for item in glossary[: (6 if level == "Simple" else 20)]:
            out.append(f"* **{item['term']}:** {item['plain_meaning']}")

    return {
        "markdown": "\n".join(out).strip(),
        "stats": {
            "sentences_simplified": len(simplified_sentences),
            "phrases_rewritten": rewrites,
            "before": before,
            "after": after,
            "facts_found": len(profile["parties"]) + len(profile["dates"]) + len(profile["labeled_amounts"]) + len(profile["periods"]),
        },
        "profile": profile,
    }


def rule_based_simplify_telugu(text: str, level: str = "Simple") -> str:
    """Telugu document -> simplified modern Telugu (offline)."""
    return rule_based_simplify(text, level=level, lang="te")["markdown"]


def rule_based_simplify_english(text: str, level: str = "Simple") -> str:
    """English document -> plain English (offline)."""
    return rule_based_simplify(text, level=level, lang="en")["markdown"]


def offline_translation_overview(text: str, target: str) -> str:
    """
    Without an AI key a full translation is not possible offline. Instead, give the key
    facts with labels in the target language (names, numbers and dates kept exactly).
    """
    lang = "te" if target == "te" else "en"
    profile = extract_contract_profile(text, lang)
    head = (
        f"### 🌐 {profile['doc_type_te']} — ముఖ్య వివరాలు తెలుగులో"
        if lang == "te" else f"### 🌐 {profile['doc_type_en']} — Key Facts in English"
    )
    note = (
        "> ℹ️ పూర్తి అనువాదం కోసం `.env` ఫైల్‌లో GEMINI_API_KEY లేదా OPENAI_API_KEY ఇవ్వండి. "
        "ఆఫ్‌లైన్ మోడ్‌లో ముఖ్య వివరాలు మాత్రమే అనువాద లేబుళ్లతో చూపబడతాయి."
        if lang == "te" else
        "> ℹ️ A full translation needs an AI key (GEMINI_API_KEY or OPENAI_API_KEY in `.env`). "
        "In offline mode only the key facts are shown with translated labels; names and numbers are unchanged."
    )
    return "\n".join([head, note, ""] + _build_facts(profile, lang))


# ----------------------------------------------------------------------------------------
# AI simplification (Gemini / OpenAI) with honest error reporting
# ----------------------------------------------------------------------------------------

def _build_ai_prompt(text: str, target_language_name: str, level: str, translate: bool) -> str:
    if translate:
        lang_rule = f"Translate the document's meaning into simple {target_language_name} while simplifying it."
    elif target_language_name == "Telugu":
        lang_rule = "Write ONLY in simple, modern spoken Telugu (the same language as the document). Do NOT translate into English."
    else:
        lang_rule = "Write in plain, everyday English."
    depth = (
        "Give a short, clear explanation a person with no legal background understands in 2 minutes."
        if level == "Simple" else
        "Explain every clause one by one: what it says, who it affects, and any condition or exception."
    )
    return f"""You are a legal document simplification assistant.
Rewrite the legal document below so an ordinary person can understand it.

RULES
1. Output language: {target_language_name}. {lang_rule}
2. Depth: {depth}
3. Base everything ONLY on this document. Keep every name, date, amount, number, survey/plot/door number and boundary exactly as written.
4. If something is missing or unreadable, say "Not found" (Telugu: "లభించలేదు"). Never guess or invent facts.
5. Use markdown with these sections (only include a section when the document has content for it):
   - In short (3-5 bullet points)
   - Parties and their roles
   - Money (rent / price / deposit / fees and when they are due)
   - Dates and time periods
   - Property details (if any)
   - Who must do what (obligations, rights, prohibitions for each party)
   - Points to watch (one-sided or risky clauses)
6. Do not add generic legal advice that is not tied to this document.

DOCUMENT
\"\"\"
{text[:30000]}
\"\"\"
"""


# Model that actually worked last time (may differ from GEMINI_MODEL if that one was retired)
_working_gemini_model: Optional[str] = None


def _gemini_replacement_models(client, failed_model: str, error_text: str) -> List[str]:
    """
    When a model is retired (404 NOT_FOUND), find replacements: the model named in Google's
    error message first, then available text 'flash' models, newest version first.
    """
    candidates: List[str] = []
    suggested = re.search(r"models/(gemini-[\w\.\-]+)", error_text.replace(f"models/{failed_model}", ""))
    if suggested:
        candidates.append(suggested.group(1).rstrip("."))
    try:
        listed = []
        for m in client.models.list():
            name = (getattr(m, "name", "") or "").replace("models/", "")
            actions = getattr(m, "supported_actions", None) or []
            if ("flash" in name and "generateContent" in actions
                    and not re.search(r"lite|image|tts|live|audio|embed|thinking|exp", name)):
                version = re.search(r"gemini-(\d+(?:\.\d+)?)", name)
                listed.append((float(version.group(1)) if version else 0.0, "preview" not in name, name))
        candidates.extend(name for _, _, name in sorted(listed, reverse=True))
    except Exception:
        pass
    return [c for c in dict.fromkeys(candidates) if c != failed_model][:3]


def _make_gemini_client(timeout_seconds: float):
    from google import genai
    from google.genai import types
    return genai.Client(api_key=GEMINI_API_KEY, http_options=types.HttpOptions(timeout=int(timeout_seconds * 1000)))


def _is_retired(message: str) -> bool:
    return "404" in message or "NOT_FOUND" in message


def _is_temporary(message: str) -> bool:
    """Overload / rate-limit / server hiccup: worth waiting and retrying."""
    return bool(re.search(r"\b(?:429|500|503|504)\b|UNAVAILABLE|RESOURCE_EXHAUSTED|INTERNAL|DEADLINE_EXCEEDED|overloaded|high demand|timed? ?out", message, re.IGNORECASE))


GEMINI_MIN_REQUEST_SECONDS = 10   # Google rejects request deadlines shorter than 10 seconds
GEMINI_RETRY_DELAY = 2             # pause before re-trying a busy model once


def _call_gemini(prompt: str, system: str, errors: List[str]) -> Optional[Dict[str, Any]]:
    """
    Call Gemini robustly within one overall time limit (AI_TIMEOUT_SECONDS):
      - busy / rate-limited (503, 429, timeout): try other available flash models first,
        then re-try the busy model once if time is left;
      - retired model (404): switch to the replacement Google suggests or the newest flash model.
    """
    global _working_gemini_model
    deadline = time.monotonic() + AI_TIMEOUT_SECONDS
    contents = f"{system}\n\n{prompt}"
    primary = _working_gemini_model or GEMINI_MODEL
    queue = [primary]
    attempts: Dict[str, int] = {}
    first_problem = None   # "retired" or "busy"
    failures: List[str] = []

    while queue:
        model = queue.pop(0)
        remaining = deadline - time.monotonic()
        if remaining < GEMINI_MIN_REQUEST_SECONDS + 1:
            failures.append(f"stopped after the {AI_TIMEOUT_SECONDS}-second time limit")
            break
        if attempts.get(model):
            time.sleep(GEMINI_RETRY_DELAY)
            remaining = deadline - time.monotonic()
        attempts[model] = attempts.get(model, 0) + 1
        client = _make_gemini_client(max(remaining, GEMINI_MIN_REQUEST_SECONDS))
        try:
            response = client.models.generate_content(model=model, contents=contents)
            if response.text and response.text.strip():
                engine = f"Gemini AI ({model})"
                if model != primary:
                    if first_problem == "retired":
                        _working_gemini_model = model
                        engine += f" — '{primary}' is no longer available; set GEMINI_MODEL={model} in .env"
                    else:
                        engine += f" — used because '{primary}' was busy"
                return {"text": response.text.strip(), "engine": engine, "errors": []}
            failures.append(f"{model}: empty response")
            continue
        except Exception as e:
            message = str(e)
            failures.append(f"{model}: {message}")
            if model == primary and attempts[model] == 1 and (_is_retired(message) or _is_temporary(message)):
                first_problem = "retired" if _is_retired(message) else "busy"
                queue.extend(_gemini_replacement_models(client, model, message)[:2])
                if first_problem == "busy":
                    queue.append(model)   # one more try of the busy model at the end

    if failures:
        errors.append("Gemini failed — " + " | ".join(failures))
    return None


def call_ai_model(prompt: str, system: str = "You are a careful legal document simplifier.") -> Dict[str, Any]:
    """Call Gemini first, then OpenAI. Returns text + engine, or the errors that occurred."""
    errors = []
    if GEMINI_API_KEY:
        try:
            result = _call_gemini(prompt, system, errors)
            if result:
                return result
        except Exception as e:
            errors.append(f"Gemini ({GEMINI_MODEL}) failed: {e}")
    if OPENAI_API_KEY:
        try:
            from openai import OpenAI
            client = OpenAI(api_key=OPENAI_API_KEY, timeout=AI_TIMEOUT_SECONDS, max_retries=1)
            completion = client.chat.completions.create(
                model=OPENAI_MODEL,
                messages=[{"role": "system", "content": system}, {"role": "user", "content": prompt}],
                temperature=0.2,
            )
            out_text = completion.choices[0].message.content
            if out_text and out_text.strip():
                return {"text": out_text.strip(), "engine": f"OpenAI ({OPENAI_MODEL})", "errors": errors}
            errors.append(f"OpenAI ({OPENAI_MODEL}) returned an empty response.")
        except Exception as e:
            errors.append(f"OpenAI ({OPENAI_MODEL}) failed: {e}")
    return {"text": None, "engine": None, "errors": errors}


def generate_ai_simplification(
    text: str,
    source_lang: str,
    level: str = "Simple",
    translate_to: Optional[str] = None,
    use_ai: bool = True
) -> Dict[str, Any]:
    """
    Simplify with an AI model when a key is configured; otherwise (or if the call fails)
    use the offline document-specific engine. Same-language output unless translate_to is set.
    """
    lang_meta = detect_document_language(text)
    output_lang = translate_to or ("te" if source_lang == "te" else lang_meta["dominant_lang"] if source_lang == "mixed" else "en")
    target_language_name = "Telugu" if output_lang == "te" else "English"

    ai_errors: List[str] = []
    if use_ai and (GEMINI_API_KEY or OPENAI_API_KEY):
        ai = call_ai_model(_build_ai_prompt(text, target_language_name, level, translate=bool(translate_to)))
        ai_errors = ai["errors"]
        if ai["text"]:
            return {
                "success": True,
                "simplified_text": ai["text"],
                "engine": ai["engine"],
                "target_language": target_language_name,
                "is_fallback": False,
                "ai_errors": ai_errors,
                "stats": None,
            }

    if translate_to:
        return {
            "success": True,
            "simplified_text": offline_translation_overview(text, translate_to),
            "engine": "LexiMind Offline Key-Facts Translator (labels only)",
            "target_language": target_language_name,
            "is_fallback": True,
            "ai_errors": ai_errors,
            "stats": None,
        }

    result = rule_based_simplify(text, level=level, lang=output_lang)
    if source_lang == "te":
        engine_label = "LexiMind Rule-Based Engine (Telugu Legal NLP Heuristics — Offline Mode)"
    elif source_lang == "mixed":
        engine_label = "LexiMind Rule-Based Engine (Bilingual Legal NLP Heuristics — Offline Mode)"
    else:
        engine_label = "LexiMind Rule-Based Engine (English Legal NLP Heuristics — Offline Mode)"

    return {
        "success": True,
        "simplified_text": result["markdown"],
        "engine": engine_label,
        "target_language": target_language_name,
        "is_fallback": True,
        "ai_errors": ai_errors,
        "stats": result["stats"],
        "note": "No AI API key configured (or the AI call failed). Generated offline from the document's own sentences.",
    }


def simplify_legal_document(
    text: str,
    level: str = "Simple",
    enable_translation: bool = False,
    translation_target: str = "en",
    use_ai: bool = True
) -> Dict[str, Any]:
    """
    Main simplification entry point.
    By default:
      - Simplifies same-language (Telugu -> Simplified Telugu, English -> Simplified English)
      - Translation is optional and only triggered when enable_translation is True.
    """
    lang_info = detect_document_language(text)
    src_code = lang_info["lang_code"]
    primary_lang = "te" if src_code == "te" else lang_info["dominant_lang"] if src_code == "mixed" else "en"

    translate_to = translation_target if (enable_translation and translation_target != primary_lang) else None

    primary_res = generate_ai_simplification(text=text, source_lang=src_code, level=level, translate_to=None, use_ai=use_ai)

    secondary_res = None
    if enable_translation:
        if translate_to:
            secondary_res = generate_ai_simplification(text=text, source_lang=src_code, level=level, translate_to=translate_to, use_ai=use_ai)
        else:
            secondary_res = {
                "simplified_text": "The document is already in the selected language, so no translation was needed.",
                "engine": "Not required",
                "ai_errors": [],
            }

    glossary = extract_legal_glossary(text, src_code)

    return {
        "source_language_info": lang_info,
        "simplification_level": level,
        "primary_simplified_text": primary_res["simplified_text"],
        "primary_engine": primary_res["engine"],
        "primary_language": primary_lang,
        "is_fallback": primary_res.get("is_fallback", False),
        "stats": primary_res.get("stats"),
        "ai_errors": primary_res.get("ai_errors", []) + (secondary_res.get("ai_errors", []) if secondary_res else []),
        "translation_enabled": enable_translation,
        "translated_simplified_text": secondary_res["simplified_text"] if secondary_res else None,
        "translation_engine": secondary_res["engine"] if secondary_res else None,
        "glossary": glossary
    }

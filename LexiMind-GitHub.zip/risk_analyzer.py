"""
LexiMind Risk Analyzer
Identifies potentially one-sided, onerous, or risky clauses in legal documents.
Outputs exact source passage, reason flagged, plain explanation, and actionable review advice.
Clearly distinguishes rule-based heuristics from AI observations, with legal safety disclaimers.
"""

import re
from typing import Dict, Any, List
from config import RISK_LEVEL_HIGH, RISK_LEVEL_MEDIUM, RISK_LEVEL_LOW, LEGAL_SAFETY_DISCLAIMER
from text_simplifier import split_sentences


# Rule patterns for detecting potential legal risks
RISK_RULES = [
    {
        "id": "UNILATERAL_TERMINATION",
        "category": "Unilateral Termination / Discretion",
        "severity": RISK_LEVEL_HIGH,
        "telugu_patterns": [
            r"నోటీసు\s*లేకుండా\s*తక్షణమే\s*రద్దు",
            r"కారణం\s*చూపకుండా\s*రద్దు",
            r"స్వంత\s*నిర్ణయంతో\s*రద్దు",
            r"ఎదుటి\s*పక్షం\s*సమ్మతి\s*లేకుండా"
        ],
        "english_patterns": [
            r"terminate\s+(?:immediately\s+)?without\s+(?:any\s+)?(?:cause|notice|reason)",
            r"sole\s+(?:and\s+absolute\s+)?discretion\s+to\s+terminate",
            r"unilateral\s+(?:right\s+to\s+)?terminate",
            r"without\s+liability\s+to\s+the\s+other\s+party",
            r"(?:sole|absolute)\s+(?:and\s+absolute\s+)?discretion\s+to\s+(?:terminate|end|cancel)",
            r"(?:evict|vacate|terminate|cancel)\b.{0,60}?\bwithout\s+(?:any\s+)?(?:prior\s+)?notice"
        ],
        "reason_flagged": "Allows one party to cancel the contract abruptly without mutual consent, explanation, or reasonable notice.",
        "plain_explanation_te": "ఒక పక్షం ఎదుటివారికి ఎటువంటి ముందస్తు నోటీసు లేదా కారణం ఇవ్వకుండానే ఒప్పందాన్ని రద్దు చేసుకునే అవకాశం కలిగి ఉంది. దీనివల్ల రెండవ పక్షానికి ఆకస్మిక నష్టం వాటిల్లవచ్చు.",
        "plain_explanation_en": "One party can cancel the agreement suddenly without prior notice or giving a legitimate reason, putting the other party at severe disadvantage.",
        "suggestion": "Require a mandatory written notice period (e.g., 30 to 60 days) and specify that termination must be based on legitimate, defined default events."
    },
    {
        "id": "EXCESSIVE_PENALTY_FORFEITURE",
        "category": "Excessive Penalty / Deposit Forfeiture",
        "severity": RISK_LEVEL_HIGH,
        "telugu_patterns": [
            r"డిపాజిట్\s*(?:మొత్తాన్ని|సొమ్మును)?\s*జప్తు",
            r"అడ్వాన్స్\s*తిరిగి\s*ఇవ్వబడదు",
            r"భారీ\s*జరిమానా",
            r"వడ్డీ\s*\d{2,}\s*శాతం"
        ],
        "english_patterns": [
            r"forfeit\s+(?:all|the\s+entire)\s+(?:security\s+)?deposit",
            r"liquidated\s+damages\s+(?:equal\s+to|exceeding)",
            r"non-refundable\s+under\s+any\s+circumstances",
            r"forfeit(?:ed|ure)?\s+(?:of\s+)?(?:the\s+)?(?:entire\s+|whole\s+|full\s+)?(?:security\s+)?(?:deposit|advance)",
            r"interest\s+(?:rate\s+)?(?:of\s+)?(?:[2-9]\d|1\d{2})\s*%\s*(?:per\s+month|per\s+annum)"
        ],
        "reason_flagged": "Imposes severe financial penalties or total forfeiture of deposits without accounting for actual proportional damages.",
        "plain_explanation_te": "చిన్న పొరపాటు లేదా ఆలస్యం జరిగినా మొత్తం సెక్యూరిటీ డిపాజిట్‌ను జప్తు చేసేలా లేదా అధిక వడ్డీ/జరిమానా విధించేలా నిబంధన ఉంది.",
        "plain_explanation_en": "The agreement allows complete forfeiture of security deposits or imposes disproportionate penalties even for minor non-compliance.",
        "suggestion": "Ensure forfeiture is restricted strictly to actual quantifiable damages, and cap late payment interest rates to reasonable statutory rates."
    },
    {
        "id": "UNLIMITED_LIABILITY_INDEMNITY",
        "category": "Broad / Unlimited Liability & Indemnity",
        "severity": RISK_LEVEL_MEDIUM,
        "telugu_patterns": [
            r"సమస్త\s*నష్టములకు\s*పరిహారము",
            r"పరిమితి\s*లేని\s*బాధ్యత",
            r"పూర్తిగా\s*రక్షణ\s*కల్పించవలెను",
            r"ఎలాంటి\s*క్లెయిములకైనా"
        ],
        "english_patterns": [
            r"unlimited\s+liability",
            r"indemnify\s+.*?(?:any\s+and\s+all\s+claims|all\s+claims)",
            r"without\s+(?:any\s+)?(?:cap|limitation)\s+(?:on|of)\s+liability",
            r"without\s+any\s+limitation\s+of\s+liability\s+or\s+cap",
            r"consequential,?\s+indirect\s+or\s+punitive\s+damages"
        ],
        "reason_flagged": "Creates an open-ended financial commitment to defend and pay for all damages or third-party claims without any monetary cap.",
        "plain_explanation_te": "నష్టపరిహార బాధ్యతపై ఎటువంటి గరిష్ట పరిమితి (క్యాప్) లేదు. ఎదుటివారి నిర్లక్ష్యం వల్ల వచ్చిన నష్టాలకు కూడా మిమ్మల్ని బాధ్యులను చేసే ప్రమాదం ఉంది.",
        "plain_explanation_en": "Indemnification is one-sided and liability is uncapped, meaning a party could face indefinite financial exposure for unforeseen third-party claims.",
        "suggestion": "Introduce a monetary cap on liability (e.g., equal to 1x to 2x the annual contract value) and exclude liability for gross negligence of the other party."
    },
    {
        "id": "STRICT_LOCK_IN",
        "category": "Strict Lock-In / Inflexible Term",
        "severity": RISK_LEVEL_MEDIUM,
        "telugu_patterns": [
            r"లాక్-ఇన్\s*కాలపరిమితి",
            r"గడువు\s*ముగిసేవరకు\s*రద్దు\s*చేయరాదు",
            r"మిగిలిన\s*కాలపు\s*అద్దె\s*చెల్లించాలి"
        ],
        "english_patterns": [
            r"lock-in\s+period\s+of",
            r"shall\s+not\s+(?:have\s+the\s+right\s+to\s+)?terminate\s+prior\s+to",
            r"pay\s+the\s+rent\s+for\s+the\s+remainder\s+of\s+the\s+lock-in"
        ],
        "reason_flagged": "Forces a party to remain committed for a rigid period, requiring payment of remaining dues even if circumstances change drastically.",
        "plain_explanation_te": "ఒప్పందం నిర్ణీత కాలం (లాక్-ఇన్) వరకు తప్పనిసరిగా కొనసాగాలి, మధ్యలో ఖాళీ చేసినా మిగిలిన నెలల మొత్తం చెల్లించాల్సి ఉంటుంది.",
        "plain_explanation_en": "Binds a party to a mandatory duration without exit options, demanding payment of remaining contract fees upon early exit.",
        "suggestion": "Include exit conditions for unforeseen hardship, job transfer, health emergencies, or material breach by the other party."
    },
    {
        "id": "UNFAVORABLE_JURISDICTION",
        "category": "Unfavorable Dispute Resolution / Jurisdiction",
        "severity": RISK_LEVEL_LOW,
        "telugu_patterns": [
            r"ఏకపక్ష\s*మధ్యవర్తి",
            r"కేవలం\s*ఒకరి\s*పరిధిలోని\s*కోర్టు"
        ],
        "english_patterns": [
            r"exclusive\s+jurisdiction\s+of\s+courts\s+in",
            r"sole\s+arbitrator\s+appointed\s+exclusively\s+by",
            r"waive\s+any\s+objection\s+to\s+venue"
        ],
        "reason_flagged": "Sets the dispute resolution venue or court in a distant, inconvenient location or allows sole appointment of an arbitrator by one party.",
        "plain_explanation_te": "వివాదాలు వస్తే పరిష్కరించే కోర్టు చాలా దూరంగా ఉండడం లేదా మధ్యవర్తిని ఒకే పక్షం నియమించుకునే అవకాశం ఉండడం.",
        "plain_explanation_en": "Specifies an inconvenient legal venue or allows unilateral appointment of an arbitrator, increasing legal expense and bias risk.",
        "suggestion": "Ensure the dispute resolution venue is local to the property/business location, or require mutual agreement for arbitrator appointments."
    },
    {
        "id": "AUTO_RENEWAL_TRAP",
        "category": "Automatic Renewal Trap",
        "severity": RISK_LEVEL_LOW,
        "telugu_patterns": [
            r"ఆటోమేటిక్గా\s*పునరుద్ధరించబడును",
            r"నోటీసు\s*ఇవ్వనిచో\s*పొడిగింపు"
        ],
        "english_patterns": [
            r"automatically\s+renew(?:ed|s)?\s+for",
            r"consecutive\s+terms?\s+unless\s+written\s+notice",
            r"evergreen\s+clause"
        ],
        "reason_flagged": "Contract automatically extends for additional terms unless opt-out notice is given within an easily missed narrow window.",
        "plain_explanation_te": "ఒప్పందం గడువు ముగిసినప్పుడు ప్రత్యేక నోటీసు ఇవ్వకపోతే స్వయంచాలకంగా మరికొంత కాలం పొడిగించబడుతుంది.",
        "plain_explanation_en": "The agreement automatically renews for another full cycle unless timely written cancellation notice is served.",
        "suggestion": "Require affirmative mutual written confirmation for renewal rather than silent automatic extension."
    },
    {
        "id": "ONE_SIDED_WAIVER",
        "category": "One-Sided Waiver / No Liability",
        "severity": RISK_LEVEL_MEDIUM,
        "telugu_patterns": [
            r"ఎటువంటి\s*బాధ్యత\s*(?:వహించరు|వహించబోరు|లేదు)",
            r"హక్కులను\s*వదులుకొను",
            r"ఎటువంటి\s*క్లెయిము\s*చేయరాదు"
        ],
        "english_patterns": [
            r"waives?\s+(?:all|any)\s+(?:of\s+(?:its|his|her|their)\s+)?(?:rights?|claims?)",
            r"shall\s+not\s+be\s+(?:held\s+)?(?:liable|responsible)\s+for\s+any",
            r"no\s+(?:liability|responsibility)\s+(?:whatsoever|of\s+any\s+kind)"
        ],
        "reason_flagged": "One party gives up its legal rights or the other party excludes all of its own responsibility.",
        "plain_explanation_te": "ఒక పక్షం తన హక్కులను పూర్తిగా వదులుకునేలా లేదా ఎదుటి పక్షం ఎలాంటి బాధ్యత తీసుకోనవసరం లేకుండా నిబంధన ఉంది.",
        "plain_explanation_en": "You may be giving up your right to claim compensation, or the other side refuses all responsibility even for its own faults.",
        "suggestion": "Limit waivers to specific, listed situations and keep liability for negligence, fraud and wilful misconduct."
    },
    {
        "id": "RENT_ESCALATION",
        "category": "Rent / Price Escalation",
        "severity": RISK_LEVEL_LOW,
        "telugu_patterns": [
            r"అద్దె\s*\d+\s*%\s*పెంచ",
            r"\d+\s*శాతం\s*(?:అద్దె\s*)?పెంపు"
        ],
        "english_patterns": [
            r"(?:increase|enhance|escalat)\w*\s+(?:the\s+)?(?:monthly\s+)?(?:rent|fee|price)\s+(?:by\s+)?\d+\s*%",
            r"(?:rent|fee|price)\s+(?:shall|will)\s+(?:be\s+)?(?:increased|enhanced|escalated)\s+(?:by\s+)?\d+\s*%",
            r"\d+\s*%\s+(?:annual\s+)?(?:increase|escalation|hike)"
        ],
        "reason_flagged": "The payment automatically increases on renewal or every year.",
        "plain_explanation_te": "పునరుద్ధరణ సమయంలో లేదా ప్రతి సంవత్సరం అద్దె / ధర ఒక నిర్ణీత శాతం పెరుగుతుంది. మీ బడ్జెట్‌ను ముందుగా లెక్కించుకోండి.",
        "plain_explanation_en": "The rent or price goes up by a fixed percentage on renewal or every year — plan your budget for it.",
        "suggestion": "Check that the increase percentage is reasonable for your area and that it applies only on renewal, not mid-term."
    }
]


RISK_CATEGORY_TE = {
    "UNILATERAL_TERMINATION": "ఏకపక్ష రద్దు",
    "EXCESSIVE_PENALTY_FORFEITURE": "అధిక జరిమానా / డిపాజిట్ జప్తు",
    "UNLIMITED_LIABILITY_INDEMNITY": "పరిమితి లేని బాధ్యత / నష్టపరిహారం",
    "STRICT_LOCK_IN": "కఠినమైన లాక్-ఇన్ కాలం",
    "UNFAVORABLE_JURISDICTION": "అననుకూల కోర్టు / మధ్యవర్తి",
    "AUTO_RENEWAL_TRAP": "స్వయంచాలక పునరుద్ధరణ",
    "ONE_SIDED_WAIVER": "ఏకపక్ష హక్కుల వదులుకోలు / బాధ్యత లేదు",
    "RENT_ESCALATION": "అద్దె / ధర పెంపు",
}
SEVERITY_TE = {
    RISK_LEVEL_HIGH: "అధిక ప్రమాదం",
    RISK_LEVEL_MEDIUM: "మధ్యస్థ ప్రమాదం",
    RISK_LEVEL_LOW: "సమీక్షించండి",
}


def _passages(text: str) -> List[str]:
    """Sentence-level passages, so the quoted source is the exact risky sentence."""
    sentences = split_sentences(text)
    return sentences if sentences else [p.strip() for p in text.split("\n\n") if p.strip()]


def highlight_potential_risks(text: str, source_lang: str = "en") -> Dict[str, Any]:
    """
    Scan contract text against legal risk heuristics.
    Both Telugu and English patterns are always checked (documents often mix scripts);
    explanations are returned in the document's language.
    """
    flagged_risks = []
    passages = _passages(text)
    use_te = source_lang == "te"

    for rule in RISK_RULES:
        patterns = rule["telugu_patterns"] + rule["english_patterns"]
        matching_passage = ""
        for pattern in patterns:
            for passage in passages:
                if re.search(pattern, passage, re.IGNORECASE):
                    matching_passage = passage
                    break
            if matching_passage:
                break

        if matching_passage:
            explanation = rule["plain_explanation_te"] if use_te else rule["plain_explanation_en"]
            flagged_risks.append({
                "rule_id": rule["id"],
                "category": RISK_CATEGORY_TE.get(rule["id"], rule["category"]) + f" ({rule['category']})" if use_te else rule["category"],
                "severity": rule["severity"],
                "severity_label": SEVERITY_TE.get(rule["severity"], rule["severity"]) if use_te else rule["severity"],
                "source_passage": matching_passage[:400] + ("..." if len(matching_passage) > 400 else ""),
                "reason_flagged": rule["reason_flagged"],
                "plain_explanation": explanation,
                "suggestion": rule["suggestion"],
                "engine": "Rule-Based Heuristic Risk Detector"
            })

    # Summary metrics
    high_count = sum(1 for r in flagged_risks if r["severity"] == RISK_LEVEL_HIGH)
    med_count = sum(1 for r in flagged_risks if r["severity"] == RISK_LEVEL_MEDIUM)
    low_count = sum(1 for r in flagged_risks if r["severity"] == RISK_LEVEL_LOW)

    return {
        "total_risks_flagged": len(flagged_risks),
        "high_risk_count": high_count,
        "medium_risk_count": med_count,
        "advisory_count": low_count,
        "flagged_risks": flagged_risks,
        "disclaimer": LEGAL_SAFETY_DISCLAIMER
    }